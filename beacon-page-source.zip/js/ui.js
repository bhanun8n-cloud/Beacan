/* Shared UI primitives: icons, toasts, modals, formatting, charts. */
import { qrSvg } from './qr.js';

let renderer = () => {};
export function setRenderer(fn) { renderer = fn; }
export function rerender() { renderer(); }

export function navigate(hash) {
  if (location.hash === hash) rerender();
  else location.hash = hash;
}

export function esc(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

/* ---------- icons ---------- */
const ICONS = {
  home: '<path d="M4 10.6 12 4l8 6.6V19a1.6 1.6 0 0 1-1.6 1.6h-3.6v-6H9.2v6H5.6A1.6 1.6 0 0 1 4 19z"/>',
  link: '<path d="M10.2 13.4a3.6 3.6 0 0 0 5.1 0l2.6-2.6a3.6 3.6 0 0 0-5.1-5.1l-1 1"/><path d="M13.8 10.6a3.6 3.6 0 0 0-5.1 0L6.1 13.2a3.6 3.6 0 0 0 5.1 5.1l1-1"/>',
  palette: '<circle cx="12" cy="12" r="8.4"/><circle cx="8.6" cy="10" r="1.1" fill="currentColor" stroke="none"/><circle cx="12.4" cy="7.9" r="1.1" fill="currentColor" stroke="none"/><circle cx="15.8" cy="10.4" r="1.1" fill="currentColor" stroke="none"/><path d="M12 20.4a3 3 0 0 1 0-6h.6a1.5 1.5 0 0 0 0-3"/>',
  user: '<circle cx="12" cy="8.4" r="3.6"/><path d="M5 20.2a7 7 0 0 1 14 0"/>',
  users: '<circle cx="9.2" cy="8.6" r="3.3"/><path d="M3.4 19.6a6 6 0 0 1 11.6 0"/><path d="M16 5.6a3.2 3.2 0 0 1 0 6.2"/><path d="M17.6 14.4a5.4 5.4 0 0 1 3 5.2"/>',
  chart: '<path d="M4 20h16"/><path d="M7 20v-6"/><path d="M12 20V7"/><path d="M17 20v-9"/>',
  trend: '<path d="M3 16.5 9 10l4 3.8L21 6"/><path d="M15.6 6H21v5.4"/>',
  mail: '<rect x="3" y="5.4" width="18" height="13.2" rx="2.4"/><path d="m3.8 7 8.2 6 8.2-6"/>',
  message: '<path d="M20.4 12.2c0 3.9-3.8 7-8.4 7a9.6 9.6 0 0 1-2.6-.35L4.6 20.4l1.2-3.6A6.7 6.7 0 0 1 3.6 12.2c0-3.9 3.8-7 8.4-7s8.4 3.1 8.4 7Z"/>',
  card: '<rect x="3" y="5.4" width="18" height="13.2" rx="2.6"/><path d="M3 10h18"/><path d="M7 14.6h4"/>',
  file: '<path d="M14 3.4H7.4A2 2 0 0 0 5.4 5.4v13.2a2 2 0 0 0 2 2h9.2a2 2 0 0 0 2-2V8z"/><path d="M13.8 3.6V8h5"/>',
  plus: '<path d="M12 5v14"/><path d="M5 12h14"/>',
  search: '<circle cx="11" cy="11" r="6.4"/><path d="m16 16 4.4 4.4"/>',
  chevronRight: '<path d="m9.4 6 6 6-6 6"/>',
  chevronLeft: '<path d="m14.6 6-6 6 6 6"/>',
  chevronDown: '<path d="m6 9.4 6 6 6-6"/>',
  chevronUp: '<path d="m6 14.6 6-6 6 6"/>',
  arrowUp: '<path d="M12 19V5"/><path d="m6 11 6-6 6 6"/>',
  arrowDown: '<path d="M12 5v14"/><path d="m18 13-6 6-6-6"/>',
  arrowLeft: '<path d="M19 12H5"/><path d="m11 6-6 6 6 6"/>',
  arrowRight: '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
  undo: '<path d="M8.4 5.4 4.6 9.2l3.8 3.8"/><path d="M4.6 9.2h9a5.4 5.4 0 0 1 0 10.8H8.6"/>',
  redo: '<path d="m15.6 5.4 3.8 3.8-3.8 3.8"/><path d="M19.4 9.2h-9a5.4 5.4 0 0 0 0 10.8h5"/>',
  share: '<path d="M12 16V4"/><path d="m7.6 8.4 4.4-4.4 4.4 4.4"/><path d="M5 14.6v3.8a1.8 1.8 0 0 0 1.8 1.8h10.4a1.8 1.8 0 0 0 1.8-1.8v-3.8"/>',
  eye: '<path d="M2.6 12S6 5.8 12 5.8 21.4 12 21.4 12 18 18.2 12 18.2 2.6 12 2.6 12Z"/><circle cx="12" cy="12" r="3"/>',
  eyeOff: '<path d="M3 3l18 18"/><path d="M10.2 6.1A9.7 9.7 0 0 1 12 5.8c6 0 9.4 6.2 9.4 6.2a17 17 0 0 1-3 3.8"/><path d="M6.3 7.8A16 16 0 0 0 2.6 12S6 18.2 12 18.2a9.6 9.6 0 0 0 3.3-.55"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
  copy: '<rect x="8.6" y="8.6" width="11" height="11" rx="2.2"/><path d="M15.4 5.4H6.6a2.2 2.2 0 0 0-2.2 2.2v8.8"/>',
  trash: '<path d="M4.6 7.4h14.8"/><path d="M9.4 7.4V5.6a1.4 1.4 0 0 1 1.4-1.4h2.4a1.4 1.4 0 0 1 1.4 1.4v1.8"/><path d="M6.4 7.4l.9 11.2a1.8 1.8 0 0 0 1.8 1.6h5.8a1.8 1.8 0 0 0 1.8-1.6l.9-11.2"/>',
  archive: '<rect x="3.4" y="4.6" width="17.2" height="4.6" rx="1.4"/><path d="M5.2 9.2v8.4a2 2 0 0 0 2 2h9.6a2 2 0 0 0 2-2V9.2"/><path d="M10 13.2h4"/>',
  clock: '<circle cx="12" cy="12" r="8.4"/><path d="M12 7.6V12l3 1.8"/>',
  drag: '<circle cx="9" cy="6.6" r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="6.6" r="1.2" fill="currentColor" stroke="none"/><circle cx="9" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="9" cy="17.4" r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="17.4" r="1.2" fill="currentColor" stroke="none"/>',
  check: '<path d="m5 12.6 4.2 4.2L19 6.6"/>',
  checkCircle: '<circle cx="12" cy="12" r="8.6"/><path d="m8 12.2 2.8 2.8 5.2-5.6"/>',
  x: '<path d="M6 6l12 12"/><path d="M18 6 6 18"/>',
  dots: '<circle cx="6" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="18" cy="12" r="1.4" fill="currentColor" stroke="none"/>',
  grid: '<rect x="4" y="4" width="6.4" height="6.4" rx="1.6"/><rect x="13.6" y="4" width="6.4" height="6.4" rx="1.6"/><rect x="4" y="13.6" width="6.4" height="6.4" rx="1.6"/><rect x="13.6" y="13.6" width="6.4" height="6.4" rx="1.6"/>',
  settings: '<circle cx="12" cy="12" r="3.1"/><path d="M19.2 14.4a1.5 1.5 0 0 0 .3 1.7l.1.1a1.8 1.8 0 1 1-2.6 2.6l-.1-.1a1.5 1.5 0 0 0-2.5 1.1v.3a1.8 1.8 0 1 1-3.6 0v-.2a1.5 1.5 0 0 0-2.6-1.1l-.1.1a1.8 1.8 0 1 1-2.6-2.6l.1-.1a1.5 1.5 0 0 0-1.1-2.5H4a1.8 1.8 0 1 1 0-3.6h.2a1.5 1.5 0 0 0 1.1-2.6l-.1-.1a1.8 1.8 0 1 1 2.6-2.6l.1.1a1.5 1.5 0 0 0 2.5-1.1V4a1.8 1.8 0 1 1 3.6 0v.2a1.5 1.5 0 0 0 2.6 1.1l.1-.1a1.8 1.8 0 1 1 2.6 2.6l-.1.1a1.5 1.5 0 0 0 1.1 2.5h.3a1.8 1.8 0 1 1 0 3.6h-.2a1.5 1.5 0 0 0-1.3.8Z"/>',
  logout: '<path d="M14.4 8.4V5.8A1.8 1.8 0 0 0 12.6 4H6a1.8 1.8 0 0 0-1.8 1.8v12.4A1.8 1.8 0 0 0 6 20h6.6a1.8 1.8 0 0 0 1.8-1.8v-2.6"/><path d="M9.8 12h10"/><path d="m16.6 8.8 3.2 3.2-3.2 3.2"/>',
  bell: '<path d="M18 9.4a6 6 0 0 0-12 0c0 5.2-2 6.6-2 6.6h16s-2-1.4-2-6.6"/><path d="M13.7 19.4a2 2 0 0 1-3.4 0"/>',
  lock: '<rect x="4.8" y="10.4" width="14.4" height="9.6" rx="2.4"/><path d="M8.4 10.4V7.8a3.6 3.6 0 0 1 7.2 0v2.6"/>',
  creditCard: '<rect x="3" y="5.6" width="18" height="12.8" rx="2.4"/><path d="M3 10h18"/>',
  sparkles: '<path d="m12 4 1.7 4.6L18.4 10l-4.7 1.4L12 16l-1.7-4.6L5.6 10l4.7-1.4z"/><path d="M18.4 16.4 19 18l1.6.6-1.6.6-.6 1.6-.6-1.6-1.6-.6 1.6-.6z"/>',
  image: '<rect x="3.6" y="4.6" width="16.8" height="14.8" rx="2.4"/><circle cx="9" cy="10" r="1.6"/><path d="m4.6 17 4.6-4.4 3.2 3 2.6-2.4 4.4 4.2"/>',
  play: '<path d="M9 6.6 18 12l-9 5.4z"/>',
  type: '<path d="M5 6.4V5h14v1.4"/><path d="M12 5v14"/><path d="M9 19h6"/>',
  calendar: '<rect x="3.6" y="5.4" width="16.8" height="15" rx="2.2"/><path d="M3.6 10.2h16.8"/><path d="M8.4 3.6v3.4"/><path d="M15.6 3.6v3.4"/>',
  filter: '<path d="M4 6h16"/><path d="M7 12h10"/><path d="M10 18h4"/>',
  download: '<path d="M12 4v11"/><path d="m7.6 10.6 4.4 4.4 4.4-4.4"/><path d="M5 19.4h14"/>',
  external: '<path d="M14.4 4.6H20v5.6"/><path d="m20 4.6-8.4 8.4"/><path d="M18 14.4v3.8a1.8 1.8 0 0 1-1.8 1.8H5.8A1.8 1.8 0 0 1 4 18.2V7.8A1.8 1.8 0 0 1 5.8 6H9.6"/>',
  info: '<circle cx="12" cy="12" r="8.4"/><path d="M12 11v5.4"/><circle cx="12" cy="8" r=".9" fill="currentColor" stroke="none"/>',
  help: '<circle cx="12" cy="12" r="8.4"/><path d="M9.6 9.4a2.5 2.5 0 1 1 3.6 2.2c-.7.4-1.2 1-1.2 1.8v.3"/><circle cx="12" cy="16.6" r=".9" fill="currentColor" stroke="none"/>',
  bag: '<path d="M5.4 8h13.2l-1 11.2a1.8 1.8 0 0 1-1.8 1.6H8.2a1.8 1.8 0 0 1-1.8-1.6z"/><path d="M8.8 8V6.4a3.2 3.2 0 0 1 6.4 0V8"/>',
  form: '<rect x="4" y="3.8" width="16" height="16.4" rx="2.4"/><path d="M7.6 8.4h8.8"/><path d="M7.6 12h8.8"/><path d="M7.6 15.6h5"/>',
  send: '<path d="m21 3-9.4 18-2-7.6L3 11z"/><path d="m9.6 13.4 5-5"/>',
  star: '<path d="m12 4 2.5 5.2 5.5.8-4 3.9.9 5.6-4.9-2.7-4.9 2.7.9-5.6-4-3.9 5.5-.8z"/>',
  globe: '<circle cx="12" cy="12" r="8.4"/><path d="M3.8 12h16.4"/><path d="M12 3.6a14 14 0 0 1 0 16.8a14 14 0 0 1 0-16.8"/>',
  instagram: '<rect x="3.6" y="3.6" width="16.8" height="16.8" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17" cy="7" r="1.1" fill="currentColor" stroke="none"/>',
  tiktok: '<path d="M14.4 4v10.2a3.4 3.4 0 1 1-3.4-3.4"/><path d="M14.4 4c.3 2.6 2 4.2 4.6 4.4"/>',
  youtube: '<rect x="2.8" y="6" width="18.4" height="12" rx="3.4"/><path d="m10.6 9.6 4.4 2.4-4.4 2.4z"/>',
  x: '<path d="M4.4 4.4l15.2 15.2"/><path d="M19.6 4.4 4.4 19.6"/>',
  spotify: '<circle cx="12" cy="12" r="8.4"/><path d="M8 9.6c2.6-.8 5.4-.6 7.6.6"/><path d="M8.6 12.4c2.1-.6 4.4-.4 6.2.5"/><path d="M9.2 15c1.6-.4 3.3-.3 4.8.4"/>',
  linktree: '<path d="M12 4v16"/><path d="m7 9 5-5 5 5"/>',
  menu: '<path d="M4 7h16"/><path d="M4 12h16"/><path d="M4 17h16"/>',
  qr: '<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><path d="M14 14h2v2h-2z"/><path d="M18 14h2"/><path d="M14 18h2"/><path d="M18 18h2v2h-2z"/>',
  phone: '<path d="M7.4 4.4h-2A1.6 1.6 0 0 0 3.8 6c0 7.8 6.4 14.2 14.2 14.2a1.6 1.6 0 0 0 1.6-1.6v-2a1.6 1.6 0 0 0-1.2-1.5l-2.6-.6a1.6 1.6 0 0 0-1.6.5l-1 1.2a12.6 12.6 0 0 1-5.4-5.4l1.2-1a1.6 1.6 0 0 0 .5-1.6l-.6-2.6a1.6 1.6 0 0 0-1.5-1.2z"/>',
  building: '<path d="M5 20V6.4l7-3.2v16.8"/><path d="M12 9h7v11"/><path d="M3.4 20h17.2"/><path d="M8 8.6h1.2M8 12h1.2M8 15.4h1.2M15 12.4h1.2M15 15.8h1.2"/>',
  wallet: '<rect x="3.4" y="6" width="17.2" height="12.6" rx="2.8"/><path d="M3.4 10.4h17.2"/><circle cx="16.6" cy="14.8" r="1" fill="currentColor" stroke="none"/>',
  megaphone: '<path d="M4 10v4a1.6 1.6 0 0 0 1.6 1.6H8l7.4 3.6V5.4L8 9H5.6A1.6 1.6 0 0 0 4 10.6z"/><path d="M18 9.4a3.6 3.6 0 0 1 0 5.2"/>',
  scissors: '<circle cx="7" cy="17.4" r="2.4"/><circle cx="7" cy="6.6" r="2.4"/><path d="M9 8 19 18"/><path d="M9 16 19 6"/>',
  bulb: '<path d="M9.4 17.4h5.2"/><path d="M10.4 20.4h3.2"/><path d="M12 3.6a5.8 5.8 0 0 0-3.2 10.6v3.2h6.4v-3.2A5.8 5.8 0 0 0 12 3.6z"/>',
  invite: '<circle cx="9" cy="8.4" r="3.4"/><path d="M3 19.6a6 6 0 0 1 12 0"/><path d="M18 8v6"/><path d="M15 11h6"/>',
  book: '<path d="M4 5.4A2 2 0 0 1 6 3.4h13v15.2H6a2 2 0 0 0-2 2z"/><path d="M4 5.4v15.2"/>',
  code: '<path d="m8.4 8.4-4 3.6 4 3.6"/><path d="m15.6 8.4 4 3.6-4 3.6"/>',
  ticket: '<path d="M3.6 9.4V7a1.6 1.6 0 0 1 1.6-1.6h13.6A1.6 1.6 0 0 1 20.4 7v2.4a2.6 2.6 0 0 0 0 5.2V17a1.6 1.6 0 0 1-1.6 1.6H5.2A1.6 1.6 0 0 1 3.6 17v-2.4a2.6 2.6 0 0 0 0-5.2z"/>',
  music: '<circle cx="7" cy="17" r="2.4"/><circle cx="17.4" cy="15" r="2.4"/><path d="M9.4 17V7.4l10.4-2v9.6"/>',
  camera: '<path d="M4 8.4h2.6l1.4-2h8l1.4 2H20a1.6 1.6 0 0 1 1.6 1.6v8.4A1.6 1.6 0 0 1 20 20H4a1.6 1.6 0 0 1-1.6-1.6V10A1.6 1.6 0 0 1 4 8.4z"/><circle cx="12" cy="14" r="3.4"/>',
};

export function icon(name, size = 18) {
  const body = ICONS[name] || ICONS.link;
  return `<svg class="ic" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${body}</svg>`;
}

export const SOCIAL_ICON = {
  instagram: 'instagram', tiktok: 'tiktok', youtube: 'youtube', x: 'x',
  spotify: 'spotify', website: 'globe',
};

/* ---------- formatting ---------- */
export function formatNumber(n) {
  if (n === null || n === undefined) return '0';
  return new Intl.NumberFormat('en-US').format(Math.round(n));
}
export function compactNumber(n) {
  return new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 1 }).format(n || 0);
}
export function formatDate(iso, opts = { month: 'short', day: 'numeric' }) {
  if (!iso) return '—';
  return new Intl.DateTimeFormat('en-US', opts).format(new Date(iso));
}
export function formatDateTime(iso) {
  return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(new Date(iso));
}
export function timeAgo(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.round(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.round(hrs / 24);
  if (days < 30) return `${days}d ago`;
  return formatDate(iso);
}
export function initials(name = '') {
  return name.trim().split(/\s+/).slice(0, 2).map((p) => p[0]?.toUpperCase() || '').join('') || 'B';
}
export function greeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
}
export function prettyDate(date = new Date()) {
  return new Intl.DateTimeFormat('en-US', { weekday: 'long', month: 'long', day: 'numeric' }).format(date);
}

/* ---------- toasts ---------- */
export function toast(message, kind = 'default', ms = 3400) {
  const root = document.getElementById('toast-root');
  if (!root) return;
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  const ic = kind === 'success' ? 'checkCircle' : kind === 'error' ? 'info' : 'sparkles';
  el.innerHTML = `${icon(ic, 16)}<span>${esc(message)}</span>`;
  root.appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity .3s ease, transform .3s ease';
    el.style.opacity = '0';
    el.style.transform = 'translateY(8px)';
    setTimeout(() => el.remove(), 320);
  }, ms);
}

/* ---------- modal ---------- */
let lastFocused = null;

export function openModal({ title, subtitle = '', body, footer = '', size = '', onMount, onClose, labelledBy = 'modal-title' }) {
  closeModal();
  lastFocused = document.activeElement;
  const root = document.getElementById('overlay-root');
  const wrap = document.createElement('div');
  wrap.className = 'backdrop';
  wrap.dataset.backdrop = 'true';
  wrap.innerHTML = `
    <div class="modal ${size}" role="dialog" aria-modal="true" aria-labelledby="${labelledBy}">
      <div class="modal-head">
        <div>
          <h2 class="modal-title" id="${labelledBy}">${esc(title)}</h2>
          ${subtitle ? `<p class="modal-sub">${esc(subtitle)}</p>` : ''}
        </div>
        <button class="btn-icon modal-close" data-action="modal-close" aria-label="Close dialog">${icon('x', 18)}</button>
      </div>
      <div class="modal-body">${body}</div>
      ${footer ? `<div class="modal-foot">${footer}</div>` : ''}
    </div>`;
  root.appendChild(wrap);
  document.body.style.overflow = 'hidden';

  wrap.addEventListener('mousedown', (e) => {
    if (e.target === wrap) closeModal();
  });
  wrap.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { e.stopPropagation(); closeModal(); }
    if (e.key === 'Tab') {
      const focusables = wrap.querySelectorAll('a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])');
      if (!focusables.length) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });

  const auto = wrap.querySelector('[data-autofocus]') || wrap.querySelector('input, button, textarea, select');
  setTimeout(() => auto?.focus(), 30);
  if (onMount) onMount(wrap);
  wrap._onClose = onClose;
  return wrap;
}

export function closeModal() {
  const root = document.getElementById('overlay-root');
  const wrap = root?.querySelector('.backdrop');
  if (!wrap) return;
  const cb = wrap._onClose;
  wrap.remove();
  document.body.style.overflow = '';
  if (lastFocused && document.contains(lastFocused)) lastFocused.focus();
  if (cb) cb();
}

export function dialog({ title, message, confirmLabel = 'Confirm', cancelLabel = 'Cancel', danger = false, requireText = null }) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (value) => { if (!settled) { settled = true; resolve(value); } };
    openModal({
      title,
      body: `
        <p class="small" style="color:#4b4b45">${esc(message)}</p>
        ${requireText ? `
          <div class="field mt-4">
            <label class="field-label" for="confirm-text">Type <strong>${esc(requireText)}</strong> to continue</label>
            <input class="input" id="confirm-text" name="confirmText" autocomplete="off" data-confirm-input />
          </div>` : ''}`,
      footer: `
        <button class="btn btn-outline" data-action="dialog-cancel">${esc(cancelLabel)}</button>
        <button class="btn ${danger ? 'btn-danger-solid' : 'btn-primary'}" data-action="dialog-confirm" ${requireText ? 'disabled' : ''}>${esc(confirmLabel)}</button>`,
      onMount(wrap) {
        const confirmBtn = wrap.querySelector('[data-action="dialog-confirm"]');
        const input = wrap.querySelector('[data-confirm-input]');
        if (input && confirmBtn) {
          input.addEventListener('input', () => {
            confirmBtn.disabled = input.value.trim() !== requireText;
          });
        }
        confirmBtn?.addEventListener('click', () => { finish(true); closeModal(); });
        wrap.querySelector('[data-action="dialog-cancel"]')?.addEventListener('click', () => { finish(false); closeModal(); });
      },
      onClose() { finish(false); },
    });
  });
}

/* ---------- charts ---------- */
export function areaChart(series, { labels = [], height = 210 } = {}) {
  const w = 720;
  const h = height;
  const pad = { top: 12, right: 8, bottom: 24, left: 34 };
  const max = Math.max(1, ...series.map((s) => Math.max(s.views, s.clicks)));
  const stepX = (w - pad.left - pad.right) / Math.max(1, series.length - 1);
  const y = (v) => h - pad.bottom - (v / max) * (h - pad.top - pad.bottom);
  const x = (i) => pad.left + i * stepX;

  const path = (key) => series.map((s, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)} ${y(s[key]).toFixed(1)}`).join(' ');
  const viewsPath = path('views');
  const clicksPath = path('clicks');
  const areaPath = `${viewsPath} L${x(series.length - 1).toFixed(1)} ${h - pad.bottom} L${pad.left} ${h - pad.bottom} Z`;

  const gridLines = [0, 0.25, 0.5, 0.75, 1].map((t) => {
    const gy = h - pad.bottom - t * (h - pad.top - pad.bottom);
    return `<line x1="${pad.left}" y1="${gy}" x2="${w - pad.right}" y2="${gy}"/>
      <text class="chart-label" x="${pad.left - 8}" y="${gy + 3}" text-anchor="end">${Math.round(max * t)}</text>`;
  }).join('');

  const every = Math.ceil(series.length / 7);
  const xLabels = series.map((s, i) => (i % every === 0 || i === series.length - 1)
    ? `<text class="chart-label" x="${x(i)}" y="${h - 6}" text-anchor="middle">${esc(labels[i] ?? '')}</text>` : '').join('');

  const dots = series.map((s, i) => `
    <circle cx="${x(i)}" cy="${y(s.views)}" r="3" fill="#fff" stroke="#6b28d9" stroke-width="1.6">
      <title>${esc(labels[i] ?? '')}: ${formatNumber(s.views)} views, ${formatNumber(s.clicks)} clicks</title>
    </circle>`).join('');

  return `
  <svg class="chart-svg" viewBox="0 0 ${w} ${h}" role="img" aria-label="Views and clicks over time. Peak ${formatNumber(max)} views per day.">
    <defs>
      <linearGradient id="viewsFill" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#6b28d9" stop-opacity=".22"/>
        <stop offset="100%" stop-color="#6b28d9" stop-opacity="0"/>
      </linearGradient>
    </defs>
    <g class="chart-grid">${gridLines}</g>
    <path d="${areaPath}" fill="url(#viewsFill)"/>
    <path d="${viewsPath}" fill="none" stroke="#6b28d9" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/>
    <path d="${clicksPath}" fill="none" stroke="#2832a8" stroke-width="1.8" stroke-dasharray="4 4" stroke-linecap="round"/>
    ${dots}
    ${xLabels}
  </svg>`;
}

export function sparkline(values, { color = '#6b28d9', height = 44, width = 140 } = {}) {
  if (!values.length) return '';
  const max = Math.max(1, ...values);
  const min = Math.min(...values);
  const range = Math.max(1, max - min);
  const step = width / Math.max(1, values.length - 1);
  const pts = values.map((v, i) => `${(i * step).toFixed(1)},${(height - 4 - ((v - min) / range) * (height - 8)).toFixed(1)}`);
  return `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" aria-hidden="true" focusable="false">
    <polyline points="${pts.join(' ')}" fill="none" stroke="${color}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
}

export function qrCode(url) {
  return `<div class="qr">${qrSvg(url)}</div>`;
}

export function progressRing(pct, size = 46, stroke = 4) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return `<div class="ring" style="width:${size}px;height:${size}px">
    <svg width="${size}" height="${size}" aria-hidden="true">
      <circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="#e7e7e2" stroke-width="${stroke}"/>
      <circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="#6b28d9" stroke-width="${stroke}"
        stroke-dasharray="${c}" stroke-dashoffset="${c - (c * pct) / 100}" stroke-linecap="round"/>
    </svg>
    <span class="ring-label">${pct}%</span>
  </div>`;
}

export function emptyState({ title, body, actions = '', iconName = 'sparkles' }) {
  return `<div class="empty">
    <div class="empty-icon">${icon(iconName, 22)}</div>
    <p class="empty-title">${esc(title)}</p>
    <p class="empty-body">${esc(body)}</p>
    ${actions ? `<div class="empty-actions">${actions}</div>` : ''}
  </div>`;
}

export function copyToClipboard(text) {
  if (navigator.clipboard?.writeText) {
    return navigator.clipboard.writeText(text).catch(() => fallbackCopy(text));
  }
  return Promise.resolve(fallbackCopy(text));
}
function fallbackCopy(text) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); } catch { /* noop */ }
  ta.remove();
}
