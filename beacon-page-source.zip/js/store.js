/* Beacon Page — workspace state.
   The server (D1) is the source of truth for signed-in accounts; localStorage
   keeps a copy for instant interactivity and for the one-time migration of
   pages created before accounts existed. */
import { api } from './api.js';
import { toast } from './ui.js';

const DOC_KEY = 'beacon.doc.v2';
const SESSION_KEY = 'beacon.session.v2';
/* Pages created before accounts existed live under this key. They are read
   once, at sign-up, so a new account can keep the links it already had. */
const LEGACY_KEY = 'beacon.hub.v1';

export const uid = (prefix = 'id') =>
  `${prefix}_${Math.random().toString(36).slice(2, 9)}${Date.now().toString(36).slice(-3)}`;

export const clone = (value) => JSON.parse(JSON.stringify(value));

const THEME = {
  preset: 'Aurora',
  background: 'linear-gradient(165deg, #ece5ff 0%, #f8f4ff 48%, #eaf9d5 100%)',
  wallpaper: 'blob',
  buttonStyle: 'rounded',
  buttonColor: '#ffffff',
  fontFamily: 'Inter',
  textColor: '#1f1f1f',
  accentColor: '#6b28d9',
  decorations: ['sparkle'],
};

function defaultDoc() {
  return {
    profile: {
      displayName: '', bio: '', avatarUrl: '', socials: [],
      headerAlign: 'center', headerSpacing: 'cozy', showSocials: true, email: '',
    },
    theme: clone(THEME),
    blocks: [],
    archived: [],
    published: null,
    events: [],
    contacts: [],
    conversations: [],
    messaging: {
      configured: true,
      welcome: 'Thanks for reaching out! I read every message and usually reply within a couple of days.',
      tab: 'all',
      spotlight: null,
    },
    subscribe: {
      enabled: false,
      fields: ['email'],
      consentText: 'I agree to receive occasional emails from this creator.',
    },
    tools: {
      businessCard: {
        displayName: '', jobTitle: '', background: '#c7ff3f',
        showEmail: true, showPhone: false, showWebsite: true,
        email: '', phone: '', website: '',
      },
      mediaKit: { enabled: false, shareStats: true, contactEmail: '' },
    },
    settings: {
      notifications: { weeklyDigest: true, newContact: true, newMessage: true, productUpdates: false },
      integrations: { instagram: false, tiktok: false, youtube: false, spotify: false, mailchimp: false },
      plan: 'Starter',
      publicProfile: { showInSearch: true, showContactButton: true },
    },
    onboarding: { completed: [] },
    demoAnalytics: false,
    assistant: {
      open: false,
      messages: [
        { id: 'assistant_welcome', from: 'bot', text: 'Hi — I am Beacon Assist. I can point you to the right screen or explain how something works.' },
      ],
    },
    history: { past: [], future: [] },
  };
}

const isPlainObject = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value);

/** Merge a saved server document over the current defaults so older accounts
 *  pick up new fields without losing their content. */
export function mergeDoc(doc = {}) {
  const base = defaultDoc();
  const merged = { ...base, ...(isPlainObject(doc) ? doc : {}) };
  merged.profile = { ...base.profile, ...(doc.profile || {}) };
  merged.theme = { ...base.theme, ...(doc.theme || {}) };
  merged.messaging = { ...base.messaging, ...(doc.messaging || {}) };
  merged.subscribe = { ...base.subscribe, ...(doc.subscribe || {}) };
  merged.tools = {
    businessCard: { ...base.tools.businessCard, ...(doc.tools?.businessCard || {}) },
    mediaKit: { ...base.tools.mediaKit, ...(doc.tools?.mediaKit || {}) },
  };
  merged.settings = {
    ...base.settings,
    ...(doc.settings || {}),
    notifications: { ...base.settings.notifications, ...(doc.settings?.notifications || {}) },
    integrations: { ...base.settings.integrations, ...(doc.settings?.integrations || {}) },
    publicProfile: { ...base.settings.publicProfile, ...(doc.settings?.publicProfile || {}) },
  };
  merged.onboarding = { completed: [], ...(doc.onboarding || {}) };
  merged.blocks = Array.isArray(doc.blocks) ? doc.blocks.map((b) => ({ ...b, config: b.config || {} })) : [];
  merged.archived = Array.isArray(doc.archived) ? doc.archived : [];
  merged.contacts = (Array.isArray(doc.contacts) ? doc.contacts : []).map((c) => ({
    ...c, tags: Array.isArray(c.tags) ? c.tags : [],
  }));
  merged.conversations = Array.isArray(doc.conversations) ? doc.conversations : [];
  merged.events = Array.isArray(doc.events) ? doc.events : [];
  merged.published = doc.published || null;
  return merged;
}

export const State = {
  data: {
    ...defaultDoc(),
    session: null,
    account: null,
    workspace: { id: '', ownerId: '', name: '', handle: '', status: 'draft' },
  },
};

/* ------------------------------------------------------------------ */
/* persistence                                                         */
/* ------------------------------------------------------------------ */
export function workspaceSnapshot() {
  const { profile, theme, blocks, archived, published, events, contacts, conversations,
    messaging, subscribe, tools, settings, onboarding, demoAnalytics } = State.data;
  return {
    profile, theme, blocks, archived, published, events, contacts, conversations,
    messaging, subscribe, tools, settings, onboarding, demoAnalytics,
  };
}

function writeLocalCopy() {
  // The page lives on the server now, so nothing is cached in the browser.
  // Clear copies written by the pre-account version of the app.
  try {
    localStorage.removeItem(DOC_KEY);
    localStorage.removeItem(SESSION_KEY);
  } catch { /* storage blocked */ }
}

export function readLocalDoc() {
  try {
    const raw = localStorage.getItem(LEGACY_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return null;
    return { handle: parsed.workspace?.handle || '', doc: parsed };
  } catch {
    return null;
  }
}

export function clearLegacyDoc() {
  try { localStorage.removeItem(LEGACY_KEY); } catch { /* ignore */ }
}

export function hasLocalContent() {
  const cached = readLocalDoc();
  if (!cached) return false;
  return (cached.doc?.blocks?.length || 0) > 0 || (cached.doc?.contacts?.length || 0) > 0;
}

let syncTimer = null;
let syncing = false;
let syncQueued = false;
let lastSyncedAt = null;
let warnedOffline = false;

export function getSyncStatus() {
  return { syncing: Boolean(syncTimer) || syncing, lastSyncedAt };
}

async function pushToServer() {
  if (!State.data.session) return false;
  if (syncing) { syncQueued = true; return false; }
  syncing = true;
  const payload = {
    handle: State.data.workspace.handle,
    name: State.data.workspace.name,
    status: State.data.workspace.status,
    doc: workspaceSnapshot(),
  };
  try {
    await api.saveWorkspace(payload);
    lastSyncedAt = new Date().toISOString();
    warnedOffline = false;
    writeLocalCopy();
    return true;
  } catch (err) {
    if (!warnedOffline) {
      warnedOffline = true;
      toast('Could not save to the server — check your connection and try again.', 'error');
    }
    console.warn('Beacon: workspace sync failed', err?.message || err);
    return false;
  } finally {
    syncing = false;
    if (syncQueued) { syncQueued = false; pushToServer(); }
  }
}

/** Persist locally immediately, and to the server shortly after. */
export function save({ immediate = false } = {}) {
  writeLocalCopy();
  if (!State.data.session) return Promise.resolve(false);
  if (immediate) {
    clearTimeout(syncTimer);
    syncTimer = null;
    return pushToServer();
  }
  clearTimeout(syncTimer);
  syncTimer = setTimeout(() => {
    syncTimer = null;
    pushToServer();
  }, 700);
  return Promise.resolve(true);
}

export const syncNow = () => save({ immediate: true });

/* ------------------------------------------------------------------ */
/* session lifecycle                                                   */
/* ------------------------------------------------------------------ */
function dedupeEvents(local = [], remote = []) {
  const seen = new Set();
  const out = [];
  for (const event of [...local, ...remote]) {
    if (!event?.id || seen.has(event.id)) continue;
    seen.add(event.id);
    out.push(event);
  }
  return out.sort((a, b) => new Date(a.occurredAt) - new Date(b.occurredAt));
}

export function hydrateSession(payload, { adoptDoc = null } = {}) {
  const ws = payload.workspace || {};
  const doc = mergeDoc(adoptDoc || ws.doc || {});
  State.data = {
    ...doc,
    session: {
      id: payload.user.id,
      email: payload.user.email,
      name: payload.user.name,
      handle: payload.user.handle,
    },
    account: payload.user,
    workspace: {
      id: `ws_${payload.user.id}`,
      ownerId: payload.user.id,
      name: ws.name || payload.user.name,
      handle: ws.handle || payload.user.handle,
      status: ws.status || 'draft',
    },
  };
  State.data.events = dedupeEvents(doc.events, payload.events || []);
  lastSyncedAt = new Date().toISOString();
  writeLocalCopy();
}

export function clearSession() {
  State.data.session = null;
  State.data.account = null;
  try {
    localStorage.removeItem(SESSION_KEY);
  } catch { /* ignore */ }
}

export function setState(mutator) {
  mutator(State.data);
  save();
}

export const isAuthenticated = () => Boolean(State.data.session);
export const currentHandle = () => State.data.workspace.handle;

export function publicUrl(handle = currentHandle()) {
  return `${location.origin}${location.pathname}#/p/${handle}`;
}

export function hasUnpublishedChanges() {
  const { profile, theme, blocks, published } = State.data;
  if (!published) return true;
  return JSON.stringify({ profile, theme, blocks }) !== JSON.stringify({
    profile: published.profile, theme: published.theme, blocks: published.blocks,
  });
}

/* ------------------------------------------------------------------ */
/* draft history                                                       */
/* ------------------------------------------------------------------ */
export function snapshot() {
  const { profile, theme, blocks } = State.data;
  if (!State.data.history) State.data.history = { past: [], future: [] };
  const { history } = State.data;
  history.past.push(JSON.stringify({ profile, theme, blocks }));
  if (history.past.length > 50) history.past.shift();
  history.future = [];
}

function applySnapshot(serialized) {
  const parsed = JSON.parse(serialized);
  if (!parsed.profile || !parsed.blocks) return false;
  State.data.profile = parsed.profile;
  State.data.theme = parsed.theme;
  State.data.blocks = parsed.blocks;
  return true;
}

export function undo() {
  const history = State.data.history || { past: [], future: [] };
  State.data.history = history;
  if (!history.past.length) return false;
  const current = JSON.stringify({
    profile: State.data.profile, theme: State.data.theme, blocks: State.data.blocks,
  });
  const prev = history.past.pop();
  history.future.push(current);
  applySnapshot(prev);
  save();
  return true;
}

export function redo() {
  const history = State.data.history || { past: [], future: [] };
  State.data.history = history;
  if (!history.future.length) return false;
  const current = JSON.stringify({
    profile: State.data.profile, theme: State.data.theme, blocks: State.data.blocks,
  });
  const next = history.future.pop();
  history.past.push(current);
  applySnapshot(next);
  save();
  return true;
}

export async function publish() {
  const { profile, theme, blocks } = State.data;
  State.data.published = {
    profile: clone(profile), theme: clone(theme), blocks: clone(blocks),
    publishedAt: new Date().toISOString(),
  };
  State.data.workspace.status = 'published';
  await save({ immediate: true });
}

export function visibleBlocks(blocks = State.data.blocks) {
  const now = Date.now();
  return blocks
    .filter((b) => b.visible)
    .filter((b) => {
      if (!b.schedule) return true;
      const { start, end } = b.schedule;
      if (start && new Date(start).getTime() > now) return false;
      if (end && new Date(end).getTime() < now) return false;
      return true;
    })
    .sort((a, b) => a.position - b.position);
}

export function trackEvent(type, blockId = null) {
  State.data.events.push({
    id: uid('ev'), type, blockId, occurredAt: new Date().toISOString(),
    country: 'Unknown', device: window.innerWidth < 640 ? 'mobile' : 'desktop', referrer: 'direct',
  });
  save();
}

export function addContact({ name, email, phone = '', source }) {
  const exists = State.data.contacts.find((c) => c.email && c.email.toLowerCase() === String(email).toLowerCase());
  if (exists) return exists;
  const contact = {
    id: uid('ct'), name: name || '', email: email || '', phone,
    source, tags: [], createdAt: new Date().toISOString(), consentAt: new Date().toISOString(),
  };
  State.data.contacts.unshift(contact);
  save();
  return contact;
}

/* ------------------------------------------------------------------ */
/* sample analytics                                                    */
/* ------------------------------------------------------------------ */
let sampleSeed = 20261113;
function sampleRandom() {
  sampleSeed = (sampleSeed * 1664525 + 1013904223) % 4294967296;
  return sampleSeed / 4294967296;
}
const samplePick = (list) => list[Math.floor(sampleRandom() * list.length)];

/** Builds a readable sample series for the "Show sample data" affordance. */
export function generateSampleEvents(days = 30) {
  const sources = ['instagram', 'direct', 'tiktok', 'youtube', 'newsletter', 'google'];
  const countries = ['United States', 'United Kingdom', 'Germany', 'Portugal', 'Canada', 'Australia'];
  const devices = ['mobile', 'mobile', 'mobile', 'desktop', 'tablet'];
  const blocks = visibleBlocks();
  const events = [];
  for (let d = days - 1; d >= 0; d -= 1) {
    const date = new Date();
    date.setDate(date.getDate() - d);
    const views = 22 + Math.round(sampleRandom() * 55);
    for (let i = 0; i < views; i += 1) {
      const at = new Date(date);
      at.setHours(7 + Math.floor(sampleRandom() * 15), Math.floor(sampleRandom() * 60), 0, 0);
      events.push({
        id: uid('smpl'), type: 'view', blockId: null, occurredAt: at.toISOString(),
        country: samplePick(countries), device: samplePick(devices), referrer: samplePick(sources),
      });
    }
    const clicks = Math.round(views * (0.22 + sampleRandom() * 0.2));
    for (let i = 0; i < clicks; i += 1) {
      const at = new Date(date);
      at.setHours(7 + Math.floor(sampleRandom() * 15), Math.floor(sampleRandom() * 60), 0, 0);
      events.push({
        id: uid('smpl'), type: 'click', blockId: blocks.length ? samplePick(blocks).id : null,
        occurredAt: at.toISOString(), country: samplePick(countries),
        device: samplePick(devices), referrer: samplePick(sources),
      });
    }
  }
  return events;
}

/* ------------------------------------------------------------------ */
/* onboarding                                                          */
/* ------------------------------------------------------------------ */
export const ONBOARDING_STEPS = [
  { id: 'handle', title: 'Choose your handle', desc: 'Your public address.', route: '#/app/settings/profile' },
  { id: 'avatar', title: 'Upload a profile photo', desc: 'A face or a mark — either works.', route: '#/app/editor/header' },
  { id: 'firstLink', title: 'Add your first link', desc: 'Where should people go first?', route: '#/app/editor/content' },
  { id: 'theme', title: 'Pick a look', desc: 'Colors, wallpaper and button shape.', route: '#/app/editor/design' },
  { id: 'social', title: 'Connect a social account', desc: 'Show icons under your bio.', route: '#/app/editor/header' },
  { id: 'publish', title: 'Publish your page', desc: 'Make it live for the world.', route: '#/app/editor/content' },
];

export function onboardingProgress() {
  const completed = new Set(State.data.onboarding.completed || []);
  const steps = ONBOARDING_STEPS.map((s) => ({ ...s, done: completed.has(s.id) }));
  const done = steps.filter((s) => s.done).length;
  return { steps, done, total: steps.length, pct: Math.round((done / steps.length) * 100) };
}

export function completeStep(id) {
  const set = new Set(State.data.onboarding.completed || []);
  set.add(id);
  State.data.onboarding.completed = [...set];
  save();
}

export function resetDemo() {
  State.data = {
    ...State.data,
    ...defaultDoc(),
    session: State.data.session,
    account: State.data.account,
    workspace: State.data.workspace,
    history: { past: [], future: [] },
  };
  save({ immediate: true });
}

export function signOut() {
  clearSession();
  State.data = {
    ...defaultDoc(),
    session: null,
    account: null,
    workspace: { id: '', ownerId: '', name: '', handle: '', status: 'draft' },
    history: { past: [], future: [] },
  };
  try { localStorage.removeItem(DOC_KEY); } catch { /* ignore */ }
  writeLocalCopy();
}
