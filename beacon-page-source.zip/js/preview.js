/* Public profile rendering, shared by the live page, the phone preview and share cards. */
import { esc, icon, SOCIAL_ICON } from './ui.js';
import { visibleBlocks } from './store.js';

export const FONTS = {
  Inter: "'Inter', ui-sans-serif, system-ui, sans-serif",
  'DM Sans': "'DM Sans', ui-sans-serif, system-ui, sans-serif",
  'Space Grotesk': "'Space Grotesk', ui-sans-serif, system-ui, sans-serif",
  'Playfair Display': "'Playfair Display', Georgia, serif",
};

export const WALLPAPERS = [
  { id: 'none', label: 'Plain' },
  { id: 'blob', label: 'Glow' },
  { id: 'dots', label: 'Dots' },
  { id: 'grid', label: 'Grid' },
  { id: 'grain', label: 'Grain' },
];

export const BUTTON_STYLES = [
  { id: 'rounded', label: 'Rounded' },
  { id: 'pill', label: 'Pill' },
  { id: 'square', label: 'Square' },
  { id: 'outline', label: 'Outline' },
  { id: 'filled', label: 'Filled' },
];

export const DECOS = [
  { id: 'none', glyph: '', label: 'None' },
  { id: 'sparkle', glyph: '✦', label: 'Sparkle' },
  { id: 'star', glyph: '★', label: 'Star' },
  { id: 'heart', glyph: '♥', label: 'Heart' },
  { id: 'arrow', glyph: '➜', label: 'Arrow' },
];

export const PRESETS = [
  { id: 'Aurora', background: 'linear-gradient(165deg, #ece5ff 0%, #f8f4ff 48%, #eaf9d5 100%)', wallpaper: 'blob', textColor: '#1f1f1f', accentColor: '#6b28d9' },
  { id: 'Sunroom', background: 'linear-gradient(170deg, #fff3d6 0%, #ffe8c8 55%, #ffd9d0 100%)', wallpaper: 'none', textColor: '#2a1c0e', accentColor: '#b4550f' },
  { id: 'Nightshift', background: 'linear-gradient(165deg, #14121f 0%, #231b3d 55%, #14233a 100%)', wallpaper: 'grain', textColor: '#f6f5ff', accentColor: '#c7ff3f' },
  { id: 'Studio', background: 'linear-gradient(180deg, #ffffff 0%, #f2f2ee 100%)', wallpaper: 'grid', textColor: '#1f1f1f', accentColor: '#2832a8' },
  { id: 'Limeade', background: 'linear-gradient(160deg, #f2ffd6 0%, #e6fbc0 50%, #d5f7a8 100%)', wallpaper: 'dots', textColor: '#20300c', accentColor: '#3d6b0d' },
  { id: 'Rosewater', background: 'linear-gradient(165deg, #ffeef3 0%, #ffe3ec 55%, #f6e7ff 100%)', wallpaper: 'blob', textColor: '#31202a', accentColor: '#b02a6a' },
];

const THUMB_GRADIENTS = [
  'linear-gradient(135deg,#c7ff3f,#0f9f68)',
  'linear-gradient(135deg,#6b28d9,#2832a8)',
  'linear-gradient(135deg,#ffb199,#ff6a88)',
  'linear-gradient(135deg,#ffd36e,#b7791f)',
  'linear-gradient(135deg,#a8d8ff,#5a7dff)',
  'linear-gradient(135deg,#ffd6f5,#a8338f)',
];

const blockGradient = (id = '') => THUMB_GRADIENTS[[...id].reduce((a, c) => a + c.charCodeAt(0), 0) % THUMB_GRADIENTS.length];

function avatar(profile, cls = 'pub-avatar') {
  if (profile.avatarUrl) {
    return `<div class="${cls}"><img src="${esc(profile.avatarUrl)}" alt="${esc(profile.displayName)}" /></div>`;
  }
  const parts = (profile.displayName || 'B').trim().split(/\s+/).slice(0, 2);
  return `<div class="${cls}" aria-hidden="true">${esc(parts.map((p) => p[0]?.toUpperCase() || '').join(''))}</div>`;
}

function socialsRow(profile, accent) {
  if (!profile.showSocials || !profile.socials?.length) return '';
  return `<div class="pub-socials" style="--accent:${esc(accent)}">
    ${profile.socials.map((s) => `<a class="soc" href="${esc(s.url || '#')}" target="_blank" rel="noopener noreferrer"
      aria-label="${esc(s.platform)}" style="color:${esc(accent)}">${icon(SOCIAL_ICON[s.platform] || 'globe', 15)}</a>`).join('')}
  </div>`;
}

export function blockMarkup(block, theme, { live = false, index = 0 } = {}) {
  const styleClass = theme.buttonStyle === 'pill' ? 'pill'
    : theme.buttonStyle === 'square' ? 'square'
      : theme.buttonStyle === 'outline' ? 'outline'
        : theme.buttonStyle === 'filled' ? 'filled' : '';
  const action = (extra = '') => live ? `data-action="public-block" data-block-id="${esc(block.id)}" ${extra}` : 'tabindex="-1"';
  const track = live ? `data-track-block="${esc(block.id)}"` : '';
  const thumb = block.thumbUrl
    ? `<span class="pub-thumb"><img src="${esc(block.thumbUrl)}" alt="" /></span>`
    : '';
  const fallbackIcon = block.kind === 'product' ? 'bag'
    : block.kind === 'form' ? 'mail'
      : block.kind === 'message' ? 'send'
        : block.kind === 'social' ? 'globe'
          : 'link';
  const iconBox = block.iconUrl
    ? `<span class="pub-thumb"><img src="${esc(block.iconUrl)}" alt="" /></span>`
    : '';
  const description = block.description ? `<span class="pub-sub">${esc(block.description)}</span>` : '';

  switch (block.kind) {
    case 'text':
      return `<div class="pub-text-card">
        ${block.title ? `<strong style="display:block;margin-bottom:3px">${esc(block.title)}</strong>` : ''}
        ${esc(block.description || '')}
      </div>`;

    case 'divider':
      return '<div class="pub-divider" role="separator"></div>';

    case 'collection': {
      const items = block.config?.items || [];
      return `<details class="pub-collection">
        <summary>${esc(block.title || 'Collection')}${icon('chevronDown', 16)}</summary>
        <div class="items">
          ${items.length ? items.map((i) => `<a href="${esc(block.url || '#')}" ${live ? 'target="_blank" rel="noopener noreferrer"' : 'tabindex="-1"'} style="color:${esc(theme.textColor)}">${esc(i)}</a>`).join('') : '<span class="tiny" style="opacity:.6">No items yet</span>'}
        </div>
      </details>`;
    }

    case 'gallery': {
      const count = Math.min(6, Math.max(3, block.config?.images?.length || 3));
      return `<div>
        ${block.title ? `<p class="tiny" style="font-weight:600;margin-bottom:6px">${esc(block.title)}</p>` : ''}
        <div class="pub-gallery">${Array.from({ length: count }).map((_, i) => `<div style="background:${blockGradient(block.id + i)}"></div>`).join('')}</div>
      </div>`;
    }

    case 'video':
      return `<div>
        ${block.title ? `<p class="tiny" style="font-weight:600;margin-bottom:6px">${esc(block.title)}</p>` : ''}
        <a class="pub-video" ${live ? `href="${esc(block.url || '#')}" target="_blank" rel="noopener noreferrer"` : 'tabindex="-1"'}>
          <span style="display:grid;place-items:center;width:46px;height:46px;border-radius:50%;background:rgb(255 255 255 / .22);backdrop-filter:blur(4px)">${icon('play', 20)}</span>
        </a>
      </div>`;

    case 'social':
      return `<a class="pub-link ${styleClass}" ${live ? `href="${esc(block.url || '#')}" ${track} target="_blank" rel="noopener noreferrer"` : 'tabindex="-1"'}
        style="--btn-bg:${esc(theme.buttonColor)}">
        <span class="pub-thumb" style="background:${esc(theme.accentColor)};color:#fff">${icon(SOCIAL_ICON[block.config?.platform] || fallbackIcon, 18)}</span>
        <span class="pub-link-title">${esc(block.title)}${description}</span>
        ${icon('external', 15)}
      </a>`;

    case 'form':
      return `<button class="pub-link ${styleClass}" ${action()}
        style="--btn-bg:${esc(theme.buttonColor)};color:${esc(theme.textColor)}">
        ${iconBox || `<span class="pub-thumb" style="background:${esc(theme.accentColor)};color:#fff">${icon(fallbackIcon, 18)}</span>`}
        <span class="pub-link-title">${esc(block.title)}${description}</span>
        ${icon('chevronRight', 15)}
      </button>`;

    case 'message':
      return `<button class="pub-link ${styleClass}" ${action()}
        style="--btn-bg:${esc(theme.buttonColor)};color:${esc(theme.textColor)}">
        ${iconBox || `<span class="pub-thumb" style="background:${esc(theme.accentColor)};color:#fff">${icon('send', 17)}</span>`}
        <span class="pub-link-title">${esc(block.title)}${description}</span>
        ${icon('chevronRight', 15)}
      </button>`;

    case 'product':
      return `<a class="pub-link ${styleClass}" ${live ? `href="${esc(block.url || '#')}" ${track} target="_blank" rel="noopener noreferrer"` : 'tabindex="-1"'}
        style="--btn-bg:${esc(theme.buttonColor)};color:${esc(theme.textColor)}">
        ${thumb || `<span class="pub-thumb" style="background:${blockGradient(block.id)}"></span>`}
        <span class="pub-link-title">${esc(block.title)}${description}</span>
        ${block.config?.price ? `<span class="pub-price">${esc(block.config.price)}</span>` : ''}
        ${icon('bag', 16)}
      </a>`;

    default:
      return `<a class="pub-link ${styleClass}" ${live ? `href="${esc(block.url || '#')}" ${track} target="_blank" rel="noopener noreferrer"` : 'tabindex="-1"'}
        style="--btn-bg:${esc(theme.buttonColor)};color:${esc(theme.textColor)}">
        ${thumb || iconBox}
        <span class="pub-link-title">${esc(block.title || 'Untitled link')}${description}</span>
        ${icon('chevronRight', 15)}
      </a>`;
  }
}

export function profileContent(profile, theme, blocks, opts = {}) {
  const { live = false } = opts;
  const list = visibleBlocks(blocks);
  const deco = DECOS.find((d) => d.id === (theme.decorations?.[0] || 'none'));
  return `
    ${deco?.glyph ? `<span class="deco deco-1" style="color:${esc(theme.accentColor)}">${deco.glyph}</span>
      <span class="deco deco-2" style="color:${esc(theme.accentColor)}">${deco.glyph}</span>
      <span class="deco deco-3" style="color:${esc(theme.accentColor)}">${deco.glyph}</span>` : ''}
    <div class="pub-head ${profile.headerAlign === 'left' ? 'align-left' : ''}"
      style="padding-top:${profile.headerSpacing === 'roomy' ? '26px' : '10px'}">
      ${avatar(profile)}
      <div>
        <h1 class="pub-name">${esc(profile.displayName || 'Your name')}</h1>
      </div>
      ${profile.bio ? `<p class="pub-bio">${esc(profile.bio)}</p>` : ''}
      ${socialsRow(profile, theme.accentColor)}
    </div>
    <div class="pub-links">
      ${list.length
        ? list.map((b, i) => blockMarkup(b, theme, { live, index: i })).join('')
        : `<div class="pub-text-card" style="text-align:center">Nothing here yet — links you publish will show up in this space.</div>`}
    </div>
    <div class="pub-footer">${icon('sparkles', 12)} Built with Beacon</div>`;
}

export function publicScreen(profile, theme, blocks, { live = false, className = '' } = {}) {
  return `<div class="public-page wallpaper-${esc(theme.wallpaper || 'none')} ${className}"
    style="background:${esc(theme.background)};color:${esc(theme.textColor)};font-family:${FONTS[theme.fontFamily] || FONTS.Inter}">
    ${profileContent(profile, theme, blocks, { live })}
  </div>`;
}

export function phonePreview(profile, theme, blocks, { open = false } = {}) {
  return `<div class="phone">
    <div class="phone-inner" style="background:${esc(theme.background)}">
      <div class="phone-status" style="color:${esc(theme.textColor)}">
        <span>9:41</span><span>▮▮▮ ⌁</span>
      </div>
      <div class="phone-scroll">${publicScreen(profile, theme, blocks, { className: 'phone-screen' })}</div>
    </div>
  </div>`;
}
