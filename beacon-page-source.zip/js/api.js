/* Thin fetch wrapper for the Beacon Page API. Cookies carry the session. */

async function request(path, { method = 'GET', body } = {}) {
  const options = {
    method,
    credentials: 'same-origin',
    headers: { accept: 'application/json' },
  };
  if (body !== undefined) {
    options.headers['content-type'] = 'application/json';
    options.body = JSON.stringify(body);
  }
  const response = await fetch(path, options);
  let data = null;
  try { data = await response.json(); } catch { data = null; }
  if (!response.ok) {
    const error = new Error(data?.message || `Request failed (${response.status})`);
    error.status = response.status;
    error.code = data?.error || 'request_failed';
    throw error;
  }
  return data || {};
}

export const api = {
  session: () => request('/api/auth/session'),
  signIn: (email, password) => request('/api/auth/sign-in', { method: 'POST', body: { email, password } }),
  signUp: (payload) => request('/api/auth/sign-up', { method: 'POST', body: payload }),
  signOut: () => request('/api/auth/sign-out', { method: 'POST' }),
  reset: (email) => request('/api/auth/reset', { method: 'POST', body: { email } }),
  changePassword: (current, next) => request('/api/auth/password', { method: 'POST', body: { current, next } }),
  updateProfile: (name, email) => request('/api/auth/profile', { method: 'PATCH', body: { name, email } }),
  checkHandle: (handle) => request(`/api/handles/${encodeURIComponent(handle)}`),
  saveWorkspace: (payload) => request('/api/workspace', { method: 'PUT', body: payload }),
  getPublic: (handle) => request(`/api/public/${encodeURIComponent(handle)}`),
  publicEvent: (handle, payload) => request(`/api/public/${encodeURIComponent(handle)}/event`, { method: 'POST', body: payload }),
  publicContact: (handle, payload) => request(`/api/public/${encodeURIComponent(handle)}/contact`, { method: 'POST', body: payload }),
  deleteAccount: () => request('/api/account', { method: 'DELETE' }),
};
