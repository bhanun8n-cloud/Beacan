/* Dashboard home. */
import {
  State, hasUnpublishedChanges, publicUrl, onboardingProgress, visibleBlocks,
} from '../store.js';
import {
  esc, icon, greeting, prettyDate, formatNumber, compactNumber, sparkline, progressRing, timeAgo,
} from '../ui.js';

function series(days = 7) {
  const now = new Date();
  const buckets = Array.from({ length: days }, (_, i) => {
    const d = new Date(now);
    d.setDate(d.getDate() - (days - 1 - i));
    return { date: d, key: d.toISOString().slice(0, 10), views: 0, clicks: 0 };
  });
  const index = new Map(buckets.map((b) => [b.key, b]));
  for (const ev of State.data.events) {
    const key = new Date(ev.occurredAt).toISOString().slice(0, 10);
    const b = index.get(key);
    if (!b) continue;
    if (ev.type === 'view') b.views += 1;
    if (ev.type === 'click') b.clicks += 1;
  }
  return buckets;
}

export function dashboardView() {
  const { workspace, profile, contacts, conversations, published } = State.data;
  const { steps, done, total, pct } = onboardingProgress();
  const dirty = hasUnpublishedChanges();
  const week = series(7);
  const prevWeek = series(14).slice(0, 7);
  const sum = (arr, k) => arr.reduce((a, b) => a + b[k], 0);
  const views = sum(week, 'views');
  const clicks = sum(week, 'clicks');
  const prevViews = sum(prevWeek, 'views');
  const deltaPct = prevViews ? Math.round(((views - prevViews) / prevViews) * 100) : 0;
  const ctr = views ? Math.round((clicks / views) * 100) : 0;
  const newContacts = contacts.filter((c) => Date.now() - new Date(c.createdAt).getTime() < 7 * 864e5).length;
  const unread = conversations.reduce((a, c) => a + (c.unread || 0), 0);
  const links = visibleBlocks().length;
  const url = publicUrl(workspace.handle);
  const initials = (profile.displayName || 'B').split(/\s+/).slice(0, 2).map((p) => p[0]).join('');

  return `
  <div class="dash-hero">
    <div class="row between wrap gap-4">
      <div>
        <p class="small muted bold" style="letter-spacing:.04em;text-transform:uppercase">${esc(prettyDate())}</p>
        <h1 class="mt-2">${greeting()}, ${esc((profile.displayName || 'there').split(' ')[0])}.</h1>
        <p class="small muted mt-2">${dirty ? 'You have unpublished changes waiting.' : `Published ${published ? timeAgo(published.publishedAt) : 'not yet'} — your page is up to date.`}</p>
      </div>
      <div class="head-actions">
        <a class="btn btn-outline" href="#/p/${esc(workspace.handle)}" target="_blank" rel="noopener">${icon('eye', 16)} View page</a>
        <button class="btn btn-dark" data-action="share">${icon('share', 16)} Share</button>
        <a class="btn btn-primary" href="#/app/editor/content">${icon('link', 16)} Edit page</a>
      </div>
    </div>
  </div>

  <div class="card card-pad mb-4">
    <div class="profile-card">
      <div class="avatar-lg">${profile.avatarUrl ? `<img src="${esc(profile.avatarUrl)}" alt="" />` : esc(initials)}</div>
      <div class="grow" style="min-width:180px">
        <div class="row gap-2 wrap">
          <h2 style="font-size:17px;font-weight:700;letter-spacing:-.02em">${esc(profile.displayName)}</h2>
          ${workspace.status === 'published'
            ? '<span class="badge badge-live"><span class="dot"></span>Live</span>'
            : '<span class="badge badge-draft">Draft</span>'}
          ${dirty ? '<span class="badge badge-draft">Unpublished changes</span>' : ''}
        </div>
        <p class="small muted mt-2">beacon.page/p/${esc(workspace.handle)} · ${links} link${links === 1 ? '' : 's'} live</p>
        <div class="row gap-2 mt-3 wrap">
          <button class="btn btn-sm btn-outline" data-action="copy-url">${icon('copy', 14)} Copy link</button>
          <a class="btn btn-sm btn-ghost" href="#/app/editor/content">Manage links ${icon('chevronRight', 14)}</a>
          ${dirty ? '<button class="btn btn-sm btn-primary" data-action="publish">Publish changes</button>' : ''}
        </div>
      </div>
      <div style="width:100%;max-width:240px">
        <div class="row between small muted"><span>This week</span><strong style="color:var(--ink)">${formatNumber(views)} views</strong></div>
        <div class="mt-2">${sparkline(week.map((d) => d.views), { width: 240, height: 52 })}</div>
      </div>
    </div>
  </div>

  <div class="kpi-grid mb-4">
    <div class="kpi">
      <p class="kpi-label">${icon('eye', 14)} Profile views</p>
      <p class="kpi-value">${formatNumber(views)}</p>
      <p class="kpi-foot"><span class="delta ${deltaPct >= 0 ? 'up' : 'down'}">${deltaPct >= 0 ? '↑' : '↓'} ${Math.abs(deltaPct)}%</span> vs previous 7 days</p>
    </div>
    <div class="kpi">
      <p class="kpi-label">${icon('link', 14)} Link clicks</p>
      <p class="kpi-value">${formatNumber(clicks)}</p>
      <p class="kpi-foot">${ctr}% click-through rate</p>
    </div>
    <div class="kpi">
      <p class="kpi-label">${icon('users', 14)} New contacts</p>
      <p class="kpi-value">${formatNumber(newContacts)}</p>
      <p class="kpi-foot">${contacts.length} total in your audience</p>
    </div>
    <div class="kpi">
      <p class="kpi-label">${icon('message', 14)} Unread messages</p>
      <p class="kpi-value">${formatNumber(unread)}</p>
      <p class="kpi-foot"><a class="btn-link" href="#/app/messaging" style="text-decoration:none">Open inbox →</a></p>
    </div>
  </div>

  <div class="dash-grid">
    <div class="card card-pad">
      <div class="card-head">
        <div>
          <h2 class="card-title">Finish setting up</h2>
          <p class="card-sub">${done} of ${total} steps complete · ${pct}%</p>
        </div>
        ${progressRing(pct, 42, 4)}
      </div>
      <div class="checklist">
        ${steps.slice(0, 5).map((s) => `
          <div class="check-row ${s.done ? 'done' : ''}">
            <span class="check-mark">${icon('check', 12)}</span>
            <div class="grow"><p class="check-title">${esc(s.title)}</p><p class="check-sub">${esc(s.desc)}</p></div>
            ${s.done ? '' : `<a class="btn-link" href="${s.route}" style="text-decoration:none;font-size:12.5px">Open →</a>`}
          </div>`).join('')}
      </div>
      ${done < total ? `<a class="btn btn-primary btn-block mt-4" href="#/onboarding">Finish setup</a>`
        : `<a class="btn btn-outline btn-block mt-4" href="#/onboarding">Review setup</a>`}
    </div>

    <div class="col gap-4" style="gap:16px">
      <div class="card card-pad">
        <div class="card-head">
          <div><h2 class="card-title">Top links</h2><p class="card-sub">Last 7 days</p></div>
          <a class="btn-link" href="#/app/insights" style="text-decoration:none;font-size:12.5px">All insights</a>
        </div>
        ${topLinks(week)}
      </div>
      <div class="card card-pad">
        <div class="card-head"><div><h2 class="card-title">Recent activity</h2><p class="card-sub">Fresh from your page</p></div></div>
        <div class="col gap-3">
          ${recentActivity()}
        </div>
      </div>
    </div>
  </div>`;
}

function topLinks() {
  const cutoff = Date.now() - 7 * 864e5;
  const counts = new Map();
  for (const ev of State.data.events) {
    if (ev.type !== 'click' || new Date(ev.occurredAt).getTime() < cutoff) continue;
    counts.set(ev.blockId, (counts.get(ev.blockId) || 0) + 1);
  }
  const rows = [...counts.entries()]
    .map(([id, n]) => ({ block: State.data.blocks.find((b) => b.id === id), n }))
    .filter((r) => r.block)
    .sort((a, b) => b.n - a.n)
    .slice(0, 4);
  if (!rows.length) {
    return `<p class="small muted">No clicks in this period yet. Share your page to get the first one.</p>`;
  }
  const max = Math.max(...rows.map((r) => r.n));
  return `<div class="bar-list">
    ${rows.map((r) => `<div class="bar-row">
      <span class="truncate" title="${esc(r.block.title)}">${esc(r.block.title)}</span>
      <span class="bar-track"><span class="bar-fill" style="width:${Math.max(6, (r.n / max) * 100)}%"></span></span>
      <span class="bar-value">${formatNumber(r.n)}</span>
    </div>`).join('')}
  </div>`;
}

function recentActivity() {
  const items = [];
  const c = State.data.contacts[0];
  if (c) items.push({ icon: 'users', t: `${c.name} joined your audience`, s: `via ${c.source}`, at: c.createdAt });
  const conv = State.data.conversations[0];
  if (conv) items.push({ icon: 'message', t: `New message from ${conv.name}`, s: conv.messages.at(-1)?.text || '', at: conv.lastAt });
  if (State.data.published) items.push({ icon: 'sparkles', t: 'Page published', s: 'Design and links are live', at: State.data.published.publishedAt });
  const evt = State.data.events.at(-1);
  if (evt) items.push({ icon: 'eye', t: 'Profile viewed', s: `${evt.country} · ${evt.device}`, at: evt.occurredAt });
  return items.slice(0, 4).map((i) => `
    <div class="row gap-3">
      <span class="tool-icon" style="width:30px;height:30px;border-radius:9px;color:var(--brand-primary)">${icon(i.icon, 15)}</span>
      <div class="grow" style="min-width:0">
        <p class="small bold truncate">${esc(i.t)}</p>
        <p class="tiny muted truncate">${esc(i.s)}</p>
      </div>
      <span class="tiny muted" style="flex:none">${esc(timeAgo(i.at))}</span>
    </div>`).join('');
}
