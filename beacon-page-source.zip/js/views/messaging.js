/* Messaging inbox. */
import { State, save, uid } from '../store.js';
import { esc, icon, timeAgo, formatDateTime, toast, openModal, emptyState } from '../ui.js';

export const messagingUI = { activeId: State.data.conversations[0]?.id || null, q: '', tab: 'all', showConvo: false, filter: 'all' };

export function messagingView() {
  const { messaging, conversations } = State.data;
  const q = messagingUI.q.trim().toLowerCase();
  const filtered = conversations.filter((c) => {
    const matchesQ = !q || `${c.name} ${c.email}`.toLowerCase().includes(q) || c.messages.some((m) => m.text.toLowerCase().includes(q));
    if (messagingUI.filter === 'unread') return matchesQ && c.unread > 0;
    return matchesQ;
  });
  const active = conversations.find((c) => c.id === messagingUI.activeId) || null;

  return `
  <div class="page-head">
    <div>
      <h1 class="page-title">Messaging</h1>
      <p class="page-sub">One inbox for everyone who reaches out from your page.</p>
    </div>
    <div class="head-actions">
      <button class="btn btn-outline" data-action="configure-messaging">${icon('settings', 15)} Configure</button>
      <button class="btn btn-primary" data-action="edit-welcome">${icon('message', 15)} Welcome message</button>
    </div>
  </div>

  <div class="card card-pad mb-4 row between wrap gap-3" style="background:linear-gradient(110deg,#f6f2ff,#fbfbfa)">
    <div class="row gap-3">
      <span class="tool-icon" style="background:#fff;color:var(--brand-primary)">${icon('megaphone', 18)}</span>
      <div class="grow">
        <p class="small bold">Your welcome message</p>
        <p class="tiny muted" style="max-width:70ch">“${esc(messaging.welcome)}”</p>
      </div>
    </div>
    <button class="btn-link" data-action="edit-welcome" style="font-size:12.5px">Edit</button>
  </div>

  <div class="msg-shell ${messagingUI.showConvo ? 'convo-open' : ''}">
    <div class="msg-list">
      <div class="msg-list-head">
        <div class="row between">
          <div class="tabs" style="border:0;margin:0;gap:0">
            <button class="${messagingUI.tab === 'all' ? 'active' : ''}" data-action="msg-tab" data-tab="all" style="padding:6px 10px">All</button>
            <button class="${messagingUI.tab === 'stacks' ? 'active' : ''}" data-action="msg-tab" data-tab="stacks" style="padding:6px 10px">Stacks</button>
          </div>
          <button class="btn-icon" data-action="configure-messaging" aria-label="Inbox settings">${icon('filter', 16)}</button>
        </div>
        <div class="search-box mt-3">
          ${icon('search', 15)}
          <input class="input" placeholder="Search messages" value="${esc(messagingUI.q)}" data-input="msg-search" aria-label="Search messages" />
        </div>
        <div class="msg-filter">
          ${[['all', `All (${conversations.length})`], ['unread', `Unread (${conversations.reduce((a, c) => a + (c.unread || 0), 0)})`]].map(([id, label]) => `<button class="chip ${messagingUI.filter === id ? 'active' : ''}" data-action="msg-filter" data-filter="${id}" aria-pressed="${messagingUI.filter === id}">${label}</button>`).join('')}
        </div>
      </div>

      ${messagingUI.tab === 'stacks' ? `<div class="spotlight">
        <p class="tiny bold">${icon('star', 12)} Spotlight</p>
        <p class="tiny muted mt-1">Pin one message you want to see first. Currently: ${esc(conversations.find((c) => c.id === messaging.messaging?.spotlight)?.name || conversations.find((c) => c.id === messaging.spotlight)?.name || 'none')}</p>
      </div>` : ''}

      <div class="msg-items" id="msg-items">
        ${filtered.length ? filtered.map((c) => {
          const last = c.messages.at(-1);
          return `<button class="msg-item ${active?.id === c.id ? 'active' : ''}" data-action="open-conversation" data-id="${esc(c.id)}">
            <span class="avatar-sm" style="width:34px;height:34px">${esc((c.name || '?').slice(0, 1))}</span>
            <span class="grow" style="min-width:0">
              <span class="row between"><span class="who">${esc(c.name)}</span>${c.unread ? `<span class="badge badge-brand" style="padding:1px 6px">${c.unread}</span>` : ''}</span>
              <span class="preview">${esc(last?.text || 'No messages')}</span>
            </span>
            <span class="when">${esc(timeAgo(c.lastAt))}</span>
          </button>`;
        }).join('') : `<div style="padding:18px">
          ${emptyState({ title: 'No messages found', body: 'Try another search, or clear the unread filter.', iconName: 'search', actions: '<button class="btn btn-outline btn-sm" data-action="clear-msg-filters">Clear filters</button>' })}
        </div>`}
      </div>
    </div>

    ${active ? conversationPane(active) : welcomePane()}
  </div>

  <p class="tiny muted mt-3">Messages arrive from your public Message block. In this demo they are stored locally and never emailed.</p>`;
}

function conversationPane(convo) {
  return `<div class="msg-convo">
    <div class="msg-convo-head">
      <button class="btn-icon" data-action="back-to-list" aria-label="Back to messages" style="display:none" id="msg-back">${icon('arrowLeft', 18)}</button>
      <span class="avatar-sm" style="width:36px;height:36px">${esc((convo.name || '?').slice(0, 1))}</span>
      <div class="grow" style="min-width:0">
        <p class="small bold truncate">${esc(convo.name)}</p>
        <p class="tiny muted truncate">${esc(convo.email)}</p>
      </div>
      <button class="btn-icon" data-action="msg-details" data-id="${esc(convo.id)}" aria-label="Conversation details">${icon('info', 17)}</button>
    </div>
    <div class="msg-bubbles">
      ${convo.messages.map((m) => `<div class="msg-bubble ${m.from === 'us' ? 'us' : 'them'}">
        ${esc(m.text)}
        <span class="time">${esc(formatDateTime(m.at))}</span>
      </div>`).join('')}
    </div>
    <form class="msg-compose" data-form="compose" data-convo-id="${esc(convo.id)}">
      <input class="input" name="message" placeholder="Write a reply…" aria-label="Reply message" autocomplete="off" required />
      <button class="btn btn-primary" type="submit" aria-label="Send reply">${icon('send', 16)}</button>
    </form>
  </div>`;
}

function welcomePane() {
  return `<div class="msg-convo" style="justify-content:center;align-items:center;padding:30px;text-align:center;background:#fbfbfa">
    <div class="empty-icon" style="width:60px;height:60px;border-radius:18px;color:var(--brand-primary);background:#fff">${icon('message', 26)}</div>
    <h2 style="font-size:18px;margin-top:14px">Welcome to your inbox</h2>
    <p class="small muted mt-2" style="max-width:38ch">Pick a conversation on the left. Visitors reach you through the Message block on your page, and every thread stays here.</p>
    <div class="row gap-2 mt-4 wrap" style="justify-content:center">
      <button class="btn btn-outline btn-sm" data-action="edit-welcome">Set a welcome message</button>
      <a class="btn btn-outline btn-sm" href="#/app/editor/content">Add a message block</a>
    </div>
  </div>`;
}

export function refreshMessageList() {
  const box = document.getElementById('msg-items');
  if (!box) return;
  const q = messagingUI.q.trim().toLowerCase();
  const list = State.data.conversations.filter((c) => {
    const matches = !q || `${c.name} ${c.email}`.toLowerCase().includes(q) || c.messages.some((m) => m.text.toLowerCase().includes(q));
    return messagingUI.filter === 'unread' ? matches && c.unread > 0 : matches;
  });
  box.innerHTML = list.length ? list.map((c) => {
    const last = c.messages.at(-1);
    return `<button class="msg-item ${messagingUI.activeId === c.id ? 'active' : ''}" data-action="open-conversation" data-id="${esc(c.id)}">
      <span class="avatar-sm" style="width:34px;height:34px">${esc((c.name || '?').slice(0, 1))}</span>
      <span class="grow" style="min-width:0">
        <span class="row between"><span class="who">${esc(c.name)}</span>${c.unread ? `<span class="badge badge-brand" style="padding:1px 6px">${c.unread}</span>` : ''}</span>
        <span class="preview">${esc(last?.text || 'No messages')}</span>
      </span>
      <span class="when">${esc(timeAgo(c.lastAt))}</span>
    </button>`;
  }).join('') : `<div style="padding:18px">${emptyState({ title: 'No messages found', body: 'Try another search or clear the filter.', iconName: 'search', actions: '<button class="btn btn-outline btn-sm" data-action="clear-msg-filters">Clear filters</button>' })}</div>`;
}

export function configureModal() {
  const m = State.data.messaging;
  openModal({
    title: 'Configure messaging',
    subtitle: 'Control what visitors see before they write.',
    body: `<form data-form="messaging-config" id="msg-config-form">
      <div class="row between mb-4">
        <div><p class="field-label">Accept messages</p><p class="field-hint">Turn off to hide the Message block from your page.</p></div>
        <label class="switch"><input type="checkbox" name="configured" ${m.configured ? 'checked' : ''} aria-label="Accept messages" /><span></span></label>
      </div>
      <div class="field">
        <label class="field-label" for="welcome-msg">Welcome message</label>
        <textarea class="textarea" id="welcome-msg" name="welcome" maxlength="240">${esc(m.welcome)}</textarea>
        <span class="field-hint">Shown at the top of the message form.</span>
      </div>
      <div class="field">
        <label class="field-label" for="reply-to">Replies go to</label>
        <input class="input" id="reply-to" name="replyTo" type="email" value="${esc(State.data.profile.email || '')}" />
      </div>
      <div class="row between">
        <div><p class="field-label">Require email</p><p class="field-hint">Keeps threads reachable.</p></div>
        <label class="switch"><input type="checkbox" checked disabled aria-label="Require email" /><span></span></label>
      </div>
    </form>`,
    footer: '<button class="btn btn-outline" data-action="modal-close">Cancel</button><button class="btn btn-primary" data-action="save-messaging">Save settings</button>',
  });
}

export function welcomeModal() {
  const m = State.data.messaging;
  openModal({
    title: 'Welcome message',
    subtitle: 'The first thing someone reads in the message form.',
    body: `<form data-form="welcome" id="welcome-form">
      <div class="field" style="margin-bottom:0">
        <label class="field-label" for="welcome-text">Message</label>
        <textarea class="textarea" id="welcome-text" name="welcome" maxlength="240" data-autofocus>${esc(m.welcome)}</textarea>
        <span class="field-hint">Keep it short and warm — 240 characters max.</span>
      </div>
    </form>`,
    footer: '<button class="btn btn-outline" data-action="modal-close">Cancel</button><button class="btn btn-primary" data-action="save-welcome">Save message</button>',
  });
}

export function threadDetails(id) {
  const c = State.data.conversations.find((x) => x.id === id);
  if (!c) return;
  openModal({
    title: c.name,
    subtitle: c.email,
    body: `<div class="col gap-3 small">
      <div class="soft-card"><p class="tiny muted bold" style="text-transform:uppercase;letter-spacing:.05em">Conversation</p>
        <p class="mt-2">${c.messages.length} messages · started ${esc(formatDateTime(c.messages[0].at))}</p></div>
      <div><p class="field-label">Email</p><p class="small">${esc(c.email)}</p></div>
      <div><p class="field-label">Source</p><p class="small">Message block on your public page</p></div>
    </div>`,
    footer: `<button class="btn btn-danger btn-sm" style="margin-right:auto" data-action="delete-conversation" data-id="${esc(c.id)}">${icon('trash', 14)} Delete thread</button>
      <button class="btn btn-primary" data-action="modal-close">Done</button>`,
  });
}

export function sendReply(convoId, text) {
  const convo = State.data.conversations.find((c) => c.id === convoId);
  if (!convo || !text.trim()) return;
  convo.messages.push({ id: uid('m'), from: 'us', text: text.trim(), at: new Date().toISOString() });
  convo.lastAt = new Date().toISOString();
  convo.unread = 0;
  save();
}
