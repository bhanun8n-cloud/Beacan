/* Insights: analytics with date range, chart, sources, geography, devices, lifetime. */
import { State, save, visibleBlocks } from '../store.js';
import {
  esc, icon, formatNumber, compactNumber, areaChart, emptyState, toast, formatDate,
} from '../ui.js';

export const insightsUI = { range: 7 };

const RANGES = [
  { id: 7, label: 'Last 7 days' },
  { id: 30, label: 'Last 30 days' },
  { id: 90, label: 'Last 90 days' },
];

function eventsInRange(days) {
  if (!State.data.demoAnalytics) return [];
  const from = Date.now() - days * 864e5;
  return State.data.events.filter((e) => new Date(e.occurredAt).getTime() >= from);
}

function dailySeries(days) {
  const buckets = Array.from({ length: days }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (days - 1 - i));
    return { date: d, key: d.toISOString().slice(0, 10), views: 0, clicks: 0 };
  });
  const index = new Map(buckets.map((b) => [b.key, b]));
  for (const ev of eventsInRange(days)) {
    const b = index.get(new Date(ev.occurredAt).toISOString().slice(0, 10));
    if (!b) continue;
    if (ev.type === 'view') b.views += 1;
    if (ev.type === 'click') b.clicks += 1;
  }
  return buckets;
}

const groupCount = (list, key, value) => {
  const map = new Map();
  for (const item of list) map.set(item[key] || 'Unknown', (map.get(item[key] || 'Unknown') || 0) + 1);
  return [...map.entries()].sort((a, b) => b[1] - a[1]);
};

export function insightsView() {
  const days = insightsUI.range;
  const events = eventsInRange(days);
  const prevEvents = State.data.demoAnalytics
    ? State.data.events.filter((e) => {
      const t = new Date(e.occurredAt).getTime();
      return t >= Date.now() - days * 2 * 864e5 && t < Date.now() - days * 864e5;
    })
    : [];
  const views = events.filter((e) => e.type === 'view').length;
  const clicks = events.filter((e) => e.type === 'click').length;
  const contacts = events.filter((e) => e.type === 'contact').length;
  const prevViews = prevEvents.filter((e) => e.type === 'view').length;
  const delta = prevViews ? Math.round(((views - prevViews) / prevViews) * 100) : 0;
  const ctr = views ? (clicks / views) * 100 : 0;
  const series = dailySeries(days);
  const labels = series.map((s) => formatDate(s.date, { month: 'short', day: 'numeric' }));
  const empty = !State.data.demoAnalytics || events.length === 0;

  return `
  <div class="page-head">
    <div>
      <h1 class="page-title">Insights</h1>
      <p class="page-sub">What people do when they land on your page. All numbers are local to this demo workspace.</p>
    </div>
    <div class="head-actions">
      <div class="range-picker" role="group" aria-label="Date range">
        ${RANGES.map((r) => `<button class="chip ${insightsUI.range === r.id ? 'active' : ''}" data-action="set-range" data-range="${r.id}" aria-pressed="${insightsUI.range === r.id}">${r.id === 7 ? '7 days' : r.id === 30 ? '30 days' : '90 days'}</button>`).join('')}
      </div>
      <button class="btn-icon" data-action="insights-info" aria-label="About these numbers" title="About these numbers">${icon('info', 18)}</button>
    </div>
  </div>

  ${State.data.demoAnalytics ? '' : `<div class="card card-pad mb-4 row between wrap gap-3">
      <div><p class="bold small">Sample data is hidden</p><p class="tiny muted">Charts will stay empty until traffic arrives or you turn sample data back on.</p></div>
      <button class="btn btn-outline btn-sm" data-action="toggle-sample">${icon('eye', 14)} Show sample data</button>
    </div>`}

  <div class="kpi-grid mb-4">
    ${kpi('Profile views', formatNumber(views), `${delta >= 0 ? '↑' : '↓'} ${Math.abs(delta)}% vs previous period`, delta >= 0, 'eye')}
    ${kpi('Link clicks', formatNumber(clicks), `${ctr.toFixed(1)}% click-through rate`, true, 'link')}
    ${kpi('New contacts', formatNumber(contacts), `${State.data.contacts.length} lifetime contacts`, true, 'users')}
    ${kpi('Shares', formatNumber(Math.max(0, Math.round(views * 0.03))), 'People passing your page along', true, 'share')}
  </div>

  <section class="card chart-card mb-4">
    <div class="card-head">
      <div>
        <h2 class="card-title">Activity</h2>
        <p class="card-sub">Views and clicks · ${RANGES.find((r) => r.id === days).label.toLowerCase()}</p>
      </div>
      <div class="chart-legend">
        <span><span class="sw" style="background:#6b28d9"></span>Views</span>
        <span><span class="sw" style="background:#2832a8"></span>Clicks</span>
      </div>
    </div>
    ${empty ? emptyState({
      title: 'No activity yet',
      body: 'Once someone visits your page, views and clicks show up here within seconds.',
      iconName: 'chart',
      actions: `<button class="btn btn-primary btn-sm" data-action="toggle-sample">Show sample data</button>
        <button class="btn btn-outline btn-sm" data-action="copy-url">Share your page</button>`,
    }) : `<div class="chart-wrap">${areaChart(series, { labels, height: 230 })}</div>
      <table class="sr-only">
        <caption>Views and clicks per day</caption>
        <thead><tr><th>Date</th><th>Views</th><th>Clicks</th></tr></thead>
        <tbody>${series.map((s) => `<tr><td>${formatDate(s.date)}</td><td>${s.views}</td><td>${s.clicks}</td></tr>`).join('')}</tbody>
      </table>`}
  </section>

  <div class="insight-grid">
    <section class="card card-pad">
      <div class="card-head"><div><h2 class="card-title">Traffic sources</h2><p class="card-sub">Where visitors come from</p></div></div>
      ${empty ? emptyMini('No sources yet') : barList(groupCount(events.filter((e) => e.type === 'view'), 'referrer').slice(0, 5), ['#6b28d9', '#7c46e0', '#9a72ea', '#b79cf0', '#d4c2f6'])}
    </section>

    <section class="card card-pad">
      <div class="card-head"><div><h2 class="card-title">Top links</h2><p class="card-sub">Clicks per block</p></div>
        <button class="btn-icon" data-action="share" aria-label="Share page">${icon('share', 16)}</button>
      </div>
      ${empty ? emptyMini('No clicks yet') : topLinks(events)}
    </section>

    <section class="card card-pad">
      <div class="card-head"><div><h2 class="card-title">Audience</h2><p class="card-sub">Top countries</p></div></div>
      ${empty ? emptyMini('No geography yet') : barList(groupCount(events.filter((e) => e.type === 'view'), 'country').slice(0, 5), ['#2832a8', '#3b46c4', '#5d68d6', '#8790e4', '#b1b7ef'])}
    </section>

    <section class="card card-pad">
      <div class="card-head"><div><h2 class="card-title">Devices</h2><p class="card-sub">How people browse</p></div></div>
      ${empty ? emptyMini('No device data yet') : deviceBreakdown(events)}
    </section>
  </div>

  <section class="card card-pad mt-4">
    <div class="card-head"><div><h2 class="card-title">Lifetime totals</h2><p class="card-sub">Since you created this page</p></div>
      <span class="badge">All time</span></div>
    <div class="lifetime">
      <div><p class="tiny muted bold" style="text-transform:uppercase;letter-spacing:.06em">Views</p><p class="v">${formatNumber(State.data.events.filter((e) => e.type === 'view').length)}</p></div>
      <div><p class="tiny muted bold" style="text-transform:uppercase;letter-spacing:.06em">Clicks</p><p class="v">${formatNumber(State.data.events.filter((e) => e.type === 'click').length)}</p></div>
      <div><p class="tiny muted bold" style="text-transform:uppercase;letter-spacing:.06em">Contacts</p><p class="v">${formatNumber(State.data.contacts.length)}</p></div>
    </div>
    <hr class="divider-line" />
    <div class="row between wrap gap-3">
      <p class="small muted">Want richer numbers? Connect a social account or add a subscribe form.</p>
      <div class="row gap-2">
        <a class="btn btn-outline btn-sm" href="#/app/audience">Audience tools</a>
        <a class="btn btn-outline btn-sm" href="#/app/audience/integrations">Connect a source</a>
      </div>
    </div>
  </section>`;
}

function kpi(label, value, foot, positive, iconName) {
  return `<div class="kpi">
    <p class="kpi-label">${icon(iconName, 14)} ${esc(label)}</p>
    <p class="kpi-value">${esc(value)}</p>
    <p class="kpi-foot">${foot.includes('↑') || foot.includes('↓') ? `<span class="delta ${positive ? 'up' : 'down'}">${esc(foot.split(' ').slice(0, 2).join(' '))}</span> ${esc(foot.split(' ').slice(2).join(' '))}` : esc(foot)}</p>
  </div>`;
}

function barList(entries, colors = []) {
  if (!entries.length) return `<p class="small muted">Nothing here yet.</p>`;
  const max = Math.max(...entries.map((e) => e[1]));
  return `<div class="bar-list">
    ${entries.map(([name, n], i) => `<div class="bar-row">
      <span class="truncate" title="${esc(name)}">${esc(name)}</span>
      <span class="bar-track"><span class="bar-fill" style="width:${Math.max(5, (n / max) * 100)}%;background:${colors[i] || '#6b28d9'}"></span></span>
      <span class="bar-value">${formatNumber(n)}</span>
    </div>`).join('')}
  </div>`;
}

function topLinks(events) {
  const counts = new Map();
  for (const ev of events) {
    if (ev.type !== 'click') continue;
    counts.set(ev.blockId, (counts.get(ev.blockId) || 0) + 1);
  }
  const blocks = visibleBlocks(State.data.blocks);
  const rows = [...counts.entries()]
    .map(([id, n]) => [blocks.find((b) => b.id === id)?.title || State.data.blocks.find((b) => b.id === id)?.title || 'Removed block', n])
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);
  if (!rows.length) return `<p class="small muted">No clicks in this period.</p>`;
  return `<div class="bar-list">
    ${rows.map(([title, n]) => `<div class="row between gap-3" style="padding:6px 0">
      <span class="small truncate">${esc(title)}</span>
      <span class="badge">${formatNumber(n)} clicks</span>
    </div>`).join('')}
  </div>`;
}

function deviceBreakdown(events) {
  const groups = groupCount(events.filter((e) => e.type === 'view'), 'device');
  const total = groups.reduce((a, [, n]) => a + n, 0) || 1;
  if (!groups.length) return `<p class="small muted">No device data yet.</p>`;
  return `<div class="col gap-3">
    ${groups.map(([device, n]) => `<div>
      <div class="row between small"><span style="text-transform:capitalize">${esc(device)}</span><span class="muted">${Math.round((n / total) * 100)}%</span></div>
      <div class="bar-track mt-2"><div class="bar-fill" style="width:${(n / total) * 100}%"></div></div>
    </div>`).join('')}
  </div>`;
}

function emptyMini(title) {
  return `<div class="soft-card" style="text-align:center;padding:24px">
    <p class="small bold">${esc(title)}</p>
    <p class="tiny muted mt-2">Share your page to start collecting data.</p>
    <button class="btn btn-outline btn-sm mt-3" data-action="toggle-sample">Show sample data</button>
  </div>`;
}

export function insightsInfoModal() {
  import('../ui.js').then(({ openModal }) => {
    openModal({
      title: 'How these numbers work',
      body: `<div class="col gap-3 small">
        <p><strong>Views</strong> count every time your public page loads. <strong>Clicks</strong> count taps on any block.</p>
        <p><strong>Contacts</strong> are people who submitted a form or messaged you.</p>
        <p>Views and link taps are recorded by Beacon’s server for your page only. No third-party tracking scripts are loaded.</p>
      </div>`,
      footer: '<button class="btn btn-primary" data-action="modal-close">Got it</button>',
    });
  });
}

export function setRange(range) {
  insightsUI.range = Number(range);
  save();
}
