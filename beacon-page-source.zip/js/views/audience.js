/* Audience: contacts, acquisition tools and integrations. */
import { State, save, addContact } from '../store.js';
import { esc, icon, emptyState, formatDate, toast, openModal } from '../ui.js';

export const audienceUI = {
  q: '', source: 'all', page: 1, perPage: 8, tab: 'contacts',
  selected: new Set(),
};

const TOOLS = [
  { id: 'form', title: 'Contact form', desc: 'A simple way for brands and listeners to reach you.', icon: 'form', action: 'tool-form' },
  { id: 'download', title: 'Digital download', desc: 'Trade a preset or PDF for an email address.', icon: 'download', action: 'tool-download' },
  { id: 'booking', title: 'Bookings', desc: 'Let people book a shoot or a call.', icon: 'calendar', action: 'tool-soon' },
  { id: 'discount', title: 'Discount code', desc: 'Hand out a code and track who used it.', icon: 'ticket', action: 'tool-soon' },
  { id: 'gated', title: 'Gated content', desc: 'Keep a page or video behind a signup.', icon: 'lock', action: 'tool-soon' },
  { id: 'course', title: 'Course', desc: 'Sell a small class with lessons and files.', icon: 'book', action: 'tool-soon' },
  { id: 'community', title: 'Community invite', desc: 'Send people straight into your group chat.', icon: 'invite', action: 'tool-soon' },
];

const INTEGRATIONS = [
  { id: 'instagram', name: 'Instagram', desc: 'Sync profile info and see which posts send traffic.', icon: 'instagram' },
  { id: 'tiktok', name: 'TikTok', desc: 'Attribute visits from your bio link.', icon: 'tiktok' },
  { id: 'youtube', name: 'YouTube', desc: 'Track clicks from video descriptions.', icon: 'youtube' },
  { id: 'spotify', name: 'Spotify', desc: 'Show your latest release automatically.', icon: 'spotify' },
  { id: 'mailchimp', name: 'Mailchimp', desc: 'Push new contacts into an existing audience.', icon: 'mail' },
];

export function audienceView(tab = 'contacts') {
  audienceUI.tab = tab;
  if (tab === 'integrations') return integrationsView();
  return contactsView();
}

function tabs(active) {
  return `<nav class="tabs" aria-label="Audience sections">
    <a href="#/app/audience" class="${active === 'contacts' ? 'active' : ''}">Contacts <span class="count">${State.data.contacts.length}</span></a>
    <a href="#/app/audience/integrations" class="${active === 'integrations' ? 'active' : ''}">Integrations</a>
  </nav>`;
}

function contactsView() {
  const { subscribe, contacts } = State.data;
  return `
  <div class="page-head">
    <div>
      <h1 class="page-title">Audience</h1>
      <p class="page-sub">Everyone who asked to hear from you — plus the tools that bring them in.</p>
    </div>
    <div class="head-actions">
      <button class="btn btn-outline" data-action="export-contacts">${icon('download', 15)} Export CSV</button>
      <button class="btn btn-primary" data-action="add-contact">${icon('plus', 15)} Add contact</button>
    </div>
  </div>
  ${tabs('contacts')}

  ${!subscribe.enabled ? `
  <section class="promo-card mb-4">
    <div class="row gap-5 wrap">
      <div class="grow" style="min-width:260px">
        <span class="badge badge-brand mb-2">${icon('sparkles', 12)} Not activated</span>
        <h2>Turn visitors into an audience you own</h2>
        <p class="small muted mt-2" style="max-width:56ch">Add a signup block to your page and every new subscriber lands here — with consent recorded and export ready.</p>
        <div class="row gap-2 mt-3 wrap">
          <button class="btn btn-primary" data-action="activate-subscribe">Activate subscribe</button>
          <button class="btn btn-outline" data-action="preview-subscribe">Preview the form</button>
        </div>
      </div>
      <div class="promo-art">${icon('users', 40)}</div>
    </div>
  </section>` : `
  <section class="card card-pad mb-4 row between wrap gap-3">
    <div class="row gap-3">
      <span class="tool-icon" style="background:#e9f8f0;color:var(--success)">${icon('checkCircle', 18)}</span>
      <div><p class="bold small">Subscribe is live</p><p class="tiny muted">${subscribe.fields.join(', ')} collected · consent text shown on your page</p></div>
    </div>
    <div class="row gap-2">
      <button class="btn btn-outline btn-sm" data-action="preview-subscribe">Preview form</button>
      <button class="btn btn-ghost btn-sm" data-action="disable-subscribe">Turn off</button>
    </div>
  </section>`}

  <section class="card card-pad mb-4">
    <div class="card-head"><div><h2 class="card-title">Ways to grow</h2><p class="card-sub">Each tool publishes as a block on your page.</p></div></div>
    <div class="tool-grid">
      ${TOOLS.map((t) => `<div class="tool-card">
        <span class="tool-icon">${icon(t.icon, 18)}</span>
        <h3>${esc(t.title)}</h3>
        <p>${esc(t.desc)}</p>
        <button class="btn-link" style="text-align:left;margin-top:auto;font-size:12.5px" data-action="${t.action}">Set up →</button>
      </div>`).join('')}
    </div>
  </section>

  <section class="card card-pad">
    <div class="card-head"><div><h2 class="card-title">Contacts</h2><p class="card-sub">Search, filter and export your list.</p></div></div>
    <div class="table-toolbar">
      <div class="search-box grow" style="max-width:300px">
        ${icon('search', 16)}
        <input class="input" placeholder="Search name or email" value="${esc(audienceUI.q)}" data-input="contact-search" aria-label="Search contacts" />
      </div>
      <select class="select" style="max-width:190px" data-input="contact-source" aria-label="Filter by source">
        <option value="all">All sources</option>
        ${[...new Set(State.data.contacts.map((c) => c.source))].map((s) => `<option value="${esc(s)}" ${audienceUI.source === s ? 'selected' : ''}>${esc(s)}</option>`).join('')}
      </select>
      <span class="tiny muted" id="contact-count">${contacts.length} contacts</span>
    </div>
    <div id="contacts-region">${contactsTable()}</div>
  </section>`;
}

export function filteredContacts() {
  const q = audienceUI.q.trim().toLowerCase();
  return State.data.contacts
    .filter((c) => audienceUI.source === 'all' || c.source === audienceUI.source)
    .filter((c) => !q || `${c.name} ${c.email} ${c.phone} ${(c.tags || []).join(' ')}`.toLowerCase().includes(q));
}

export function allTags() {
  return [...new Set(State.data.contacts.flatMap((c) => c.tags || []))].sort((a, b) => a.localeCompare(b));
}

function pruneSelection() {
  const existing = new Set(State.data.contacts.map((c) => c.id));
  audienceUI.selected = new Set([...audienceUI.selected].filter((id) => existing.has(id)));
  return audienceUI.selected;
}

function bulkBar(selected) {
  const n = selected.size;
  if (!n) {
    return `<div class="bulk-bar is-empty" aria-hidden="true">
      <p class="tiny muted">Select contacts to tag or delete them in one go.</p>
    </div>`;
  }
  return `<div class="bulk-bar" role="region" aria-label="Bulk actions" aria-live="polite">
    <p class="small bold" style="margin:0">${n} selected</p>
    <div class="row gap-2 wrap" style="margin-left:auto">
      <button class="btn btn-sm btn-outline" data-action="bulk-tag">${icon('plus', 14)} Tag ${n}</button>
      <button class="btn btn-sm btn-danger" data-action="bulk-delete">${icon('trash', 14)} Delete ${n}</button>
      <button class="btn btn-sm btn-ghost" data-action="bulk-clear">Clear</button>
    </div>
  </div>`;
}

export function contactsTable() {
  const selected = pruneSelection();
  const filtered = filteredContacts();
  const pages = Math.max(1, Math.ceil(filtered.length / audienceUI.perPage));
  const page = Math.min(audienceUI.page, pages);
  const slice = filtered.slice((page - 1) * audienceUI.perPage, page * audienceUI.perPage);

  if (!State.data.contacts.length) {
    return emptyState({
      title: 'No contacts yet',
      body: 'When someone subscribes or sends a message, they appear here with the source and consent date.',
      iconName: 'users',
      actions: '<button class="btn btn-primary btn-sm" data-action="activate-subscribe">Activate subscribe</button>',
    });
  }
  if (!filtered.length) {
    return emptyState({
      title: 'No contacts match',
      body: 'Try a different search, or clear the source filter.',
      iconName: 'search',
      actions: '<button class="btn btn-outline btn-sm" data-action="clear-contact-filters">Clear filters</button>',
    });
  }

  const allMatchingSelected = filtered.every((c) => selected.has(c.id));
  return `
    ${bulkBar(selected)}
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr>
          <th class="sel-cell">
            <input type="checkbox" data-select="all" aria-label="Select all ${filtered.length} matching contacts" ${allMatchingSelected ? 'checked' : ''} />
          </th>
          <th>Name</th><th>Email</th><th>Source</th><th>Tags</th><th>Consent</th><th><span class="sr-only">Actions</span></th>
        </tr></thead>
        <tbody>
          ${slice.map((c) => `<tr class="${selected.has(c.id) ? 'is-selected' : ''}">
            <td class="sel-cell">
              <input type="checkbox" data-select="contact" data-id="${esc(c.id)}" ${selected.has(c.id) ? 'checked' : ''} aria-label="Select ${esc(c.name || c.email)}" />
            </td>
            <td><div class="row gap-2"><span class="avatar-sm" style="width:28px;height:28px;font-size:11px">${esc((c.name || '?').slice(0, 1).toUpperCase())}</span>${esc(c.name || 'Unknown')}</div></td>
            <td class="muted">${esc(c.email || c.phone || '—')}</td>
            <td><span class="badge">${esc(c.source)}</span></td>
            <td><div class="row gap-1 wrap">${(c.tags || []).length ? c.tags.map((t) => `<span class="tag">${esc(t)}</span>`).join('') : '<span class="tiny muted">—</span>'}</div></td>
            <td class="muted small">${c.consentAt ? formatDate(c.consentAt) : '—'}</td>
            <td style="text-align:right"><button class="btn-icon" data-action="delete-contact" data-id="${esc(c.id)}" aria-label="Remove ${esc(c.name || c.email)}">${icon('trash', 15)}</button></td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>
    <div class="pager">
      <span class="tiny muted" style="margin-right:auto">Showing ${(page - 1) * audienceUI.perPage + 1}–${Math.min(page * audienceUI.perPage, filtered.length)} of ${filtered.length}</span>
      <button class="btn btn-outline btn-sm" data-action="contacts-page" data-page="${page - 1}" ${page <= 1 ? 'disabled' : ''}>Previous</button>
      <span class="tiny muted">Page ${page} / ${pages}</span>
      <button class="btn btn-outline btn-sm" data-action="contacts-page" data-page="${page + 1}" ${page >= pages ? 'disabled' : ''}>Next</button>
    </div>`;
}

export function openBulkTagModal() {
  const count = audienceUI.selected.size;
  if (!count) return;
  const existing = allTags();
  openModal({
    title: `Tag ${count} contact${count === 1 ? '' : 's'}`,
    subtitle: 'Tags are private to you and help you group people.',
    body: `<form data-form="bulk-tags" id="bulk-tags-form">
      ${existing.length ? `<p class="field-label mb-2">Existing tags</p>
        <div class="chip-row mb-4">
          ${existing.map((t) => `<label class="chip"><input type="checkbox" name="tag" value="${esc(t)}" class="tag-check" /> ${esc(t)}</label>`).join('')}
        </div>` : ''}
      <div class="field" style="margin-bottom:0">
        <label class="field-label" for="bulk-new-tags">Add tags</label>
        <input class="input" id="bulk-new-tags" name="newTags" placeholder="vip, wholesale, workshop" data-autofocus autocomplete="off" />
        <span class="field-hint">Separate new tags with commas. Tags already on a contact are kept.</span>
      </div>
    </form>`,
    footer: `<button class="btn btn-outline" data-action="modal-close">Cancel</button>
      <button class="btn btn-primary" data-action="save-bulk-tags">Apply tags</button>`,
  });
}

export function refreshContacts() {
  const region = document.getElementById('contacts-region');
  if (region) region.innerHTML = contactsTable();
  const count = document.getElementById('contact-count');
  if (count) count.textContent = `${State.data.contacts.length} contacts`;
}

function integrationsView() {
  return `
  <div class="page-head">
    <div>
      <h1 class="page-title">Audience</h1>
      <p class="page-sub">Connect the places you already post so attribution lines up.</p>
    </div>
    <div class="head-actions"><button class="btn btn-primary" data-action="integration-request">${icon('plus', 15)} Request an integration</button></div>
  </div>
  ${tabs('integrations')}
  <div class="card card-pad">
    <div class="card-head"><div><h2 class="card-title">Connected accounts</h2><p class="card-sub">Demo connections — nothing is sent to these services.</p></div></div>
    ${INTEGRATIONS.map((i) => {
      const on = State.data.settings.integrations[i.id];
      return `<div class="integration-row">
        <span class="tool-icon" style="width:40px;height:40px">${icon(i.icon, 19)}</span>
        <div class="grow"><p class="small bold">${esc(i.name)}</p><p class="tiny muted">${esc(i.desc)}</p></div>
        <span class="badge ${on ? 'badge-live' : ''}">${on ? 'Connected' : 'Not connected'}</span>
        <label class="switch"><input type="checkbox" data-toggle="integration" data-id="${esc(i.id)}" ${on ? 'checked' : ''} aria-label="Connect ${esc(i.name)}" /><span></span></label>
      </div>`;
    }).join('')}
  </div>
  <div class="card card-pad mt-4">
    <div class="card-head"><div><h2 class="card-title">Where contacts come from</h2><p class="card-sub">Sources attributed in the last 30 days</p></div></div>
    ${contactSources()}
  </div>`;
}

function contactSources() {
  const map = new Map();
  for (const c of State.data.contacts) map.set(c.source, (map.get(c.source) || 0) + 1);
  const rows = [...map.entries()].sort((a, b) => b[1] - a[1]);
  if (!rows.length) return '<p class="small muted">No contacts yet.</p>';
  const max = Math.max(...rows.map((r) => r[1]));
  return `<div class="bar-list">${rows.map(([s, n]) => `<div class="bar-row">
    <span class="truncate">${esc(s)}</span>
    <span class="bar-track"><span class="bar-fill lime" style="width:${(n / max) * 100}%"></span></span>
    <span class="bar-value">${n}</span>
  </div>`).join('')}</div>`;
}

export function exportContacts() {
  const rows = [['name', 'email', 'phone', 'source', 'tags', 'consent_at', 'created_at']];
  for (const c of State.data.contacts) {
    rows.push([c.name || '', c.email || '', c.phone || '', c.source, (c.tags || []).join('; '), c.consentAt || '', c.createdAt]);
  }
  const csv = rows.map((r) => r.map((v) => `"${String(v).replaceAll('"', '""')}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `beacon-contacts-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(a.href);
  toast('Contacts exported as CSV', 'success');
}

export function addContactModal() {
  openModal({
    title: 'Add a contact',
    subtitle: 'Useful for people you met offline.',
    body: `<form data-form="add-contact" id="add-contact-form">
      <div class="field"><label class="field-label" for="ac-name">Name</label><input class="input" id="ac-name" name="name" data-autofocus /></div>
      <div class="field"><label class="field-label" for="ac-email">Email</label><input class="input" id="ac-email" name="email" type="email" required /></div>
      <div class="field" style="margin-bottom:0"><label class="field-label" for="ac-source">Source</label>
        <select class="select" id="ac-source" name="source"><option>Manual</option><option>Event</option><option>Client</option><option>Newsletter</option></select>
      </div>
    </form>`,
    footer: '<button class="btn btn-outline" data-action="modal-close">Cancel</button><button class="btn btn-primary" data-action="save-contact">Add contact</button>',
  });
}
