/* Settings screens. */
import { State, save, resetDemo, currentHandle } from '../store.js';
import { esc, icon, toast, openModal, dialog, copyToClipboard } from '../ui.js';

export const SECTIONS = [
  { id: 'account', label: 'Account' },
  { id: 'profile', label: 'Public profile' },
  { id: 'workspace', label: 'Workspace' },
  { id: 'notifications', label: 'Notifications' },
  { id: 'integrations', label: 'Integrations' },
  { id: 'billing', label: 'Plan & billing' },
  { id: 'privacy', label: 'Privacy & data' },
];

export function settingsView(section = 'account') {
  const s = SECTIONS.find((x) => x.id === section) || SECTIONS[0];
  return `
  <div class="page-head">
    <div><h1 class="page-title">Settings</h1><p class="page-sub">Account, profile and data controls for this workspace.</p></div>
    <div class="head-actions"><span class="badge">${esc(State.data.settings.plan)} plan</span></div>
  </div>
  <div class="settings-grid">
    <nav class="settings-nav" aria-label="Settings sections">
      ${SECTIONS.map((x) => `<a href="#/app/settings/${x.id}" class="${s.id === x.id ? 'active' : ''}">${x.label}</a>`).join('')}
    </nav>
    <div class="settings-panel">
      ${panel(s.id)}
    </div>
  </div>`;
}

function panel(id) {
  const { account, session, settings, profile, workspace, subscribe } = State.data;
  const user = account || session || {};
  switch (id) {
    case 'account':
      return `
      <section class="card card-pad">
        <h2 class="card-title">Account</h2>
        <p class="card-sub mb-4">How you sign in to Beacon.</p>
        <form data-form="account">
          <div class="field"><label class="field-label" for="set-name">Name</label>
            <input class="input" id="set-name" name="name" value="${esc(user.name || '')}" /></div>
          <div class="field"><label class="field-label" for="set-email">Email</label>
            <input class="input" id="set-email" name="email" type="email" value="${esc(user.email || '')}" /></div>
          <hr class="divider-line" />
          <p class="field-label mb-2">Change password</p>
          <div class="field"><label class="field-label" for="set-current-pw">Current password</label>
            <input class="input" id="set-current-pw" name="currentPassword" type="password" autocomplete="current-password" placeholder="Required only to change password" /></div>
          <div class="field"><label class="field-label" for="set-pw">New password</label>
            <input class="input" id="set-pw" name="password" type="password" placeholder="At least 8 characters" autocomplete="new-password" /></div>
          <button class="btn btn-primary" type="submit">Save account</button>
        </form>
      </section>
      <section class="card card-pad">
        <h2 class="card-title">Sessions</h2>
        <p class="card-sub mb-3">Sessions are stored on the server and expire after 30 days.</p>
        <div class="setting-row"><div><p class="t">This browser</p><p class="d">Signed in as ${esc(user.email || '')}</p></div><button class="btn btn-outline btn-sm" data-action="sign-out">Sign out</button></div>
      </section>`;
    case 'profile':
      return `
      <section class="card card-pad">
        <h2 class="card-title">Public profile</h2>
        <p class="card-sub mb-4">The address and visibility of your page.</p>
        <form data-form="public-profile">
          <div class="field"><label class="field-label" for="set-handle">Handle</label>
            <div class="input-group"><span class="input-prefix">beacon.page/p/</span>
              <input class="input" id="set-handle" name="handle" value="${esc(workspace.handle)}" /></div></div>
          <div class="field"><label class="field-label" for="set-display">Display name</label>
            <input class="input" id="set-display" name="displayName" value="${esc(profile.displayName)}" /></div>
          <div class="field"><label class="field-label" for="set-bio">Bio</label>
            <textarea class="textarea" id="set-bio" name="bio" maxlength="160">${esc(profile.bio)}</textarea></div>
          <div class="setting-row"><div><p class="t">Show in search engines</p><p class="d">Allow indexing of your public page.</p></div>
            <label class="switch"><input type="checkbox" name="showInSearch" ${settings.publicProfile.showInSearch ? 'checked' : ''} aria-label="Show in search engines" /><span></span></label></div>
          <div class="setting-row"><div><p class="t">Contact button</p><p class="d">Show a message button at the bottom of your page.</p></div>
            <label class="switch"><input type="checkbox" name="showContactButton" ${settings.publicProfile.showContactButton ? 'checked' : ''} aria-label="Contact button" /><span></span></label></div>
          <div class="row gap-2 mt-4 wrap">
            <button class="btn btn-primary" type="submit">Save profile</button>
            <a class="btn btn-outline" href="#/p/${esc(workspace.handle)}" target="_blank" rel="noopener">View page</a>
          </div>
        </form>
      </section>
      <section class="card card-pad">
        <h2 class="card-title">Subscribe block</h2>
        <p class="card-sub">Controls the signup form shown on your page.</p>
        <div class="setting-row"><div><p class="t">Subscribe is ${subscribe.enabled ? 'on' : 'off'}</p><p class="d">${subscribe.enabled ? 'Collecting emails with consent.' : 'Turn it on to start collecting contacts.'}</p></div>
          <button class="btn ${subscribe.enabled ? 'btn-outline' : 'btn-primary'} btn-sm" data-action="${subscribe.enabled ? 'disable-subscribe' : 'activate-subscribe'}">${subscribe.enabled ? 'Turn off' : 'Turn on'}</button></div>
      </section>`;
    case 'workspace':
      return `
      <section class="card card-pad">
        <h2 class="card-title">Workspace</h2>
        <p class="card-sub mb-4">This demo supports a single workspace.</p>
        <form data-form="workspace">
          <div class="field"><label class="field-label" for="ws-name">Workspace name</label>
            <input class="input" id="ws-name" name="name" value="${esc(workspace.name)}" /></div>
          <div class="field"><label class="field-label" for="ws-timezone">Timezone</label>
            <select class="select" id="ws-timezone" name="timezone">
              ${['Europe/Lisbon', 'Europe/London', 'America/New_York', 'America/Los_Angeles', 'Asia/Tokyo'].map((tz) => `<option ${tz === 'Europe/Lisbon' ? 'selected' : ''}>${tz}</option>`).join('')}
            </select></div>
          <button class="btn btn-primary" type="submit">Save workspace</button>
        </form>
      </section>
      <section class="card card-pad">
        <h2 class="card-title">Danger zone</h2>
        <p class="card-sub">These actions cannot be undone.</p>
        <div class="setting-row"><div><p class="t">Reset workspace content</p><p class="d">Clear links, contacts, inbox and analytics for this account on the server.</p></div>
          <button class="btn btn-danger btn-sm" data-action="reset-demo">Reset</button></div>
      </section>`;
    case 'notifications':
      return `
      <section class="card card-pad">
        <h2 class="card-title">Notifications</h2>
        <p class="card-sub mb-3">Email preferences for ${esc(user.email || '')}.</p>
        ${[['weeklyDigest', 'Weekly digest', 'A Monday summary of views, clicks and new contacts.'],
          ['newContact', 'New contact', 'Get an email whenever someone subscribes.'],
          ['newMessage', 'New message', 'Get an email when a visitor writes to you.'],
          ['productUpdates', 'Product updates', 'Occasional news about new Beacon tools.']].map(([k, t, d]) => `
          <div class="setting-row"><div><p class="t">${esc(t)}</p><p class="d">${esc(d)}</p></div>
            <label class="switch"><input type="checkbox" data-toggle="notification" data-id="${k}" ${settings.notifications[k] ? 'checked' : ''} aria-label="${esc(t)}" /><span></span></label></div>`).join('')}
        <p class="tiny muted mt-3">Nothing is actually emailed in this prototype.</p>
      </section>`;
    case 'integrations':
      return `
      <section class="card card-pad">
        <h2 class="card-title">Integrations</h2>
        <p class="card-sub">Connections are simulated; no external request is made.</p>
        <div class="mt-3">
          ${[['instagram', 'Instagram'], ['tiktok', 'TikTok'], ['youtube', 'YouTube'], ['spotify', 'Spotify'], ['mailchimp', 'Mailchimp']].map(([k, label]) => `
            <div class="setting-row"><div><p class="t">${label}</p><p class="d">${settings.integrations[k] ? 'Connected' : 'Not connected'}</p></div>
              <label class="switch"><input type="checkbox" data-toggle="integration" data-id="${k}" ${settings.integrations[k] ? 'checked' : ''} aria-label="Connect ${label}" /><span></span></label></div>`).join('')}
        </div>
      </section>`;
    case 'billing':
      return `
      <section class="card card-pad">
        <div class="row between wrap gap-3">
          <div><h2 class="card-title">Starter plan</h2><p class="card-sub">Everything you need to publish a page. No card required.</p></div>
          <span class="badge badge-lime">Active</span>
        </div>
        <hr class="divider-line" />
        <div class="lifetime">
          <div><p class="tiny muted bold" style="text-transform:uppercase;letter-spacing:.06em">Pages</p><p class="v">1 of 1</p></div>
          <div><p class="tiny muted bold" style="text-transform:uppercase;letter-spacing:.06em">Contacts</p><p class="v">${State.data.contacts.length} unlimited</p></div>
          <div><p class="tiny muted bold" style="text-transform:uppercase;letter-spacing:.06em">Insights</p><p class="v">Lifetime</p></div>
        </div>
        <hr class="divider-line" />
        <div class="row between wrap gap-3">
          <div><p class="bold small">Beacon Plus</p><p class="tiny muted">Premium themes, custom domains and media kits. Billing is disabled in this demo.</p></div>
          <button class="btn btn-dark btn-sm" data-action="upgrade">Upgrade — $9/mo</button>
        </div>
      </section>
      <section class="card card-pad">
        <h2 class="card-title">Invoices</h2>
        <p class="card-sub">No invoices yet on the free plan.</p>
        <div class="empty mt-3" style="padding:28px"><p class="empty-title">Nothing to bill</p><p class="empty-body">When you upgrade, receipts appear here.</p></div>
      </section>`;
    case 'privacy':
      return `
      <section class="card card-pad">
        <h2 class="card-title">Privacy & data</h2>
        <p class="card-sub">Your page, links and audience are stored on Beacon's server. Sign in on any browser to reach them.</p>
        <div class="setting-row"><div><p class="t">Export your data</p><p class="d">Download a JSON file with your profile, blocks, contacts and events.</p></div>
          <button class="btn btn-outline btn-sm" data-action="export-data">${icon('download', 14)} Export</button></div>
        <div class="setting-row"><div><p class="t">Sample analytics</p><p class="d">Show seeded traffic so charts are not empty.</p></div>
          <label class="switch"><input type="checkbox" data-toggle="sample" ${State.data.demoAnalytics ? 'checked' : ''} aria-label="Sample analytics" /><span></span></label></div>
        <div class="setting-row"><div><p class="t">Contact consent records</p><p class="d">${State.data.contacts.filter((c) => c.consentAt).length} of ${State.data.contacts.length} contacts have a recorded consent date.</p></div>
          <button class="btn btn-outline btn-sm" data-action="export-contacts">Export CSV</button></div>
      </section>
      <section class="card card-pad danger-zone">
        <h2 class="card-title">Delete account</h2>
        <p class="card-sub">Removes the workspace, published page, contacts and analytics from Beacon’s server.</p>
        <div class="setting-row" style="border:0"><div><p class="t">Permanently delete everything</p><p class="d">This cannot be undone.</p></div>
          <button class="btn btn-danger-solid btn-sm" data-action="delete-account">Delete account</button></div>
      </section>`;
    default:
      return '';
  }
}

export function upcomingUpgrade() {
  toast('Billing is disabled in this demo — everything is already unlocked.', 'default');
}
