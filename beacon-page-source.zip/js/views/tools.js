/* Business cards, media kit and the small utility tools. */
import { State, save, publicUrl } from '../store.js';
import {
  esc, icon, toast, openModal, formatNumber, copyToClipboard, emptyState, qrCode,
} from '../ui.js';

const CARD_COLORS = ['#c7ff3f', '#ece5ff', '#ffe3c2', '#d6f1ff', '#ffd9e4', '#1f1f1f', '#2832a8', '#ffffff'];

export function businessCardsView() {
  const bc = State.data.tools.businessCard;
  const url = publicUrl();
  const initials = bc.displayName.split(/\s+/).slice(0, 2).map((p) => p[0]).join('').toUpperCase();
  const dark = ['#1f1f1f', '#2832a8'].includes(bc.background);
  return `
  <div class="page-head">
    <div>
      <h1 class="page-title">Business cards</h1>
      <p class="page-sub">A tappable card for the people you meet offline. Scan, save to wallet, done.</p>
    </div>
    <div class="head-actions">
      <button class="btn btn-outline" data-action="download-card">${icon('download', 15)} Download</button>
      <button class="btn btn-primary" data-action="share">${icon('share', 15)} Share card</button>
    </div>
  </div>

  <div class="bc-grid">
    <div class="col gap-4">
      <section class="card card-pad">
        <div class="card-head"><div><h2 class="card-title">Card preview</h2><p class="card-sub">Updates as you type.</p></div>
          <span class="badge badge-lime">Live preview</span></div>
        <div class="bc-preview">
          <div class="bc-card" style="background:${esc(bc.background)};color:${dark ? '#f6f5ff' : '#1f1f1f'}" id="bc-preview">
            <div class="row between">
              <div>
                <p class="bc-name" id="bc-preview-name">${esc(bc.displayName || 'Your name')}</p>
                <p class="bc-role" id="bc-preview-role">${esc(bc.jobTitle || '')}</p>
              </div>
              <span style="width:38px;height:38px;border-radius:11px;background:${dark ? '#c7ff3f' : '#1f1f1f'};display:grid;place-items:center;color:${dark ? '#1f1f1f' : '#c7ff3f'};font-weight:800;font-size:13px">${esc(initials || 'B')}</span>
            </div>
            <div class="bc-foot">
              <div>
                ${bc.showEmail ? `<p>${esc(bc.email)}</p>` : ''}
                ${bc.showPhone ? `<p>${esc(bc.phone)}</p>` : ''}
                ${bc.showWebsite ? `<p>${esc(bc.website)}</p>` : ''}
              </div>
              <div style="text-align:right">
                <p style="font-weight:700">Beacon</p>
                <p style="opacity:.65">beacon.page/p/${esc(State.data.workspace.handle)}</p>
              </div>
            </div>
          </div>
        </div>
        <div class="row gap-2 mt-4 wrap">
          <button class="btn btn-dark btn-sm" data-action="wallet-apple">${icon('wallet', 15)} Add to Apple Wallet</button>
          <button class="btn btn-outline btn-sm" data-action="wallet-google">${icon('wallet', 15)} Add to Google Wallet</button>
        </div>
        <p class="tiny muted mt-3">Wallet passes are simulated in this demo. Download creates a vCard you can AirDrop or print.</p>
      </section>

      <section class="card card-pad">
        <h2 class="card-title">QR code</h2>
        <p class="card-sub mb-3">Point it at your public page.</p>
        <div class="row gap-4 wrap">
          ${qrCode(url)}
          <div class="grow" style="min-width:180px">
            <p class="small">beacon.page/p/${esc(State.data.workspace.handle)}</p>
            <div class="row gap-2 mt-3 wrap">
              <button class="btn btn-outline btn-sm" data-action="copy-url">${icon('copy', 14)} Copy link</button>
              <button class="btn btn-ghost btn-sm" data-action="download-qr">${icon('download', 14)} Save QR</button>
            </div>
          </div>
        </div>
      </section>
    </div>

    <div class="col gap-4">
      <section class="card card-pad">
        <h2 class="card-title mb-3">Card details</h2>
        <form data-form="business-card">
          <div class="field">
            <label class="field-label" for="bc-name">Display name</label>
            <input class="input" id="bc-name" name="displayName" value="${esc(bc.displayName)}" data-input="bc-name" maxlength="40" />
          </div>
          <div class="field">
            <label class="field-label" for="bc-role">Role or tagline</label>
            <input class="input" id="bc-role" name="jobTitle" value="${esc(bc.jobTitle)}" data-input="bc-role" maxlength="60" />
          </div>
          <div class="field">
            <span class="field-label">Background</span>
            <div class="swatch-grid">
              ${CARD_COLORS.map((c) => `<button type="button" class="swatch ${bc.background === c ? 'active' : ''}" style="background:${c}" data-action="bc-color" data-color="${c}" aria-label="Card color ${c}" aria-pressed="${bc.background === c}"></button>`).join('')}
            </div>
          </div>
          <div class="field">
            <label class="field-label" for="bc-email">Email</label>
            <input class="input" id="bc-email" name="email" type="email" value="${esc(bc.email)}" />
          </div>
          <div class="field">
            <label class="field-label" for="bc-phone">Phone</label>
            <input class="input" id="bc-phone" name="phone" value="${esc(bc.phone)}" />
          </div>
          <div class="field">
            <label class="field-label" for="bc-website">Website</label>
            <input class="input" id="bc-website" name="website" value="${esc(bc.website)}" />
          </div>
          <p class="field-label mb-2">Share on the card</p>
          <div class="col gap-2 mb-4">
            ${[['showEmail', 'Email'], ['showPhone', 'Phone'], ['showWebsite', 'Website']].map(([k, label]) => `
              <label class="switch-row" style="border:1px solid var(--border);border-radius:12px;padding:10px 12px">
                <span class="field-label" style="display:block">${label}</span>
                <span class="switch"><input type="checkbox" name="${k}" data-toggle="bc-show" data-id="${k}" ${bc[k] ? 'checked' : ''} aria-label="Share ${label}" /><span></span></span>
              </label>`).join('')}
          </div>
          <button class="btn btn-primary btn-block" type="submit">Save card details</button>
        </form>
      </section>
    </div>
  </div>`;
}

export function mediaKitView() {
  const mk = State.data.tools.mediaKit;
  const views = State.data.events.filter((e) => e.type === 'view').length;
  const clicks = State.data.events.filter((e) => e.type === 'click').length;
  if (!mk.enabled) {
    return `
    <div class="page-head">
      <div><h1 class="page-title">Media kit</h1><p class="page-sub">A shareable one-pager for brands, with your numbers built in.</p></div>
    </div>
    <div class="mediakit-hero">
      <div class="empty-icon" style="margin:0 auto 16px;width:66px;height:66px;border-radius:20px;background:#fff">${icon('file', 30)}</div>
      <h2 style="font-size:26px;letter-spacing:-.03em">Show brands what you actually deliver</h2>
      <p class="muted small mt-3" style="max-width:52ch;margin-left:auto;margin-right:auto">
        Audience size, top links, geography and engagement — pulled from your insights, styled like you, ready to send.
      </p>
      <div class="row gap-2 mt-5 wrap center">
        <button class="btn btn-primary btn-lg" data-action="start-mediakit">Get started</button>
        <button class="btn btn-outline" data-action="mediakit-privacy">${icon('lock', 15)} Privacy notice</button>
      </div>
      <div class="row gap-4 mt-6 wrap center tiny muted">
        <span>${icon('check', 13)} No brand assets copied</span>
        <span>${icon('check', 13)} You choose what to share</span>
        <span>${icon('check', 13)} Revoke any time</span>
      </div>
    </div>`;
  }
  return `
  <div class="page-head">
    <div><h1 class="page-title">Media kit</h1><p class="page-sub">Your numbers, on one page, with a link you control.</p></div>
    <div class="head-actions">
      <button class="btn btn-outline" data-action="mediakit-privacy">${icon('lock', 15)} Privacy</button>
      <button class="btn btn-primary" data-action="download-mediakit">${icon('download', 15)} Download kit</button>
    </div>
  </div>
  <section class="card card-pad mb-4" style="background:linear-gradient(120deg,#f6f2ff,#fbfbfa 60%,#f2fbd9)">
    <div class="row between wrap gap-3">
      <div>
        <span class="badge badge-live"><span class="dot"></span>Kit is live</span>
        <h2 class="mt-3" style="font-size:22px;letter-spacing:-.02em">${esc(State.data.profile.displayName)}</h2>
        <p class="small muted">${esc(State.data.profile.bio)}</p>
      </div>
      <div class="row gap-2">
        <button class="btn btn-outline btn-sm" data-action="copy-mediakit">${icon('copy', 14)} Copy link</button>
        <button class="btn btn-ghost btn-sm" data-action="disable-mediakit">Turn off</button>
      </div>
    </div>
    <div class="mk-metrics mt-5">
      ${[['Audience', formatNumber(State.data.contacts.length)], ['Lifetime views', formatNumber(views)], ['Link clicks', formatNumber(clicks)], ['Avg. CTR', `${views ? Math.round((clicks / views) * 100) : 0}%`]].map(([l, v]) => `
        <div class="soft-card" style="background:#fff"><p class="tiny muted bold" style="text-transform:uppercase;letter-spacing:.05em">${l}</p><p style="font-size:22px;font-weight:700;margin-top:4px">${v}</p></div>`).join('')}
    </div>
  </section>
  <div class="insight-grid">
    <section class="card card-pad">
      <h3 class="card-title">What is shared</h3>
      <div class="col gap-3 mt-3">
        ${[['Audience size and growth', true], ['Top performing links', mk.shareStats], ['Geography and devices', mk.shareStats], ['Contact email', true]].map(([label, on]) => `
          <div class="row between"><span class="small">${esc(label)}</span><span class="badge ${on ? 'badge-live' : ''}">${on ? 'Included' : 'Hidden'}</span></div>`).join('')}
      </div>
      <button class="btn btn-outline btn-block mt-4" data-action="mediakit-privacy">Manage what is shared</button>
    </section>
    <section class="card card-pad">
      <h3 class="card-title">Outreach checklist</h3>
      <div class="checklist mt-3">
        ${[['Add a contact email', true], ['Include two recent case studies', false], ['Set a rate card', false], ['Ask a past client for a quote', false]].map(([label, done]) => `
          <div class="check-row ${done ? 'done' : ''}"><span class="check-mark">${icon('check', 12)}</span><div class="grow"><p class="check-title">${esc(label)}</p></div></div>`).join('')}
      </div>
      <button class="btn btn-primary btn-block mt-3" data-action="mediakit-privacy">Edit kit</button>
    </section>
  </div>`;
}

export function mediakitPrivacyModal() {
  const mk = State.data.tools.mediaKit;
  openModal({
    title: 'Media kit privacy',
    subtitle: 'You decide what a brand can see.',
    body: `<form data-form="mediakit-privacy">
      <label class="switch-row mb-4" style="border:1px solid var(--border);border-radius:12px;padding:12px">
        <span><span class="field-label" style="display:block">Share audience stats</span><span class="field-hint">Views, clicks, countries and devices.</span></span>
        <span class="switch"><input type="checkbox" name="shareStats" ${mk.shareStats ? 'checked' : ''} aria-label="Share audience stats" /><span></span></span>
      </label>
      <div class="field">
        <label class="field-label" for="mk-email">Contact email on the kit</label>
        <input class="input" id="mk-email" name="contactEmail" type="email" value="${esc(mk.contactEmail)}" />
      </div>
      <p class="tiny muted">The kit link is unguessable and can be revoked from this panel. In this prototype it opens your public page.</p>
    </form>`,
    footer: '<button class="btn btn-outline" data-action="modal-close">Cancel</button><button class="btn btn-primary" data-action="save-mediakit-privacy">Save</button>',
  });
}

/* ---------- small utility tools ---------- */
const TOOLCOPY = {
  'social-planner': {
    title: 'Social planner', icon: 'calendar',
    intro: 'Plan posts across Instagram, TikTok and YouTube from one calendar.',
    steps: ['Connect a social account', 'Draft your first week of posts', 'Schedule and review results'],
  },
  'link-shortener': {
    title: 'Link shortener', icon: 'scissors',
    intro: 'Turn long campaign URLs into short beacon.page links you can track.',
    steps: ['Paste a destination URL', 'Pick a short slug', 'Watch clicks in Insights'],
  },
  'post-ideas': {
    title: 'Post ideas', icon: 'bulb',
    intro: 'A weekly set of prompts based on what is already working on your page.',
    steps: ['Add a few links', 'Tell us your niche', 'Get five ideas every Monday'],
  },
  'instagram-auto-reply': {
    title: 'Instagram auto-reply', icon: 'instagram',
    intro: 'Reply to keywords in your DMs with the right link automatically.',
    steps: ['Connect Instagram', 'Choose a keyword', 'Attach a link or collection'],
  },
};

export function toolView(id) {
  const t = TOOLCOPY[id] || TOOLCOPY['social-planner'];
  return `
  <div class="page-head">
    <div><h1 class="page-title">${esc(t.title)}</h1><p class="page-sub">${esc(t.intro)}</p></div>
    <div class="head-actions"><span class="badge badge-plus">${icon('sparkles', 11)} Early access</span></div>
  </div>
  <div class="card card-pad">
    <div class="row gap-4 wrap between mb-4">
      <div class="row gap-3">
        <span class="tool-icon" style="width:44px;height:44px;color:var(--brand-primary);background:var(--brand-primary-soft)">${icon(t.icon, 21)}</span>
        <div><h2 class="card-title">Not set up yet</h2><p class="card-sub">This tool is available in your workspace but needs a quick connection.</p></div>
      </div>
      <button class="btn btn-primary" data-action="tool-soon">Start setup</button>
    </div>
    <div class="col gap-2">
      ${t.steps.map((s, i) => `<div class="onb-step" style="padding:12px 0">
        <span class="onb-num">${i + 1}</span>
        <div class="grow"><h3>${esc(s)}</h3></div>
        <span class="badge">Waiting</span>
      </div>`).join('')}
    </div>
  </div>
  <div class="card card-pad mt-4">
    <div class="row between wrap gap-3">
      <div><p class="bold small">While you are here</p><p class="tiny muted">The fastest win is making sure your page is published.</p></div>
      <div class="row gap-2">
        <a class="btn btn-outline btn-sm" href="#/app/editor/content">Open editor</a>
        <a class="btn btn-outline btn-sm" href="#/app/insights">See insights</a>
      </div>
    </div>
  </div>`;
}

export function downloadVCard() {
  const bc = State.data.tools.businessCard;
  const lines = [
    'BEGIN:VCARD', 'VERSION:3.0',
    `FN:${bc.displayName}`,
    `TITLE:${bc.jobTitle}`,
    `EMAIL:${bc.email}`,
    `TEL:${bc.phone}`,
    `URL:${publicUrl()}`,
    'END:VCARD',
  ];
  const blob = new Blob([lines.join('\r\n')], { type: 'text/vcard' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `${bc.displayName.replace(/\s+/g, '-').toLowerCase()}.vcf`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(a.href);
  toast('vCard downloaded', 'success');
}

export function downloadMediaKit() {
  const { profile, contacts, events } = State.data;
  const views = events.filter((e) => e.type === 'view').length;
  const clicks = events.filter((e) => e.type === 'click').length;
  const html = `<!doctype html><meta charset="utf-8"><title>${esc(profile.displayName)} — media kit</title>
<style>body{font-family:Inter,system-ui,sans-serif;max-width:720px;margin:48px auto;padding:0 24px;color:#1f1f1f}h1{font-size:34px;letter-spacing:-.03em;margin:0}p{line-height:1.5}.m{display:flex;gap:32px;margin:28px 0;padding:20px 0;border-top:1px solid #e3e3df;border-bottom:1px solid #e3e3df}.m div span{display:block;font-size:12px;color:#6f706d;text-transform:uppercase;letter-spacing:.06em}.m strong{font-size:24px}</style>
<h1>${esc(profile.displayName)}</h1><p>${esc(profile.bio)}</p>
<div class="m"><div><span>Audience</span><strong>${contacts.length}</strong></div><div><span>Views</span><strong>${views}</strong></div><div><span>Clicks</span><strong>${clicks}</strong></div><div><span>CTR</span><strong>${views ? Math.round((clicks / views) * 100) : 0}%</strong></div></div>
<p>Contact: ${esc(State.data.tools.mediaKit.contactEmail)}<br>Page: beacon.page/p/${esc(State.data.workspace.handle)}</p>
<p style="color:#6f706d;font-size:12px">Generated with Beacon Page — demo data.</p>`;
  const blob = new Blob([html], { type: 'text/html' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'media-kit.html';
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(a.href);
  toast('Media kit downloaded', 'success');
}
