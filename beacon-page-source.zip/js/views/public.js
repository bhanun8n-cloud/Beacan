/* Public profile page — reads published data from the server. */
import { esc, icon, rerender } from '../ui.js';
import { api } from '../api.js';
import { publicScreen } from '../preview.js';

const cache = new Map(); // handle -> { status, published, error }
let activeHandle = null;
let tracked = new Set();

function fetchPublic(handle) {
  cache.set(handle, { status: 'loading' });
  api.getPublic(handle)
    .then((data) => {
      cache.set(handle, { status: 'ready', published: data.published });
      rerender();
    })
    .catch((error) => {
      cache.set(handle, { status: 'error', error });
      rerender();
    });
}

function shell(inner) {
  return `<div class="public-shell" style="background:var(--canvas)">
    <div class="public-top">
      <a class="brand" href="#/" style="padding:0">
        <span class="brand-mark">${icon('sparkles', 17)}</span>
        <span class="brand-name">Beacon Page</span>
      </a>
      <a class="pill-link" href="#/auth/sign-in">Create yours</a>
    </div>
    <div class="public-wrap" style="display:grid;place-items:center;min-height:62vh;text-align:center">
      ${inner}
    </div>
  </div>`;
}

function loadingView() {
  return `<div class="public-shell" style="background:var(--canvas)">
    <div class="public-top">
      <span class="brand" style="padding:0"><span class="brand-mark">${icon('sparkles', 17)}</span><span class="brand-name">Beacon Page</span></span>
    </div>
    <div class="public-wrap" style="max-width:420px;padding-top:40px">
      <div class="card card-pad" aria-busy="true" aria-label="Loading profile">
        <div class="sk" style="width:88px;height:88px;border-radius:50%;margin:0 auto 16px"></div>
        <div class="sk" style="height:18px;width:60%;margin:0 auto 10px"></div>
        <div class="sk" style="height:12px;width:80%;margin:0 auto 6px"></div>
        <div class="sk" style="height:12px;width:70%;margin:0 auto 22px"></div>
        <div class="sk" style="height:52px;border-radius:12px;margin-bottom:11px"></div>
        <div class="sk" style="height:52px;border-radius:12px;margin-bottom:11px"></div>
        <div class="sk" style="height:52px;border-radius:12px"></div>
      </div>
      <p class="tiny muted mt-3">Loading the page…</p>
    </div>
  </div>`;
}

function errorView(error) {
  const unpublished = error?.code === 'unpublished';
  return shell(`
    <div>
      <div class="empty-icon" style="margin:0 auto 16px">${icon(unpublished ? 'link' : 'search', 24)}</div>
      <h1 style="font-size:24px;letter-spacing:-.02em">${unpublished ? 'This page is not public yet' : 'We could not find that page'}</h1>
      <p class="muted small mt-2" style="max-width:42ch;margin-left:auto;margin-right:auto">
        ${unpublished
          ? 'The creator has not published this page yet. Check back soon.'
          : 'Double-check the link, or ask the creator for their current address.'}
      </p>
      <div class="row gap-2 mt-4 center wrap">
        <a class="btn btn-primary" href="#/auth/sign-in">Create your own page</a>
      </div>
    </div>`);
}

function trackView(handle) {
  if (tracked.has(handle)) return;
  tracked.add(handle);
  api.publicEvent(handle, {
    type: 'view',
    device: window.innerWidth < 640 ? 'mobile' : 'desktop',
    referrer: document.referrer ? 'referral' : 'direct',
  }).catch(() => { /* analytics must never break the page */ });
}

function trackClick(blockId) {
  if (!activeHandle || !blockId) return;
  api.publicEvent(activeHandle, { type: 'click', blockId }).catch(() => {});
}

export function publicView(handle) {
  activeHandle = handle;
  const entry = cache.get(handle);
  if (!entry) {
    fetchPublic(handle);
    return loadingView();
  }
  if (entry.status === 'loading') return loadingView();
  if (entry.status === 'error') return errorView(entry.error);
  trackView(handle);
  return `<div class="public-shell" style="background:${esc(entry.published.theme?.background || '#f7f7f5')}">
    <div class="public-top">
      <span class="pill-link" style="background:rgb(255 255 255 / .7)">${icon('sparkles', 13)} Beacon Page</span>
      <div class="row gap-2">
        <button class="pill-link" data-action="share-public" style="cursor:pointer;border:1px solid rgb(0 0 0 / .08)">${icon('share', 13)} Share</button>
        <a class="pill-link" href="#/auth/sign-in" style="background:#1f1f1f;color:#fff;border-color:#1f1f1f">Create yours</a>
      </div>
    </div>
    <div class="public-wrap">
      ${publicScreen(entry.published.profile, entry.published.theme, entry.published.blocks, { live: true, className: 'live-page' })}
    </div>
    <div class="public-actions">
      <button class="btn btn-ghost btn-sm" data-action="public-report">${icon('info', 14)} Report this page</button>
      <a class="btn btn-ghost btn-sm" href="#/auth/sign-in">${icon('sparkles', 14)} Built with Beacon</a>
    </div>
  </div>`;
}

export function getPublicBlock(blockId) {
  const entry = activeHandle ? cache.get(activeHandle) : null;
  if (!entry || entry.status !== 'ready') return null;
  return entry.published.blocks?.find((b) => b.id === blockId) || null;
}

export function currentPublicHandle() {
  const match = (location.hash || '').match(/^#\/p\/([^/?]+)/);
  return match ? decodeURIComponent(match[1]) : activeHandle;
}

export function trackPublicClick(blockId) {
  trackClick(blockId);
}

/* Public form modal: subscribe, message, or generic form block. */
export function publicFormModal(block) {
  const isMessage = block.kind === 'message';
  const title = isMessage ? block.title || 'Send a message' : block.title || 'Join the list';
  const subtitle = isMessage
    ? 'Your message goes straight to the creator.'
    : 'No spam — unsubscribe any time.';
  const body = isMessage
    ? `<form data-form="public-message" data-block-id="${esc(block.id)}" id="public-form">
        <div class="field"><label class="field-label" for="pf-name">Your name</label>
          <input class="input" id="pf-name" name="name" required data-autofocus autocomplete="name" /></div>
        <div class="field"><label class="field-label" for="pf-email">Email</label>
          <input class="input" id="pf-email" name="email" type="email" required autocomplete="email" /></div>
        <div class="field"><label class="field-label" for="pf-msg">Message</label>
          <textarea class="textarea" id="pf-msg" name="message" required maxlength="600"></textarea></div>
        <label class="checkbox"><input type="checkbox" name="consent" required />
          <span class="tiny">I agree that the creator may email me back about this message.</span></label>
      </form>`
    : `<form data-form="public-subscribe" data-block-id="${esc(block.id)}" id="public-form">
        <div class="field"><label class="field-label" for="pf-name">Name <span class="muted">(optional)</span></label>
          <input class="input" id="pf-name" name="name" autocomplete="name" data-autofocus /></div>
        <div class="field"><label class="field-label" for="pf-email">Email</label>
          <input class="input" id="pf-email" name="email" type="email" required autocomplete="email" /></div>
        <label class="checkbox"><input type="checkbox" name="consent" required />
          <span class="tiny">I agree to receive occasional emails from this creator.</span></label>
      </form>`;
  return { title, subtitle, body };
}
