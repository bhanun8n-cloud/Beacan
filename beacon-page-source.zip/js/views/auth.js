/* Authentication, onboarding and password reset screens. */
import { esc, icon, progressRing } from '../ui.js';
import { State, ONBOARDING_STEPS, onboardingProgress } from '../store.js';
import { phonePreview } from '../preview.js';

export const authView = { errors: [], values: {}, loading: false, notice: '' };

const shell = (inner, { side = true } = {}) => `
<div class="auth-page">
  ${side ? `<aside class="auth-side">
    <a class="brand" href="#/">
      <span class="brand-mark">${icon('sparkles', 17)}</span>
      <span class="brand-name">Beacon Page</span>
    </a>
    <div style="position:relative;z-index:1">
      <h1>One link for everything you make.</h1>
      <p>A calm home for your links, your audience and the numbers that tell you what is working.</p>
      <div class="auth-proof">
        <div>${icon('checkCircle', 17)} Unlimited links, collections and products</div>
        <div>${icon('checkCircle', 17)} Audience tools and a real inbox</div>
        <div>${icon('checkCircle', 17)} Insights down to the individual click</div>
      </div>
    </div>
    <p class="tiny" style="position:relative;z-index:1;color:rgb(255 255 255 / .55);margin:0">
      An original demo product. Not affiliated with any link-in-bio service.
    </p>
  </aside>` : ''}
  <main class="auth-main"><div class="auth-card">${inner}</div></main>
</div>`;

const errorSummary = () => authView.errors.length ? `
  <div class="auth-errors" role="alert" tabindex="-1" id="auth-errors">
    <strong>We could not continue</strong>
    <ul>${authView.errors.map((e) => `<li>${esc(e)}</li>`).join('')}</ul>
  </div>` : '';

export function signInView() {
  const v = authView.values;
  return shell(`
    <h1 class="auth-title">Welcome back</h1>
    <p class="auth-sub">Sign in to keep building your page.</p>
    <div class="mt-5"></div>
    ${errorSummary()}
    <form data-form="sign-in" novalidate>
      <div class="field">
        <label class="field-label" for="signin-email">Email</label>
        <input class="input" id="signin-email" name="email" type="email" autocomplete="email"
          value="${esc(v.email || '')}" required aria-describedby="signin-email-err" />
        <span class="field-error" id="signin-email-err"></span>
      </div>
      <div class="field">
        <label class="field-label" for="signin-password">Password</label>
        <input class="input" id="signin-password" name="password" type="password" autocomplete="current-password"
          value="${esc(v.password || '')}" required />
        <span class="field-error" id="signin-password-err"></span>
      </div>
      <div class="row between mb-4">
        <label class="checkbox"><input type="checkbox" name="remember" checked /> Keep me signed in</label>
        <a href="#/auth/reset" class="btn-link" style="text-decoration:none;font-size:12.5px">Forgot password?</a>
      </div>
      <button class="btn btn-primary btn-block btn-lg" type="submit" ${authView.loading ? 'disabled' : ''}>
        ${authView.loading ? 'Signing in…' : 'Sign in'}
      </button>
    </form>
    <p class="auth-alt">New here? <a href="#/auth/sign-up" class="btn-link" style="text-decoration:none">Create a page</a></p>
    <p class="auth-foot">Your account and page are stored on Beacon's server, so you can sign in from any browser or device. Passwords are hashed — never stored in plain text.</p>
  `);
}

export function signUpView() {
  const v = authView.values;
  return shell(`
    <h1 class="auth-title">Claim your handle</h1>
    <p class="auth-sub">A page of your own in about a minute.</p>
    <div class="mt-5"></div>
    ${errorSummary()}
    <form data-form="sign-up" novalidate>
      <div class="field">
        <label class="field-label" for="su-name">Display name</label>
        <input class="input" id="su-name" name="name" value="${esc(v.name || '')}" autocomplete="name" required />
      </div>
      <div class="field">
        <label class="field-label" for="su-email">Email</label>
        <input class="input" id="su-email" name="email" type="email" value="${esc(v.email || '')}" autocomplete="email" required />
      </div>
      <div class="field">
        <label class="field-label" for="su-handle">Your page address</label>
        <div class="input-group">
          <span class="input-prefix">beacon.page/p/</span>
          <input class="input" id="su-handle" name="handle" value="${esc(v.handle || '')}"
            placeholder="maya.studio" autocomplete="off" aria-describedby="handle-status" required data-handle-input />
        </div>
        <span class="handle-status" id="handle-status" aria-live="polite"></span>
      </div>
      <div class="field">
        <label class="field-label" for="su-password">Password</label>
        <input class="input" id="su-password" name="password" type="password" value="${esc(v.password || '')}"
          autocomplete="new-password" required aria-describedby="pw-hint" />
        <span class="field-hint" id="pw-hint">At least 8 characters.</span>
      </div>
      <label class="checkbox mb-4">
        <input type="checkbox" name="terms" />
        <span>I agree to the demo terms and privacy notice, and I understand my page and links are stored on Beacon’s server.</span>
      </label>
      <button class="btn btn-primary btn-block btn-lg" type="submit" ${authView.loading ? 'disabled' : ''}>
        ${authView.loading ? 'Creating your account…' : 'Create my account'}
      </button>
    </form>
    <p class="auth-alt">Already have a page? <a href="#/auth/sign-in" class="btn-link" style="text-decoration:none">Sign in</a></p>
    <p class="auth-foot">Your page, links and audience are saved to Beacon's server and tied to this email. Sign in from any browser to reach them.</p>
  `);
}

export function resetView() {
  return shell(`
    <a href="#/auth/sign-in" class="btn-link row gap-1" style="text-decoration:none;font-size:12.5px">${icon('arrowLeft', 14)} Back to sign in</a>
    <h1 class="auth-title mt-4">Reset your password</h1>
    <p class="auth-sub">Enter your email and we will tell you the next step.</p>
    <div class="mt-5"></div>
    ${authView.notice ? `<div class="auth-errors" style="background:#eaf9f1;border-color:#bfe8d4;color:#0b6b47" role="status">${esc(authView.notice)}</div>` : ''}
    ${errorSummary()}
    <form data-form="reset">
      <div class="field">
        <label class="field-label" for="reset-email">Email</label>
        <input class="input" id="reset-email" name="email" type="email" required value="${esc(authView.values.email || '')}" />
      </div>
      <button class="btn btn-primary btn-block btn-lg" type="submit">Send reset link</button>
    </form>
    <p class="auth-foot">Beacon does not send email in this build. If you still know your password you can <a href="#/auth/sign-in" class="btn-link" style="text-decoration:none">sign in</a> and change it in Settings → Account.</p>
  `);
}

export function onboardingView() {
  const { steps, done, pct } = onboardingProgress();
  const next = steps.find((s) => !s.done);
  const profile = State.data.profile;
  return `
  <div class="onb-page">
    <header class="row between mb-5 wrap gap-3">
      <a class="brand" href="#/app"><span class="brand-mark">${icon('sparkles', 17)}</span><span class="brand-name">Beacon Page</span></a>
      <div class="row gap-3">
        <span class="badge badge-brand">${done} of ${steps.length} done</span>
        <a class="btn btn-outline btn-sm" href="#/app">Skip to dashboard</a>
      </div>
    </header>
    <div class="card onb-card">
      <div class="row gap-4 wrap between">
        <div>
          <h1 style="font-size:24px;letter-spacing:-.03em">Let's get your page ready</h1>
          <p class="muted small mt-2" style="max-width:52ch">Six small steps. You can leave and come back at any point — your progress is saved.</p>
        </div>
        ${progressRing(pct)}
      </div>
      <div class="mt-4">
        ${steps.map((s, i) => `
          <div class="onb-step ${s.done ? 'done' : ''}">
            <span class="onb-num">${s.done ? icon('check', 14) : i + 1}</span>
            <div class="grow">
              <h3>${esc(s.title)}</h3>
              <p>${esc(s.desc)}</p>
            </div>
            ${s.done
              ? '<span class="badge badge-live"><span class="dot"></span>Done</span>'
              : `<a class="btn btn-sm ${next?.id === s.id ? 'btn-primary' : 'btn-outline'}" href="${s.route}">${next?.id === s.id ? 'Start' : 'Open'}</a>`}
          </div>`).join('')}
      </div>
    </div>
    <div class="card card-pad mt-4">
      <div class="row between wrap gap-4">
        <div class="grow" style="min-width:220px">
          <h2 class="card-title">Your page so far</h2>
          <p class="card-sub">This is exactly what visitors see.</p>
          <div class="mt-3">
            ${next ? `<a class="btn btn-primary" href="${next.route}">Continue: ${esc(next.title)}</a>`
              : '<a class="btn btn-primary" href="#/onboarding/complete">Finish setup</a>'}
          </div>
        </div>
        ${phonePreview(profile, State.data.theme, State.data.blocks)}
      </div>
    </div>
  </div>`;
}

export function onboardingCompleteView() {
  const handle = State.data.workspace.handle;
  return shell(`
    <div style="text-align:center">
      <div class="empty-icon" style="margin:0 auto 14px;width:64px;height:64px;border-radius:20px;background:var(--brand-primary-soft);color:var(--brand-primary)">${icon('checkCircle', 30)}</div>
      <h1 class="auth-title">Your page is live 🎉</h1>
      <p class="auth-sub">beacon.page/p/${esc(handle)} is ready to share.</p>
    </div>
    <div class="soft-card mt-5">
      <p class="tiny muted bold" style="letter-spacing:.06em;text-transform:uppercase">Public address</p>
      <p class="mt-2" style="font-weight:600;word-break:break-all">beacon.page/p/${esc(handle)}</p>
      <div class="row gap-2 mt-3 wrap">
        <button class="btn btn-sm btn-primary" data-action="copy-url">${icon('copy', 14)} Copy link</button>
        <a class="btn btn-sm btn-outline" href="#/p/${esc(handle)}">${icon('eye', 14)} View page</a>
      </div>
    </div>
    <div class="row gap-2 mt-5" style="flex-direction:column">
      <a class="btn btn-primary btn-block btn-lg" href="#/app/editor/content">Open the editor</a>
      <a class="btn btn-outline btn-block" href="#/app/insights">See your insights</a>
    </div>
    <p class="auth-foot">You can change your handle, design and links any time from the console.</p>
  `);
}
