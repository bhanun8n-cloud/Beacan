/* Content, design and header editors. */
import {
  State, uid, clone, snapshot, save, hasUnpublishedChanges, isAuthenticated,
} from '../store.js';
import {
  esc, icon, toast, openModal, closeModal, formatDateTime,
} from '../ui.js';
import {
  phonePreview, PRESETS, WALLPAPERS, BUTTON_STYLES, DECOS, FONTS,
} from '../preview.js';
import { qrSvg } from '../qr.js';

export const editorUI = { search: '', cat: 'Suggested' };

export const BLOCK_TYPES = [
  { id: 'link', kind: 'link', name: 'Link', desc: 'Send people anywhere', icon: 'link', cat: 'Suggested' },
  { id: 'collection', kind: 'collection', name: 'Collection', desc: 'Group several links under one heading', icon: 'grid', cat: 'Suggested' },
  { id: 'product', kind: 'product', name: 'Product', desc: 'Feature or sell a single item', icon: 'bag', cat: 'Commerce' },
  { id: 'form', kind: 'form', name: 'Form / signup', desc: 'Collect emails or answers', icon: 'form', cat: 'Contact' },
  { id: 'message', kind: 'message', name: 'Message CTA', desc: 'Let visitors start a conversation', icon: 'send', cat: 'Contact' },
  { id: 'social', kind: 'social', name: 'Social profile', desc: 'Instagram, TikTok, YouTube, X', icon: 'instagram', cat: 'Social' },
  { id: 'video', kind: 'video', name: 'Video', desc: 'Link out to a video or embed', icon: 'play', cat: 'Media' },
  { id: 'gallery', kind: 'gallery', name: 'Image gallery', desc: 'A small grid of your images', icon: 'image', cat: 'Media' },
  { id: 'music', kind: 'link', name: 'Music', desc: 'Latest release or playlist', icon: 'music', cat: 'Media' },
  { id: 'booking', kind: 'link', name: 'Booking', desc: 'Link to your scheduler', icon: 'clock', cat: 'Events' },
  { id: 'event', kind: 'link', name: 'Event link', desc: 'Tickets, RSVPs and shows', icon: 'calendar', cat: 'Events' },
  { id: 'download', kind: 'form', name: 'Digital download', desc: 'Gate a file behind an email', icon: 'download', cat: 'Commerce' },
  { id: 'discount', kind: 'link', name: 'Discount code', desc: 'Share a promo code with your audience', icon: 'ticket', cat: 'Commerce' },
  { id: 'text', kind: 'text', name: 'Text block', desc: 'A short note or announcement', icon: 'type', cat: 'Text' },
  { id: 'divider', kind: 'divider', name: 'Divider', desc: 'Separate groups of links', icon: 'filter', cat: 'Text' },
];

const CATEGORIES = ['Suggested', 'Commerce', 'Social', 'Media', 'Contact', 'Events', 'Text', 'View all'];

const KIND_ICON = {
  link: 'link', collection: 'grid', product: 'bag', form: 'form',
  message: 'send', social: 'globe', video: 'play', gallery: 'image',
  text: 'type', divider: 'filter',
};

function editorBar() {
  const { workspace } = State.data;
  const dirty = hasUnpublishedChanges();
  return `<header class="editor-bar">
    <a class="brand" href="#/app" aria-label="Back to dashboard">
      <span class="brand-mark">${icon('sparkles', 17)}</span>
      <span class="brand-name hide-sm">Beacon</span>
    </a>
    <span class="eb-sep hide-sm"></span>
    <div class="ws-meta hide-sm" style="max-width:170px">
      <p class="ws-name">${esc(workspace.name)}</p>
      <p class="ws-handle">beacon.page/p/${esc(workspace.handle)}</p>
    </div>
    <span class="badge ${dirty ? 'badge-draft' : 'badge-live'}" aria-live="polite">
      ${dirty ? 'Draft changes' : '<span class="dot"></span>Published'}
    </span>
    <div class="eb-right">
      <button class="btn-icon" data-action="undo" aria-label="Undo" ${State.data.history.past.length ? '' : 'disabled'}>${icon('undo', 17)}</button>
      <button class="btn-icon" data-action="redo" aria-label="Redo" ${State.data.history.future.length ? '' : 'disabled'}>${icon('redo', 17)}</button>
      <span class="eb-sep hide-sm"></span>
      <button class="btn-icon" data-action="share" aria-label="Share your page">${icon('share', 17)}</button>
      <button class="btn btn-outline btn-sm only-sm" data-action="toggle-preview">${icon('eye', 15)} Preview</button>
      <a class="btn btn-ghost btn-sm hide-sm" href="#/app/insights">${icon('chart', 15)} Insights</a>
      <button class="btn btn-primary btn-sm" data-action="publish">${icon('arrowUp', 15)} Publish</button>
    </div>
  </header>`;
}

function tabs(active) {
  const tab = (id, label) => `<a href="#/app/editor/${id}" class="${active === id ? 'active' : ''}">${label}</a>`;
  return `<nav class="editor-tabs" aria-label="Editor sections">
    ${tab('content', 'Content')}${tab('design', 'Design')}${tab('header', 'Header')}
  </nav>`;
}

const previewPane = () => `${phonePreview(State.data.profile, State.data.theme, State.data.blocks)}
  <button class="btn btn-dark btn-sm preview-close" data-action="toggle-preview">${icon('x', 15)} Close preview</button>`;

function editorShell(panel) {
  return `<div class="editor">
    ${editorBar()}
    <div class="editor-body">
      <section class="editor-panel"><div class="editor-panel-inner">${panel}</div></section>
      <aside class="editor-preview" aria-label="Live phone preview">${previewPane()}</aside>
    </div>
  </div>`;
}

/* ---------------- content ---------------- */
export function contentView() {
  const { profile, blocks } = State.data;
  const sorted = [...blocks].sort((a, b) => a.position - b.position);
  const initials = (profile.displayName || 'B').split(/\s+/).slice(0, 2).map((p) => p[0]).join('');
  return editorShell(`
    ${tabs('content')}
    <div class="card card-pad mb-4">
      <div class="profile-summary">
        <div class="avatar-lg" style="width:52px;height:52px">
          ${profile.avatarUrl ? `<img src="${esc(profile.avatarUrl)}" alt="" />` : esc(initials)}
        </div>
        <div class="grow" style="min-width:0">
          <p style="font-weight:700;font-size:14.5px">${esc(profile.displayName)}</p>
          <p class="tiny muted truncate">${esc(profile.bio || 'Add a short bio so people know what you do.')}</p>
        </div>
        <a class="btn btn-outline btn-sm" href="#/app/editor/header">Edit header</a>
      </div>
    </div>

    <div class="panel-head">
      <div>
        <h2 class="panel-title">Links & blocks</h2>
        <p class="card-sub">${sorted.filter((b) => b.visible).length} visible · ${sorted.length} total</p>
      </div>
      <button class="btn btn-primary btn-sm" data-action="open-add">${icon('plus', 15)} Add</button>
    </div>

    <div class="block-list" id="block-list" role="list" aria-label="Page blocks">
      ${sorted.length ? sorted.map((b, i) => blockRow(b, i, sorted)).join('') : emptyBlocks()}
    </div>

    <div class="soft-card mt-4 row between wrap gap-3">
      <div>
        <p class="small bold">Reorder without a mouse</p>
        <p class="tiny muted">Use the arrow buttons on each block, or press Alt + ↑ / ↓ while it is focused.</p>
      </div>
      <span class="badge">Autosaves as draft</span>
    </div>
  `);
}

function emptyBlocks() {
  return `<div class="empty">
    <div class="empty-icon">${icon('link', 22)}</div>
    <p class="empty-title">No blocks yet</p>
    <p class="empty-body">Start with the one link people ask for most — your latest work, shop or booking page.</p>
    <div class="empty-actions"><button class="btn btn-primary" data-action="open-add">${icon('plus', 15)} Add your first block</button></div>
  </div>`;
}

function blockRow(block, index, list) {
  const iconName = KIND_ICON[block.kind] || 'link';
  const scheduled = block.schedule?.start || block.schedule?.end;
  const isScheduledFuture = block.schedule?.start && new Date(block.schedule.start).getTime() > Date.now();
  return `<div class="block ${block.visible ? '' : 'is-hidden'}" role="listitem" draggable="true"
      data-block-row="${esc(block.id)}" data-index="${index}" tabindex="0">
    <button class="drag" data-action="block-focus" aria-label="Drag to reorder ${esc(block.title)} (or use the arrow buttons)">${icon('drag', 16)}</button>
    <span class="block-icon">${block.thumbUrl ? `<img src="${esc(block.thumbUrl)}" alt="" />` : icon(iconName, 18)}</span>
    <div class="block-main">
      <p class="block-title">${esc(block.title || 'Untitled')}</p>
      <p class="block-url">${esc(block.url || block.description || block.kind)}</p>
      <div class="block-meta">
        ${block.visible ? '<span class="badge badge-live"><span class="dot"></span>Visible</span>' : '<span class="badge">Hidden</span>'}
        ${isScheduledFuture ? `<span class="badge badge-draft">${icon('clock', 11)} Scheduled ${esc(formatDateTime(block.schedule.start))}</span>` : ''}
        ${block.kind === 'product' && block.config?.price ? `<span class="badge badge-lime">${esc(block.config.price)}</span>` : ''}
      </div>
    </div>
    <div class="block-tools">
      <button class="btn-icon" data-action="block-up" data-id="${esc(block.id)}" aria-label="Move ${esc(block.title)} up" ${index === 0 ? 'disabled' : ''}>${icon('arrowUp', 15)}</button>
      <button class="btn-icon" data-action="block-down" data-id="${esc(block.id)}" aria-label="Move ${esc(block.title)} down" ${index === list.length - 1 ? 'disabled' : ''}>${icon('arrowDown', 15)}</button>
      <button class="btn-icon" data-action="block-toggle" data-id="${esc(block.id)}" aria-label="${block.visible ? 'Hide' : 'Show'} ${esc(block.title)}" aria-pressed="${block.visible}">${icon(block.visible ? 'eye' : 'eyeOff', 16)}</button>
      <button class="btn-icon" data-action="block-edit" data-id="${esc(block.id)}" aria-label="Edit ${esc(block.title)}">${icon('settings', 16)}</button>
      <button class="btn-icon" data-action="block-menu" data-id="${esc(block.id)}" aria-label="More options for ${esc(block.title)}">${icon('dots', 16)}</button>
    </div>
  </div>`;
}

/* ---------------- design ---------------- */
export function designView() {
  const { theme } = State.data;
  const presetCard = (p) => `<button class="preset ${theme.preset === p.id ? 'active' : ''}" data-action="set-theme" data-key="preset" data-value="${esc(p.id)}"
      aria-pressed="${theme.preset === p.id}">
      <span class="preset-swatch" style="background:${esc(p.background)}"><span style="background:${esc(p.accentColor)}"></span></span>
      <span class="preset-name">${esc(p.id)}</span>
      ${theme.preset === p.id ? `<span class="preset-check">${icon('check', 11)}</span>` : ''}
    </button>`;

  const swatch = (color, key, label) => `<button class="swatch ${theme[key]?.toLowerCase() === color.toLowerCase() ? 'active' : ''}"
      style="background:${color}" data-action="set-theme" data-key="${key}" data-value="${color}"
      aria-label="${esc(label)}" aria-pressed="${theme[key]?.toLowerCase() === color.toLowerCase()}"></button>`;

  return editorShell(`
    ${tabs('design')}
    <div class="panel-head">
      <div><h2 class="panel-title">Design</h2><p class="card-sub">Changes preview instantly and stay in draft until you publish.</p></div>
      <span class="badge badge-plus">Plus styles included</span>
    </div>

    <section class="card card-pad mb-4">
      <h3 class="card-title mb-3">Theme</h3>
      <div class="preset-grid">${PRESETS.map(presetCard).join('')}</div>
    </section>

    <section class="card card-pad mb-4">
      <h3 class="card-title">Wallpaper</h3>
      <p class="card-sub mb-3">Layer a subtle texture over your background.</p>
      <div class="chip-row">
        ${WALLPAPERS.map((w) => `<button class="chip ${theme.wallpaper === w.id ? 'active' : ''}" data-action="set-theme" data-key="wallpaper" data-value="${w.id}" aria-pressed="${theme.wallpaper === w.id}">${esc(w.label)}</button>`).join('')}
        <button class="chip" data-action="pro-tip" data-tip="wallpaper">${icon('sparkles', 13)} Mesh gradients <span class="badge badge-plus">Plus</span></button>
      </div>
    </section>

    <section class="card card-pad mb-4">
      <h3 class="card-title">Buttons</h3>
      <p class="card-sub mb-3">Shape and fill of every link button.</p>
      <div class="chip-row mb-3">
        ${BUTTON_STYLES.map((b) => `<button class="chip ${theme.buttonStyle === b.id ? 'active' : ''}" data-action="set-theme" data-key="buttonStyle" data-value="${b.id}" aria-pressed="${theme.buttonStyle === b.id}">${esc(b.label)}</button>`).join('')}
      </div>
      <p class="field-label mb-2">Button color</p>
      <div class="swatch-grid">
        ${['#ffffff', '#f4f0ff', '#c7ff3f', '#1f1f1f', '#2832a8', '#ffe3c2'].map((c) => swatch(c, 'buttonColor', `Button color ${c}`)).join('')}
      </div>
    </section>

    <section class="card card-pad mb-4">
      <h3 class="card-title">Typography</h3>
      <p class="card-sub mb-3">Fonts are included in this demo build.</p>
      <div class="chip-row mb-3">
        ${Object.keys(FONTS).map((f) => `<button class="chip ${theme.fontFamily === f ? 'active' : ''}" data-action="set-theme" data-key="fontFamily" data-value="${esc(f)}" aria-pressed="${theme.fontFamily === f}" style="font-family:${FONTS[f]}">${esc(f)}</button>`).join('')}
        <button class="chip" data-action="pro-tip" data-tip="fonts">${icon('sparkles', 13)} Editorial serif <span class="badge badge-plus">Plus</span></button>
      </div>
      <p class="field-label mb-2">Text color</p>
      <div class="swatch-grid">
        ${['#1f1f1f', '#f6f5ff', '#2832a8', '#3f5c05', '#5a1f12', '#6f706d'].map((c) => swatch(c, 'textColor', `Text color ${c}`)).join('')}
      </div>
    </section>

    <section class="card card-pad mb-4">
      <h3 class="card-title">Colors</h3>
      <p class="card-sub mb-3">Accent used for icons, pricing and highlights.</p>
      <div class="swatch-grid mb-4">
        ${['#6b28d9', '#2832a8', '#0f9f68', '#b4550f', '#b02a6a', '#1f1f1f'].map((c) => swatch(c, 'accentColor', `Accent color ${c}`)).join('')}
      </div>
      <p class="field-label mb-2">Background</p>
      <div class="chip-row">
        ${['linear-gradient(165deg, #ece5ff 0%, #f8f4ff 48%, #eaf9d5 100%)', '#ffffff', 'linear-gradient(180deg,#fff6e0,#ffd9c7)', 'linear-gradient(165deg,#14121f,#231b3d 55%,#14233a)', 'linear-gradient(160deg,#f2ffd6,#d5f7a8)'].map((bg, i) => `
          <button class="swatch ${theme.background === bg ? 'active' : ''}" style="background:${bg};border-radius:10px;width:44px" data-action="set-theme" data-key="background" data-value="${esc(bg)}" aria-label="Background option ${i + 1}" aria-pressed="${theme.background === bg}"></button>`).join('')}
      </div>
    </section>

    <section class="card card-pad">
      <h3 class="card-title">Stickers</h3>
      <p class="card-sub mb-3">A little decoration around your header.</p>
      <div class="chip-row">
        ${DECOS.map((d) => `<button class="chip ${(theme.decorations[0] || 'none') === d.id ? 'active' : ''}" data-action="set-theme" data-key="decorations" data-value="${d.id}" aria-pressed="${(theme.decorations[0] || 'none') === d.id}">
          <span aria-hidden="true" style="font-size:14px">${d.glyph || '∅'}</span> ${esc(d.label)}</button>`).join('')}
      </div>
    </section>
  `);
}

/* ---------------- header ---------------- */
export function headerView() {
  const { profile, workspace } = State.data;
  const initials = (profile.displayName || 'B').split(/\s+/).slice(0, 2).map((p) => p[0]).join('');
  return editorShell(`
    ${tabs('header')}
    <div class="panel-head">
      <div><h2 class="panel-title">Profile header</h2><p class="card-sub">How you introduce yourself at the top of your page.</p></div>
    </div>

    <form data-form="header" novalidate>
      <section class="card card-pad mb-4">
        <h3 class="card-title mb-3">Photo</h3>
        <div class="row gap-4 wrap">
          <div class="avatar-lg">${profile.avatarUrl ? `<img src="${esc(profile.avatarUrl)}" alt="Current profile photo" />` : esc(initials)}</div>
          <div class="grow" style="min-width:200px">
            <div class="row gap-2 wrap">
              <label class="btn btn-outline btn-sm" for="avatar-upload">${icon('image', 15)} Upload photo</label>
              <input id="avatar-upload" type="file" accept="image/png,image/jpeg,image/webp" class="sr-only" data-upload="avatar" />
              ${profile.avatarUrl ? '<button type="button" class="btn btn-ghost btn-sm" data-action="remove-avatar">Remove</button>' : ''}
            </div>
            <p class="tiny muted mt-2">JPG, PNG or WebP · up to 2 MB · square images look best.</p>
            <div class="progress-track mt-2 hide" id="avatar-progress"><div class="progress-fill" style="width:0%"></div></div>
          </div>
        </div>
      </section>

      <section class="card card-pad mb-4">
        <h3 class="card-title mb-3">Details</h3>
        <div class="field">
          <label class="field-label" for="h-name">Display name</label>
          <input class="input" id="h-name" name="displayName" value="${esc(profile.displayName)}" maxlength="40" required />
        </div>
        <div class="field">
          <label class="field-label" for="h-bio">Bio</label>
          <textarea class="textarea" id="h-bio" name="bio" maxlength="160">${esc(profile.bio)}</textarea>
          <span class="field-hint">160 characters max — this is what shows under your name.</span>
        </div>
        <div class="field">
          <label class="field-label" for="h-handle">Handle</label>
          <div class="input-group">
            <span class="input-prefix">beacon.page/p/</span>
            <input class="input" id="h-handle" name="handle" value="${esc(workspace.handle)}" pattern="[a-z0-9._\\-]{3,30}" />
          </div>
          <span class="field-hint">Lowercase letters, numbers, dots and dashes. Changing this breaks old links.</span>
        </div>
        <div class="field" style="margin-bottom:0">
          <label class="field-label" for="h-email">Contact email</label>
          <input class="input" id="h-email" name="email" type="email" value="${esc(profile.email || '')}" />
        </div>
      </section>

      <section class="card card-pad mb-4">
        <div class="row between gap-3 mb-3">
          <h3 class="card-title" style="margin:0">Social icons</h3>
          <label class="checkbox" style="font-size:12.5px">
            <input type="checkbox" name="showSocials" ${profile.showSocials ? 'checked' : ''} /> Show on page
          </label>
        </div>
        ${profile.socials.length ? profile.socials.map((s) => `
          <div class="social-row" data-social-id="${esc(s.id)}">
            <select class="select" name="platform_${esc(s.id)}" aria-label="Platform">
              ${['instagram', 'tiktok', 'youtube', 'x', 'spotify', 'website'].map((p) => `<option value="${p}" ${s.platform === p ? 'selected' : ''}>${p[0].toUpperCase() + p.slice(1)}</option>`).join('')}
            </select>
            <input class="input" name="url_${esc(s.id)}" value="${esc(s.url)}" placeholder="https://" aria-label="${esc(s.platform)} URL" />
            <button type="button" class="btn-icon" data-action="remove-social" data-id="${esc(s.id)}" aria-label="Remove ${esc(s.platform)}">${icon('x', 16)}</button>
          </div>`).join('') : '<p class="small muted">No social icons yet.</p>'}
        <button type="button" class="btn btn-outline btn-sm mt-3" data-action="add-social">${icon('plus', 14)} Add social</button>
      </section>

      <section class="card card-pad mb-4">
        <h3 class="card-title mb-3">Layout</h3>
        <div class="field">
          <span class="field-label">Alignment</span>
          <div class="segmented">
            ${[['center', 'Centered'], ['left', 'Left aligned']].map(([v, l]) => `<label class="seg"><input type="radio" name="headerAlign" value="${v}" ${profile.headerAlign === v ? 'checked' : ''} /> <span>${l}</span></label>`).join('')}
          </div>
        </div>
        <div class="field" style="margin-bottom:0">
          <span class="field-label">Header spacing</span>
          <div class="segmented">
            ${[['cozy', 'Cozy'], ['roomy', 'Roomy']].map(([v, l]) => `<label class="seg"><input type="radio" name="headerSpacing" value="${v}" ${profile.headerSpacing === v ? 'checked' : ''} /> <span>${l}</span></label>`).join('')}
          </div>
        </div>
      </section>

      <div class="row gap-2 wrap">
        <button class="btn btn-primary" type="submit">${icon('check', 15)} Save header</button>
        <button class="btn btn-outline" type="button" data-action="share">${icon('share', 15)} Preview &amp; share</button>
      </div>
    </form>
  `);
}

/* ---------------- add block modal ---------------- */
export function openAddBlockModal() {
  openModal({
    title: 'Add to your page',
    size: 'add-modal',
    body: `<div class="add-layout">
      <div class="add-cats" role="tablist" aria-label="Categories">
        ${CATEGORIES.map((c) => `<button class="add-cat ${editorUI.cat === c ? 'active' : ''}" role="tab"
          aria-selected="${editorUI.cat === c}" data-action="add-cat" data-cat="${c}">${c}</button>`).join('')}
      </div>
      <div class="add-results">
        <div class="search-box mb-4">
          ${icon('search', 16)}
          <input class="input" id="add-search" placeholder="Paste a link or search…" value="${esc(editorUI.search)}"
            data-input="add-search" aria-label="Search content blocks" autocomplete="off" />
        </div>
        <div id="add-results-body">${addResults()}</div>
      </div>
    </div>`,
  });
}

function addResults() {
  const q = editorUI.search.trim().toLowerCase();
  const list = BLOCK_TYPES.filter((t) => {
    const inCat = editorUI.cat === 'View all' || editorUI.cat === 'Suggested' || t.cat === editorUI.cat;
    const matches = !q || `${t.name} ${t.desc} ${t.cat}`.toLowerCase().includes(q);
    return inCat && matches;
  });
  const quick = ['collection', 'link', 'product', 'form']
    .map((id) => BLOCK_TYPES.find((t) => t.id === id));
  return `
    ${!q && editorUI.cat === 'Suggested' ? `
      <p class="field-label mb-2">Quick add</p>
      <div class="add-quick">
        ${quick.map((t) => `<button data-action="add-block" data-type="${t.id}">
          <span class="add-icon" style="background:var(--brand-primary-soft);color:var(--brand-primary)">${icon(t.icon, 17)}</span>
          ${esc(t.name)}
        </button>`).join('')}
      </div>` : ''}
    <p class="field-label mb-2">${q ? `${list.length} result${list.length === 1 ? '' : 's'}` : 'Recommended'}</p>
    ${list.length ? list.map((t) => `
      <button class="add-item" data-action="add-block" data-type="${t.id}">
        <span class="add-icon">${icon(t.icon, 18)}</span>
        <span class="grow"><span class="add-name">${esc(t.name)}</span><span class="add-desc">${esc(t.desc)}</span></span>
        <span class="tiny muted">${t.cat}</span>
      </button>`).join('')
      : `<div class="empty" style="padding:28px"><p class="empty-title">Nothing matched</p><p class="empty-body">Try a different word, or browse the categories on the left.</p></div>`}
  `;
}

export function refreshAddResults() {
  const body = document.getElementById('add-results-body');
  if (body) body.innerHTML = addResults();
}

/* ---------------- block editor modal ---------------- */
export function openBlockEditor(id) {
  const block = State.data.blocks.find((b) => b.id === id);
  if (!block) return;
  const isDivider = block.kind === 'divider';
  const showUrl = ['link', 'product', 'social', 'video', 'collection', 'gallery'].includes(block.kind);
  const showImage = ['link', 'product'].includes(block.kind);
  openModal({
    title: block.title ? 'Edit block' : 'New block',
    subtitle: `Type: ${block.kind}`,
    size: 'modal-lg',
    body: `<form data-form="block" data-block-id="${esc(block.id)}" id="block-form">
      ${isDivider ? '<p class="small muted">A divider is just a line. Save it and position it with the arrow buttons.</p>' : ''}
      ${!isDivider ? `
      <div class="field">
        <label class="field-label" for="b-title">Title</label>
        <input class="input" id="b-title" name="title" value="${esc(block.title)}" maxlength="80" data-autofocus />
      </div>` : ''}
      ${showUrl ? `
      <div class="field">
        <label class="field-label" for="b-url">URL</label>
        <input class="input" id="b-url" name="url" value="${esc(block.url)}" placeholder="https://example.com" inputmode="url" />
        <span class="field-hint">We add https:// automatically if you leave it off.</span>
      </div>` : ''}
      ${!isDivider ? `
      <div class="field">
        <label class="field-label" for="b-desc">Description</label>
        <textarea class="textarea" id="b-desc" name="description" maxlength="140">${esc(block.description || '')}</textarea>
      </div>` : ''}
      ${showImage ? `
      <div class="split-2">
        <div class="field">
          <label class="field-label" for="b-thumb">Thumbnail URL</label>
          <input class="input" id="b-thumb" name="thumbUrl" value="${esc(block.thumbUrl || '')}" placeholder="https://…" />
        </div>
        <div class="field">
          <label class="field-label" for="b-icon">Icon URL</label>
          <input class="input" id="b-icon" name="iconUrl" value="${esc(block.iconUrl || '')}" placeholder="https://…" />
        </div>
      </div>` : ''}
      ${block.kind === 'product' ? `
      <div class="field">
        <label class="field-label" for="b-price">Price label</label>
        <input class="input" id="b-price" name="price" value="${esc(block.config?.price || '')}" placeholder="$24" />
      </div>` : ''}
      ${block.kind === 'collection' ? `
      <div class="field">
        <label class="field-label" for="b-items">Collection items</label>
        <textarea class="textarea" id="b-items" name="items" placeholder="One item per line">${esc((block.config?.items || []).join('\n'))}</textarea>
        <span class="field-hint">One item per line. Items link to the URL above.</span>
      </div>` : ''}
      ${block.kind === 'social' ? `
      <div class="field">
        <label class="field-label" for="b-platform">Platform</label>
        <select class="select" id="b-platform" name="platform">
          ${['instagram', 'tiktok', 'youtube', 'x', 'spotify', 'website'].map((p) => `<option ${block.config?.platform === p ? 'selected' : ''}>${p}</option>`).join('')}
        </select>
      </div>` : ''}
      ${block.kind === 'form' || block.kind === 'message' ? `
      <div class="split-2">
        <div class="field">
          <label class="field-label" for="b-cta">Button label</label>
          <input class="input" id="b-cta" name="buttonLabel" value="${esc(block.config?.buttonLabel || '')}" placeholder="Subscribe" />
        </div>
        ${block.kind === 'form' ? `<div class="field">
          <label class="field-label" for="b-formtype">Form type</label>
          <select class="select" id="b-formtype" name="formType">
            ${[['subscribe', 'Email signup'], ['contact', 'Contact form'], ['download', 'Gated download']].map(([v, l]) => `<option value="${v}" ${block.config?.formType === v ? 'selected' : ''}>${l}</option>`).join('')}
          </select>
        </div>` : ''}
      </div>` : ''}
      ${!isDivider ? `
      <hr class="divider-line" />
      <div class="split-2">
        <div class="field">
          <label class="field-label" for="b-start">Show from</label>
          <input class="input" type="datetime-local" id="b-start" name="scheduleStart" value="${block.schedule?.start ? block.schedule.start.slice(0, 16) : ''}" />
        </div>
        <div class="field">
          <label class="field-label" for="b-end">Hide after</label>
          <input class="input" type="datetime-local" id="b-end" name="scheduleEnd" value="${block.schedule?.end ? block.schedule.end.slice(0, 16) : ''}" />
        </div>
      </div>
      <label class="switch-row">
        <span>
          <span class="field-label" style="display:block">Visible on page</span>
          <span class="field-hint">Hidden blocks keep their place but do not appear publicly.</span>
        </span>
        <span class="switch"><input type="checkbox" name="visible" ${block.visible ? 'checked' : ''} aria-label="Visible on page" /><span></span></span>
      </label>` : ''}
    </form>`,
    footer: `
      <button class="btn btn-danger btn-sm" style="margin-right:auto" data-action="block-delete" data-id="${esc(block.id)}">${icon('trash', 14)} Delete</button>
      <button class="btn btn-outline" data-action="modal-close">Cancel</button>
      <button class="btn btn-primary" data-action="save-block" data-id="${esc(block.id)}">Save block</button>`,
  });
}

/* ---------------- block menu ---------------- */
export function openBlockMenu(id) {
  const block = State.data.blocks.find((b) => b.id === id);
  if (!block) return;
  openModal({
    title: block.title || 'Block options',
    subtitle: 'Duplicate, archive or remove this block.',
    body: `<div class="col gap-2">
      <button class="btn btn-outline btn-block" data-action="block-duplicate" data-id="${esc(id)}">${icon('copy', 15)} Duplicate block</button>
      <button class="btn btn-outline btn-block" data-action="block-toggle" data-id="${esc(id)}">${icon(block.visible ? 'eyeOff' : 'eye', 15)} ${block.visible ? 'Hide from page' : 'Show on page'}</button>
      <button class="btn btn-outline btn-block" data-action="block-archive" data-id="${esc(id)}">${icon('archive', 15)} Archive (keep a copy)</button>
      <button class="btn btn-danger btn-block" data-action="block-delete" data-id="${esc(id)}">${icon('trash', 15)} Delete permanently</button>
    </div>`,
  });
}

export function createBlock(typeId) {
  const type = BLOCK_TYPES.find((t) => t.id === typeId) || BLOCK_TYPES[0];
  const defaults = {
    link: { title: 'New link', url: '' },
    collection: { title: 'New collection', config: { items: [] } },
    product: { title: 'New product', url: '', config: { price: '' } },
    form: { title: 'Join my newsletter', config: { formType: 'subscribe', buttonLabel: 'Subscribe' } },
    message: { title: 'Work with me', config: { buttonLabel: 'Send a message' } },
    social: { title: 'Follow me', url: '', config: { platform: 'instagram' } },
    video: { title: 'Watch the latest', url: '' },
    gallery: { title: 'Recent work', config: { images: [] } },
    music: { title: 'Listen to my latest release', url: '' },
    booking: { title: 'Book a call', url: '' },
    event: { title: 'Upcoming event', url: '' },
    download: { title: 'Free download', config: { formType: 'download', buttonLabel: 'Get it' } },
    discount: { title: 'Use code STUDIO20', url: '' },
    text: { title: 'A note for visitors', description: '' },
    divider: { title: 'Divider' },
  };
  const d = defaults[type.id] || { title: 'New block' };
  const block = {
    id: uid('blk'),
    kind: type.kind,
    title: d.title,
    url: d.url || '',
    description: d.description || '',
    iconUrl: '',
    thumbUrl: '',
    position: State.data.blocks.length,
    visible: true,
    schedule: null,
    config: d.config || {},
  };
  snapshot();
  State.data.blocks.push(block);
  save();
  return block;
}

export function shareModal() {
  const { workspace } = State.data;
  const url = `${location.origin}${location.pathname}#/p/${workspace.handle}`;
  openModal({
    title: 'Share your page',
    subtitle: 'One link, everywhere.',
    body: `
      <div class="soft-card">
        <p class="tiny muted bold" style="text-transform:uppercase;letter-spacing:.07em">Public address</p>
        <p class="mt-2" style="font-weight:600;word-break:break-all">beacon.page/p/${esc(workspace.handle)}</p>
      </div>
      <div class="row gap-2 mt-4 wrap">
        <button class="btn btn-primary" data-action="copy-url">${icon('copy', 15)} Copy link</button>
        <button class="btn btn-outline" data-action="native-share">${icon('share', 15)} Share…</button>
        <a class="btn btn-ghost" href="#/p/${esc(workspace.handle)}" target="_blank" rel="noopener">${icon('external', 15)} Open page</a>
      </div>
      <hr class="divider-line" />
      <div class="row gap-4 wrap">
        ${qrCodeMarkup(url)}
        <div class="grow" style="min-width:180px">
          <p class="small bold">Scan to open</p>
          <p class="tiny muted mt-2">Print it on a card, stick it on your camera bag, or add it to a story.</p>
          <a class="btn btn-outline btn-sm mt-3" href="#/app/tools/business-cards">${icon('card', 14)} Business cards</a>
        </div>
      </div>`,
  });
}

function qrCodeMarkup(url) {
  return `<div class="qr">${qrSvg(url)}</div>`;
}
