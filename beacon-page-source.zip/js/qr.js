/* Local QR code generation — no network, no third-party image service.
   Wraps the vendored MIT-licensed qrcode-generator library. */
import qrcode from './vendor/qrcode-generator.js';

const DARK = '#1f1f1f';
const LIGHT = '#ffffff';

const escapeAttr = (value) => String(value ?? '')
  .replaceAll('&', '&amp;')
  .replaceAll('<', '&lt;')
  .replaceAll('>', '&gt;')
  .replaceAll('"', '&quot;')
  .replaceAll("'", '&#39;');

/** Encode text into a square bitmap of booleans (true = dark module). */
export function qrBitmap(text, { errorCorrection = 'M' } = {}) {
  const qr = qrcode(0, errorCorrection);
  qr.addData(String(text), 'Byte');
  qr.make();
  const count = qr.getModuleCount();
  const rows = Array.from({ length: count }, (_, r) =>
    Array.from({ length: count }, (_, c) => qr.isDark(r, c)));
  return { count, rows };
}

/** Inline SVG string. Scales to its container, so it stays sharp when printed. */
export function qrSvg(text, { margin = 4, dark = DARK, light = LIGHT, label } = {}) {
  const { count, rows } = qrBitmap(text);
  const size = count + margin * 2;
  let path = '';
  for (let r = 0; r < count; r += 1) {
    for (let c = 0; c < count; c += 1) {
      if (rows[r][c]) path += `M${c + margin} ${r + margin}h1v1h-1z`;
    }
  }
  const aria = escapeAttr(label || `QR code linking to ${text}`);
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" width="100%" height="100%" role="img" aria-label="${aria}" shape-rendering="crispEdges" focusable="false"><rect width="${size}" height="${size}" fill="${light}"/><path d="${path}" fill="${dark}"/></svg>`;
}

/** Rasterise to a PNG data URL using canvas (browser only). */
export function qrPngDataUrl(text, { size = 640, margin = 4, dark = DARK, light = LIGHT } = {}) {
  if (typeof document === 'undefined') return '';
  const { count, rows } = qrBitmap(text);
  const total = count + margin * 2;
  const scale = Math.max(1, Math.floor(size / total));
  const dim = total * scale;
  const canvas = document.createElement('canvas');
  canvas.width = dim;
  canvas.height = dim;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';
  ctx.fillStyle = light;
  ctx.fillRect(0, 0, dim, dim);
  ctx.fillStyle = dark;
  for (let r = 0; r < count; r += 1) {
    for (let c = 0; c < count; c += 1) {
      if (rows[r][c]) ctx.fillRect((c + margin) * scale, (r + margin) * scale, scale, scale);
    }
  }
  return canvas.toDataURL('image/png');
}

/** Download a PNG of the code, generated in the browser. */
export function downloadQr(text, filename = 'beacon-qr.png', opts = {}) {
  const href = qrPngDataUrl(text, opts);
  if (!href) return false;
  const a = document.createElement('a');
  a.href = href;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  return true;
}
