/* Router + application shell. Boots from the server session. */
import {
  State, isAuthenticated, onboardingProgress, hydrateSession, clearSession,
} from './store.js';
import {
  esc, icon, setRenderer, rerender, navigate, progressRing,
} from './ui.js';
import { api } from './api.js';
import { bindEvents, setReturnTo } from './actions.js';
import {
  signInView, signUpView, resetView, onboardingView, onboardingCompleteView,
} from './views/auth.js';
import { dashboardView } from './views/dashboard.js';
import { contentView, designView, headerView } from './views/editor.js';
import { insightsView } from './views/insights.js';
import { audienceView } from './views/audience.js';
import { messagingView } from './views/messaging.js';
import { businessCardsView, mediaKitView, toolView } from './views/tools.js';
import { settingsView } from './views/settings.js';
import { publicView } from './views/public.js';

const root = document.getElementById('root');

const NAV_MAIN = [
  { href: '#/app', label: 'Dashboard', icon: 'home' },
  { href: '#/app/editor/content', label: 'Links', icon: 'link' },
  { href: '#/app/editor/design', label: 'Design', icon: 'palette' },
  { href: '#/app/editor/header', label: 'Header', icon: 'user' },
  { href: '#/app/insights', label: 'Insights', icon: 'chart' },
  { href: '#/app/audience', label: 'Audience', icon: 'users' },
  { href: '#/app/messaging', label: 'Messaging', icon: 'message' },
];

const NAV_TOOLS = [
  { href: '#/app/tools/business-cards', label: 'Business cards', icon: 'card' },
  { href: '#/app/tools/media-kit', label: 'Media kit', icon: 'file' },
  { href: '#/app/tools/social-planner', label: 'Social planner', icon: 'calendar' },
  { href: '#/app/tools/post-ideas', label: 'Post ideas', icon: 'bulb' },
  { href: '#/app/tools/link-shortener', label: 'Link shortener', icon: 'scissors' },
  { href: '#/app/tools/instagram-auto-reply', label: 'Instagram auto-reply', icon: 'instagram' },
];

const MOBILE_NAV = [
  { href: '#/app', label: 'Home', icon: 'home' },
  { href: '#/app/editor/content', label: 'Links', icon: 'link' },
  { href: '#/app/editor/design', label: 'Design', icon: 'palette' },
  { href: '#/app/insights', label: 'Insights', icon: 'chart' },
  { href: '#/app/messaging', label: 'Inbox', icon: 'message' },
];

function isActive(path, href) {
  const target = href.replace(/^#/, '');
  if (target === '/app') return path === '/app';
  return path === target || path.startsWith(`${target}/`);
}

function navItem(item, path) {
  const active = isActive(path, item.href);
  return `<a class="nav-item ${active ? 'active' : ''}" href="${item.href}" ${active ? 'aria-current="page"' : ''}>
    ${icon(item.icon, 17)} <span>${esc(item.label)}</span>
  </a>`;
}

function assistant() {
  const a = State.data.assistant || { open: false, messages: [] };
  if (!a.open) {
    return `<button class="assistant-btn" data-action="assistant-toggle" aria-expanded="false">
      ${icon('sparkles', 16)} Ask Beacon
    </button>`;
  }
  return `<aside class="assistant-panel" aria-label="Beacon assistant">
    <div class="assistant-head">
      <span class="brand-mark" style="width:28px;height:28px">${icon('sparkles', 15)}</span>
      <div class="grow"><p class="small bold" style="line-height:1.2">Beacon Assist</p><p class="tiny muted">Help with this workspace</p></div>
      <button class="btn-icon" data-action="assistant-toggle" aria-label="Close assistant">${icon('x', 16)}</button>
    </div>
    <div class="assistant-log">
      ${a.messages.map((m) => `<div class="assistant-msg ${m.from === 'me' ? 'me' : 'bot'}">${esc(m.text)}</div>`).join('')}
    </div>
    <div class="assistant-suggest">
      ${['How do I publish?', 'Where are my contacts?', 'Change my theme'].map((q) => `<button data-action="assistant-ask" data-q="${esc(q)}">${esc(q)}</button>`).join('')}
    </div>
    <form class="assistant-form" data-form="assistant">
      <input class="input" name="message" placeholder="Ask a question…" aria-label="Ask the assistant" autocomplete="off" />
      <button class="btn btn-primary btn-sm" type="submit" aria-label="Send">${icon('send', 15)}</button>
    </form>
  </aside>`;
}

function sidebar(path) {
  const { workspace, profile, conversations } = State.data;
  const { done, total, pct } = onboardingProgress();
  const unread = (conversations || []).reduce((a, c) => a + (c.unread || 0), 0);
  const initials = (profile.displayName || 'B').split(/\s+/).slice(0, 2).map((p) => p[0]).join('');
  return `<aside class="sidebar">
    <div class="sidebar-inner">
      <a class="brand" href="#/app">
        <span class="brand-mark">${icon('sparkles', 17)}</span>
        <span class="brand-name">Beacon Page</span>
      </a>
      <div class="ws-chip">
        <span class="ws-avatar">${profile.avatarUrl ? `<img src="${esc(profile.avatarUrl)}" alt="" />` : esc(initials)}</span>
        <span class="ws-meta">
          <span class="ws-name">${esc(profile.displayName || workspace.name)}</span>
          <span class="ws-handle">@${esc(workspace.handle)}</span>
        </span>
        <a class="btn-icon" href="#/app/settings/profile" aria-label="Workspace settings" style="width:26px;height:26px">${icon('settings', 15)}</a>
      </div>

      <nav class="nav-group" aria-label="Main navigation">
        ${NAV_MAIN.map((i) => {
          const active = isActive(path, i.href);
          return `<a class="nav-item ${active ? 'active' : ''}" href="${i.href}" ${active ? 'aria-current="page"' : ''}>
            ${icon(i.icon, 17)} <span>${esc(i.label)}</span>
            ${i.href === '#/app/messaging' && unread ? `<span class="badge badge-brand">${unread}</span>` : ''}
          </a>`;
        }).join('')}
      </nav>

      <p class="nav-label">Tools</p>
      <nav class="nav-group" aria-label="Tools">
        ${NAV_TOOLS.map((i) => navItem(i, path)).join('')}
      </nav>

      <div class="setup-mini">
        <div class="setup-mini-top">
          ${progressRing(pct, 38, 3.5)}
          <div class="grow">
            <p class="setup-mini-title">${done === total ? 'Setup complete' : 'Finish setup'}</p>
            <p class="setup-mini-sub">${done} of ${total} steps</p>
          </div>
        </div>
        <a class="btn btn-sm ${done === total ? 'btn-outline' : 'btn-primary'} btn-block mt-3" href="#/onboarding">${done === total ? 'Review' : 'Continue'}</a>
      </div>

      <div class="sidebar-foot">
        <a class="nav-item" href="#/app/settings/account">${icon('settings', 17)} Settings</a>
        <button class="nav-item" data-action="sign-out" style="border:0;background:none;width:100%;text-align:left;cursor:pointer">${icon('logout', 17)} Sign out</button>
        <a class="nav-item" href="#/p/${esc(workspace.handle)}" target="_blank" rel="noopener">${icon('external', 17)} View public page</a>
      </div>
    </div>
  </aside>`;
}

function topbar(title) {
  const { profile, workspace } = State.data;
  const initials = (profile.displayName || 'B').split(/\s+/).slice(0, 2).map((p) => p[0]).join('');
  return `<header class="topbar">
    <div class="crumb"><span>Workspace</span>${icon('chevronRight', 13)}<strong>${esc(title)}</strong></div>
    <div class="topbar-actions">
      <a class="btn btn-ghost btn-sm hide-sm" href="#/p/${esc(workspace.handle)}" target="_blank" rel="noopener">${icon('external', 14)} Public page</a>
      <a class="btn-icon" href="#/app/settings/account" aria-label="Settings">${icon('settings', 18)}</a>
      <a class="avatar-sm" href="#/app/settings/account" aria-label="Your account" style="text-decoration:none">${profile.avatarUrl ? `<img src="${esc(profile.avatarUrl)}" alt="" />` : esc(initials)}</a>
    </div>
  </header>`;
}

function shell(content, { title = 'Dashboard', path = '/app', wide = false } = {}) {
  return `<a class="skip-link" href="#main">Skip to content</a>
    <div class="shell">
      ${sidebar(path)}
      <div class="main">
        ${topbar(title)}
        <main class="page" id="main">
          <div class="page-inner" ${wide ? 'style="max-width:1200px"' : ''}>${content}</div>
        </main>
      </div>
    </div>
    <nav class="m-nav" aria-label="Mobile navigation">
      ${MOBILE_NAV.map((i) => `<a href="${i.href}" class="${isActive(path, i.href) ? 'active' : ''}" ${isActive(path, i.href) ? 'aria-current="page"' : ''}>
        ${icon(i.icon, 19)}<span>${esc(i.label)}</span>
      </a>`).join('')}
    </nav>
    ${assistant()}`;
}

const TITLES = {
  '/app': 'Dashboard',
  '/app/editor/content': 'Links',
  '/app/editor/design': 'Design',
  '/app/editor/header': 'Header',
  '/app/insights': 'Insights',
  '/app/audience': 'Audience',
  '/app/audience/integrations': 'Audience',
  '/app/messaging': 'Messaging',
  '/app/tools/business-cards': 'Business cards',
  '/app/tools/media-kit': 'Media kit',
  '/app/tools/social-planner': 'Social planner',
  '/app/tools/link-shortener': 'Link shortener',
  '/app/tools/post-ideas': 'Post ideas',
  '/app/tools/instagram-auto-reply': 'Instagram auto-reply',
};

function render() {
  const hash = location.hash || '#/';
  const path = hash.replace(/^#/, '').split('?')[0] || '/';
  const segments = path.split('/').filter(Boolean);
  let html = '';
  let title = 'Beacon Page';
  let scroll = false;

  if (path === '/' || path === '') {
    navigate(isAuthenticated() ? '#/app' : '#/auth/sign-in');
    return;
  }

  if ((path.startsWith('/app') || path.startsWith('/onboarding')) && !isAuthenticated()) {
    setReturnTo(`#${path}`);
    location.hash = '#/auth/sign-in';
    return;
  }

  if (path === '/auth/sign-in') {
    html = signInView();
    title = 'Sign in · Beacon Page';
  } else if (path === '/auth/sign-up') {
    html = signUpView();
    title = 'Create your account · Beacon Page';
  } else if (path === '/auth/reset') {
    html = resetView();
    title = 'Reset password · Beacon Page';
  } else if (path === '/onboarding') {
    html = onboardingView();
    title = 'Onboarding · Beacon Page';
  } else if (path === '/onboarding/complete') {
    html = onboardingCompleteView();
    title = 'You are live · Beacon Page';
  } else if (segments[0] === 'p' && segments[1]) {
    html = publicView(decodeURIComponent(segments[1]));
    title = 'Beacon Page';
  } else if (path === '/app') {
    html = shell(dashboardView(), { title: 'Dashboard', path, wide: true });
    title = 'Dashboard · Beacon Page';
  } else if (path.startsWith('/app/editor/')) {
    const tab = segments[2] || 'content';
    html = tab === 'design' ? designView() : tab === 'header' ? headerView() : contentView();
    title = `${tab[0].toUpperCase()}${tab.slice(1)} · Beacon Page`;
  } else if (path === '/app/insights') {
    html = shell(insightsView(), { title: 'Insights', path, wide: true });
    title = 'Insights · Beacon Page';
  } else if (path === '/app/audience' || path === '/app/audience/integrations') {
    html = shell(audienceView(path.endsWith('integrations') ? 'integrations' : 'contacts'), { title: 'Audience', path, wide: true });
    title = 'Audience · Beacon Page';
  } else if (path === '/app/messaging') {
    html = shell(messagingView(), { title: 'Messaging', path, wide: true });
    title = 'Messaging · Beacon Page';
  } else if (path === '/app/tools/business-cards') {
    html = shell(businessCardsView(), { title: 'Business cards', path, wide: true });
    title = 'Business cards · Beacon Page';
  } else if (path === '/app/tools/media-kit') {
    html = shell(mediaKitView(), { title: 'Media kit', path, wide: true });
    title = 'Media kit · Beacon Page';
  } else if (segments[0] === 'app' && segments[1] === 'tools' && segments[2]) {
    html = shell(toolView(segments[2]), { title: TITLES[path] || 'Tools', path, wide: true });
    title = `${TITLES[path] || 'Tools'} · Beacon Page`;
  } else if (segments[0] === 'app' && segments[1] === 'settings') {
    const section = segments[2] || 'account';
    html = shell(settingsView(section), { title: 'Settings', path, wide: true });
    title = 'Settings · Beacon Page';
  } else if (path.startsWith('/app')) {
    html = shell(`<div class="empty"><div class="empty-icon">${icon('search', 22)}</div>
      <p class="empty-title">Page not found</p>
      <p class="empty-body">That screen does not exist in this workspace.</p>
      <div class="empty-actions"><a class="btn btn-primary btn-sm" href="#/app">Back to dashboard</a></div></div>`, { title: 'Not found', path });
    title = 'Not found · Beacon Page';
    scroll = true;
  } else {
    html = `<div class="auth-page" style="grid-template-columns:1fr">
      <div class="auth-main"><div class="auth-card" style="text-align:center">
        <h1 class="auth-title">Page not found</h1>
        <p class="auth-sub">The link you followed does not exist.</p>
        <div class="row gap-2 mt-5 center">
          <a class="btn btn-primary" href="#/app">Go to dashboard</a>
          <a class="btn btn-outline" href="#/auth/sign-in">Sign in</a>
        </div>
      </div></div></div>`;
    title = 'Not found · Beacon Page';
    scroll = true;
  }

  root.innerHTML = html;
  document.title = title;
  if (scroll) window.scrollTo({ top: 0 });

  requestAnimationFrame(() => {
    const log = document.querySelector('.assistant-log');
    if (log) log.scrollTop = log.scrollHeight;
  });
}

function splash() {
  return `<div class="auth-page" style="grid-template-columns:1fr">
    <div class="auth-main">
      <div class="auth-card" style="text-align:center">
        <div class="brand" style="justify-content:center;padding:0 0 18px">
          <span class="brand-mark">${icon('sparkles', 17)}</span>
          <span class="brand-name">Beacon Page</span>
        </div>
        <div class="sk" style="height:14px;width:180px;margin:0 auto 10px"></div>
        <div class="sk" style="height:10px;width:120px;margin:0 auto"></div>
        <p class="tiny muted mt-4">Opening your workspace…</p>
      </div>
    </div>
  </div>`;
}

function bootError(error) {
  return `<div class="auth-page" style="grid-template-columns:1fr">
    <div class="auth-main">
      <div class="auth-card" style="text-align:center">
        <div class="empty-icon" style="margin:0 auto 14px">${icon('info', 24)}</div>
        <h1 class="auth-title">We can’t reach the server</h1>
        <p class="auth-sub">Your page lives on Beacon’s server, so we need a connection to load it.</p>
        <p class="tiny muted mt-3" style="word-break:break-word">${esc(error?.message || 'Network request failed')}</p>
        <button class="btn btn-primary btn-block mt-4" onclick="location.reload()">Try again</button>
      </div>
    </div>
  </div>`;
}

async function boot() {
  root.innerHTML = splash();
  try {
    const payload = await api.session();
    hydrateSession(payload);
  } catch (error) {
    if (error.status === 401) {
      clearSession();
    } else {
      root.innerHTML = bootError(error);
      return;
    }
  }
  bindEvents();
  window.addEventListener('hashchange', render);
  render();
}

setRenderer(render);
boot();
