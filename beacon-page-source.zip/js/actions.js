/* All interactive behaviour, wired through data-action attributes. */
import {
  State, uid, clone, snapshot, save, publish, undo as undoState, redo as redoState,
  addContact, completeStep, publicUrl, resetDemo, signOut, visibleBlocks,
  hydrateSession, hasLocalContent, readLocalDoc, clearLegacyDoc,
  generateSampleEvents,
} from './store.js';
import { api } from './api.js';
import {
  esc, icon, toast, openModal, closeModal, rerender, navigate, dialog, copyToClipboard,
} from './ui.js';
import {
  editorUI, BLOCK_TYPES, createBlock, openAddBlockModal, openBlockEditor,
  openBlockMenu, refreshAddResults, shareModal,
} from './views/editor.js';
import { authView } from './views/auth.js';
import { insightsUI } from './views/insights.js';
import {
  audienceUI, refreshContacts, filteredContacts, openBulkTagModal,
} from './views/audience.js';
import { messagingUI, refreshMessageList, configureModal, welcomeModal, threadDetails, sendReply } from './views/messaging.js';
import {
  publicFormModal, getPublicBlock, currentPublicHandle, trackPublicClick,
} from './views/public.js';
import { downloadVCard, downloadMediaKit } from './views/tools.js';
import { PRESETS } from './preview.js';
import { downloadQr } from './qr.js';

let pendingReturn = null;
let handleCheckTimer = null;
export function setReturnTo(hash) { pendingReturn = hash; }

const RESERVED_HANDLES = ['maya.studio', 'admin', 'beacon', 'support', 'help', 'linktree', 'login', 'signup'];

const normalizeUrl = (raw = '') => {
  const v = String(raw).trim();
  if (!v) return '';
  if (/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(v)) return v;
  return `https://${v}`;
};

const isValidUrl = (raw) => {
  try { new URL(normalizeUrl(raw)); return true; } catch { return false; }
};

const validHandle = (h) => /^[a-z0-9._-]{3,30}$/.test(h);

const byPosition = () => [...State.data.blocks].sort((a, b) => a.position - b.position);

function reindex(list) {
  list.forEach((b, i) => { b.position = i; });
  State.data.blocks = list;
}

function findBlock(id) {
  return State.data.blocks.find((b) => b.id === id);
}

/* =====================================================================
   Auth
   ===================================================================== */
async function doSignIn(form) {
  const fd = new FormData(form);
  const email = String(fd.get('email') || '').trim().toLowerCase();
  const password = String(fd.get('password') || '');
  authView.values = { email, password: '' };
  authView.errors = [];
  if (!email) authView.errors.push('Enter the email address on your account.');
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) authView.errors.push('That email address does not look complete.');
  if (!password) authView.errors.push('Enter your password.');
  if (authView.errors.length) {
    rerender();
    document.getElementById('auth-errors')?.focus();
    return;
  }

  authView.loading = true;
  rerender();
  try {
    const payload = await api.signIn(email, password);
    hydrateSession(payload);
    authView.loading = false;
    authView.values = {};
    authView.errors = [];
    toast(`Welcome back, ${payload.user.name.split(' ')[0]}`, 'success');
    const target = pendingReturn && pendingReturn.startsWith('#/app') ? pendingReturn : '#/app';
    pendingReturn = null;
    navigate(target);
    rerender();
  } catch (err) {
    authView.loading = false;
    authView.errors = [err.message || 'Could not sign in. Try again.'];
    rerender();
    document.getElementById('auth-errors')?.focus();
  }
}

async function doSignUp(form) {
  const fd = new FormData(form);
  const name = String(fd.get('name') || '').trim();
  const email = String(fd.get('email') || '').trim().toLowerCase();
  const handle = String(fd.get('handle') || '').trim().toLowerCase();
  const password = String(fd.get('password') || '');
  const terms = fd.get('terms') === 'on';
  authView.values = { name, email, handle, password: '' };
  authView.errors = [];
  if (!name) authView.errors.push('Add a display name so people know who you are.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) authView.errors.push('Enter a valid email address.');
  if (!validHandle(handle)) authView.errors.push('Handles need 3–30 lowercase letters, numbers, dots or dashes.');
  else if (RESERVED_HANDLES.includes(handle)) authView.errors.push(`“${handle}” is not available. Try another handle.`);
  if (password.length < 8) authView.errors.push('Passwords need at least 8 characters.');
  if (!terms) authView.errors.push('Please accept the terms to continue.');

  if (authView.errors.length) {
    rerender();
    document.getElementById('auth-errors')?.focus();
    return;
  }

  authView.loading = true;
  rerender();
  try {
    const payload = await api.signUp({ name, email, handle, password, terms: true });

    // Carry over a page created in the pre-account version of this app.
    let adoptDoc = null;
    if (hasLocalContent()) {
      const legacy = readLocalDoc();
      if (legacy?.doc?.blocks?.length) {
        adoptDoc = {
          ...legacy.doc,
          profile: { ...(legacy.doc.profile || {}), displayName: name, email },
          published: null,
          onboarding: { completed: ['handle'] },
        };
      }
      clearLegacyDoc();
    }
    hydrateSession(payload, { adoptDoc });
    if (adoptDoc) await save({ immediate: true });

    authView.loading = false;
    authView.values = {};
    authView.errors = [];
    toast('Account created — let’s set up your page', 'success');
    pendingReturn = null;
    navigate('#/onboarding');
    rerender();
  } catch (err) {
    authView.loading = false;
    authView.errors = [err.message || 'Could not create your account. Try again.'];
    rerender();
    document.getElementById('auth-errors')?.focus();
  }
}

/* =====================================================================
   Editor
   ===================================================================== */
function saveBlockForm(id) {
  const block = findBlock(id);
  const form = document.getElementById('block-form');
  if (!block || !form) return;
  const fd = new FormData(form);
  const title = String(fd.get('title') ?? block.title).trim();
  const urlRaw = String(fd.get('url') ?? '').trim();
  const start = String(fd.get('scheduleStart') || '');
  const end = String(fd.get('scheduleEnd') || '');

  if (!title && block.kind !== 'divider') {
    toast('Give the block a title first', 'error');
    return;
  }
  if (urlRaw && !isValidUrl(urlRaw)) {
    toast('That URL does not look valid', 'error');
    return;
  }
  if (start && end && new Date(start) > new Date(end)) {
    toast('The hide-after date must be later than the start date', 'error');
    return;
  }

  snapshot();
  block.title = title;
  block.url = urlRaw ? normalizeUrl(urlRaw) : '';
  if (fd.has('description')) block.description = String(fd.get('description')).trim();
  if (fd.has('thumbUrl')) block.thumbUrl = String(fd.get('thumbUrl')).trim();
  if (fd.has('iconUrl')) block.iconUrl = String(fd.get('iconUrl')).trim();
  block.visible = fd.has('visible') ? fd.get('visible') === 'on' : true;
  block.schedule = start || end ? { start: start ? new Date(start).toISOString() : '', end: end ? new Date(end).toISOString() : '' } : null;

  if (fd.has('price')) block.config = { ...block.config, price: String(fd.get('price')).trim() };
  if (fd.has('items')) {
    block.config = {
      ...block.config,
      items: String(fd.get('items')).split('\n').map((s) => s.trim()).filter(Boolean),
    };
  }
  if (fd.has('platform')) block.config = { ...block.config, platform: String(fd.get('platform')) };
  if (fd.has('buttonLabel')) block.config = { ...block.config, buttonLabel: String(fd.get('buttonLabel')).trim() };
  if (fd.has('formType')) block.config = { ...block.config, formType: String(fd.get('formType')) };

  save();
  closeModal();
  rerender();
  completeStep('firstLink');
  toast('Block saved to draft', 'success');
}

function moveBlock(id, direction) {
  const list = byPosition();
  const i = list.findIndex((b) => b.id === id);
  const j = i + direction;
  if (i < 0 || j < 0 || j >= list.length) return;
  snapshot();
  [list[i], list[j]] = [list[j], list[i]];
  reindex(list);
  save();
  rerender();
}

function setTheme(key, value) {
  snapshot();
  const theme = State.data.theme;
  if (key === 'preset') {
    const preset = PRESETS.find((p) => p.id === value);
    if (preset) {
      theme.preset = preset.id;
      theme.background = preset.background;
      theme.wallpaper = preset.wallpaper;
      theme.textColor = preset.textColor;
      theme.accentColor = preset.accentColor;
    }
  } else if (key === 'decorations') {
    theme.decorations = value === 'none' ? [] : [value];
  } else {
    theme[key] = value;
  }
  save();
  rerender();
  completeStep('theme');
}

async function saveHeaderForm() {
  const form = document.querySelector('form[data-form="header"]');
  if (!form) return;
  const fd = new FormData(form);
  const displayName = String(fd.get('displayName') || '').trim();
  const handle = String(fd.get('handle') || '').trim().toLowerCase();
  const bio = String(fd.get('bio') || '').trim();
  const email = String(fd.get('email') || '').trim();

  if (!displayName) { toast('A display name is required', 'error'); return; }
  if (!validHandle(handle) || handle.includes('--')) { toast('Handles need 3–30 lowercase letters, numbers, dots or dashes', 'error'); return; }
  if (RESERVED_HANDLES.includes(handle) && handle !== State.data.workspace.handle) {
    toast('That handle is reserved. Pick another.', 'error'); return;
  }
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { toast('That email does not look valid', 'error'); return; }
  if (handle !== State.data.workspace.handle) {
    try {
      const check = await api.checkHandle(handle);
      if (!check.available) { toast(`beacon.page/p/${handle} is already taken`, 'error'); return; }
    } catch {
      toast('Could not check that handle — check your connection and try again', 'error');
      return;
    }
  }

  const socials = [];
  form.querySelectorAll('[data-social-id]').forEach((row) => {
    const platform = row.querySelector('select')?.value || 'website';
    const url = row.querySelector('input')?.value.trim() || '';
    if (url || true) socials.push({ id: row.dataset.socialId, platform, url: normalizeUrl(url) });
  });

  snapshot();
  State.data.workspace.handle = handle;
  State.data.profile = {
    ...State.data.profile,
    displayName,
    bio,
    email,
    headerAlign: String(fd.get('headerAlign') || 'center'),
    headerSpacing: String(fd.get('headerSpacing') || 'cozy'),
    showSocials: fd.get('showSocials') === 'on',
    socials: socials.filter((s) => s.url),
  };
  save();
  rerender();
  if (State.data.profile.avatarUrl) completeStep('avatar');
  if (State.data.profile.socials.length) completeStep('social');
  toast('Header saved', 'success');
}

function readAvatar(file) {
  if (!file) return;
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
    toast('Use a JPG, PNG or WebP image', 'error');
    return;
  }
  if (file.size > 2 * 1024 * 1024) {
    toast('That image is over 2 MB. Try a smaller crop.', 'error');
    return;
  }
  const bar = document.getElementById('avatar-progress');
  if (bar) bar.classList.remove('hide');
  const reader = new FileReader();
  reader.onprogress = (e) => {
    if (bar && e.lengthComputable) bar.firstElementChild.style.width = `${Math.round((e.loaded / e.total) * 100)}%`;
  };
  reader.onload = () => {
    snapshot();
    State.data.profile.avatarUrl = String(reader.result);
    save();
    completeStep('avatar');
    rerender();
    toast('Photo updated', 'success');
  };
  reader.onerror = () => toast('We could not read that file', 'error');
  reader.readAsDataURL(file);
}

async function publishPage() {
  const list = visibleBlocks(State.data.blocks);
  if (!list.length) {
    const ok = await dialog({
      title: 'Publish an empty page?',
      message: 'There are no visible blocks. Visitors will see your header and a note that nothing is here yet.',
      confirmLabel: 'Publish anyway',
    });
    if (!ok) return;
  }
  await publish();
  completeStep('publish');
  rerender();
  toast('Published — your page is live', 'success');
}

/* =====================================================================
   Public page
   ===================================================================== */
function openPublicForm(block) {
  const isMessage = block.kind === 'message';
  const { title, subtitle, body } = publicFormModal(block);
  openModal({
    title,
    subtitle,
    body,
    footer: `<button class="btn btn-outline" data-action="modal-close">Cancel</button>
      <button class="btn btn-primary" data-action="public-form-submit" data-kind="${isMessage ? 'message' : 'form'}">
        ${isMessage ? 'Send message' : (block.config?.buttonLabel || 'Subscribe')}
      </button>`,
  });
}

/* =====================================================================
   Action map
   ===================================================================== */
export const actions = {
  /* ---------- global ---------- */
  'modal-close': () => closeModal(),

  undo() {
    if (!undoState()) { toast('Nothing to undo'); return; }
    rerender();
    toast('Undone');
  },
  redo() {
    if (!redoState()) { toast('Nothing to redo'); return; }
    rerender();
    toast('Redone');
  },
  publish: () => publishPage(),
  share: () => shareModal(),
  async 'copy-url'() {
    await copyToClipboard(publicUrl());
    toast('Public link copied', 'success');
  },
  async 'native-share'() {
    const url = publicUrl();
    if (navigator.share) {
      try { await navigator.share({ title: `${State.data.profile.displayName} on Beacon`, url }); return; } catch { /* cancelled */ }
    }
    await copyToClipboard(url);
    toast('Sharing is unavailable here — link copied instead');
  },
  'magic-link': () => toast('Magic links need an email service. Sign in with your password instead.'),
  sso: () => toast('SSO is not enabled for this workspace.'),

  'toggle-preview'() {
    const aside = document.querySelector('.editor-preview');
    const body = document.querySelector('.editor-body');
    if (!aside || !body) return;
    aside.classList.toggle('is-open');
    body.classList.toggle('preview-open');
  },

  /* ---------- editor ---------- */
  'open-add'() {
    editorUI.search = '';
    editorUI.cat = 'Suggested';
    openAddBlockModal();
  },
  'add-cat'(el) {
    editorUI.cat = el.dataset.cat;
    document.querySelectorAll('.add-cat').forEach((b) => {
      const on = b.dataset.cat === editorUI.cat;
      b.classList.toggle('active', on);
      b.setAttribute('aria-selected', String(on));
    });
    refreshAddResults();
  },
  'add-block'(el) {
    const type = BLOCK_TYPES.find((t) => t.id === el.dataset.type);
    if (!type) return;
    const block = createBlock(type.id);
    closeModal();
    rerender();
    if (block.kind === 'divider') {
      toast('Divider added', 'success');
      return;
    }
    openBlockEditor(block.id);
  },
  'save-block': (el) => saveBlockForm(el.dataset.id),
  async 'block-delete'(el) {
    const block = findBlock(el.dataset.id);
    if (!block) return;
    closeModal();
    const ok = await dialog({
      title: 'Delete this block?',
      message: `“${block.title || 'Untitled'}” will be removed from your page. You can publish afterwards, but the block cannot be recovered.`,
      confirmLabel: 'Delete block',
      danger: true,
    });
    if (!ok) return;
    snapshot();
    State.data.blocks = State.data.blocks.filter((b) => b.id !== block.id);
    reindex(byPosition());
    save();
    rerender();
    toast('Block deleted', 'success');
  },
  'block-duplicate'(el) {
    const block = findBlock(el.dataset.id);
    if (!block) return;
    snapshot();
    const copy = clone(block);
    copy.id = uid('blk');
    copy.title = `${block.title} (copy)`;
    copy.position = block.position + 0.5;
    State.data.blocks.push(copy);
    reindex(byPosition());
    save();
    closeModal();
    rerender();
    toast('Block duplicated', 'success');
  },
  'block-archive'(el) {
    const block = findBlock(el.dataset.id);
    if (!block) return;
    snapshot();
    State.data.archived.push({ ...clone(block), archivedAt: new Date().toISOString() });
    State.data.blocks = State.data.blocks.filter((b) => b.id !== block.id);
    reindex(byPosition());
    save();
    closeModal();
    rerender();
    toast('Block archived', 'success');
  },
  'block-toggle'(el) {
    const block = findBlock(el.dataset.id);
    if (!block) return;
    snapshot();
    block.visible = !block.visible;
    save();
    closeModal();
    rerender();
    toast(block.visible ? 'Block is visible' : 'Block hidden from your page');
  },
  'block-edit': (el) => openBlockEditor(el.dataset.id),
  'block-menu': (el) => openBlockMenu(el.dataset.id),
  'block-up': (el) => moveBlock(el.dataset.id, -1),
  'block-down': (el) => moveBlock(el.dataset.id, 1),
  'block-focus'(el) {
    el.closest('[data-block-row]')?.focus();
  },
  'set-theme': (el) => setTheme(el.dataset.key, el.dataset.value),
  'pro-tip': () => toast('This is a Plus style — free to try in the demo.'),
  'remove-avatar': async () => {
    const ok = await dialog({
      title: 'Remove your photo?',
      message: 'Your page will fall back to a colored monogram instead.',
      confirmLabel: 'Remove photo',
      danger: true,
    });
    if (!ok) return;
    snapshot();
    State.data.profile.avatarUrl = '';
    save();
    rerender();
    toast('Photo removed');
  },
  'add-social'() {
    snapshot();
    State.data.profile.socials.push({ id: uid('soc'), platform: 'instagram', url: '' });
    save();
    rerender();
  },
  'remove-social'(el) {
    snapshot();
    State.data.profile.socials = State.data.profile.socials.filter((s) => s.id !== el.dataset.id);
    save();
    rerender();
  },

  /* ---------- insights ---------- */
  'set-range'(el) {
    insightsUI.range = Number(el.dataset.range);
    rerender();
  },
  'insights-info'() {
    openModal({
      title: 'How these numbers work',
      body: `<div class="col gap-3 small">
        <p><strong>Views</strong> count page loads. <strong>Clicks</strong> count taps on any block.</p>
        <p><strong>Contacts</strong> are people who submitted a form or messaged you.</p>
        <p>Your page, links, contacts and analytics are stored on Beacon’s server so they follow you between browsers. No third-party tracking scripts are loaded.</p>
      </div>`,
      footer: '<button class="btn btn-primary" data-action="modal-close">Got it</button>',
    });
  },
  'toggle-sample'() {
    State.data.demoAnalytics = !State.data.demoAnalytics;
    if (State.data.demoAnalytics && State.data.events.length === 0) {
      State.data.events = generateSampleEvents(30);
      toast('Sample analytics shown — hide them any time', 'success');
    } else {
      toast(State.data.demoAnalytics ? 'Sample data shown' : 'Sample data hidden');
    }
    save();
    rerender();
  },

  /* ---------- audience ---------- */
  'activate-subscribe'() {
    State.data.subscribe.enabled = true;
    save();
    if (!State.data.blocks.some((b) => b.kind === 'form')) {
      const block = createBlock('form');
      block.title = 'Join my newsletter';
      block.description = 'One email a week. Unsubscribe any time.';
      block.config = { formType: 'subscribe', buttonLabel: 'Subscribe' };
      save();
    }
    rerender();
    toast('Subscribe is live on your page', 'success');
  },
  'disable-subscribe'() {
    State.data.subscribe.enabled = false;
    save();
    rerender();
    toast('Subscribe turned off');
  },
  'preview-subscribe'() {
    openModal({
      title: 'Subscribe form preview',
      subtitle: 'This is what visitors see on your page.',
      body: `<form data-form="public-subscribe" data-block-id="preview" id="public-form">
        <div class="field"><label class="field-label" for="pf-name">Name</label><input class="input" id="pf-name" name="name" /></div>
        <div class="field"><label class="field-label" for="pf-email">Email</label><input class="input" id="pf-email" name="email" type="email" required /></div>
        <label class="checkbox"><input type="checkbox" name="consent" required /><span class="tiny">${esc(State.data.subscribe.consentText)}</span></label>
      </form>`,
      footer: '<button class="btn btn-outline" data-action="modal-close">Close</button><button class="btn btn-primary" data-action="public-form-submit" data-kind="form">Subscribe</button>',
    });
  },
  'export-contacts'() {
    import('./views/audience.js').then((m) => m.exportContacts());
  },
  'add-contact': () => import('./views/audience.js').then((m) => m.addContactModal()),
  'save-contact'() {
    const form = document.getElementById('add-contact-form');
    if (!form) return;
    const fd = new FormData(form);
    const email = String(fd.get('email') || '').trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { toast('Enter a valid email', 'error'); return; }
    addContact({ name: String(fd.get('name') || '').trim(), email, source: String(fd.get('source') || 'Manual') });
    closeModal();
    rerender();
    toast('Contact added', 'success');
  },
  'delete-contact': async (el) => {
    const c = State.data.contacts.find((x) => x.id === el.dataset.id);
    if (!c) return;
    const ok = await dialog({
      title: 'Remove contact?',
      message: `${c.name || c.email} will be removed from your audience list.`,
      confirmLabel: 'Remove', danger: true,
    });
    if (!ok) return;
    State.data.contacts = State.data.contacts.filter((x) => x.id !== c.id);
    audienceUI.selected.delete(c.id);
    save();
    rerender();
    toast('Contact removed');
  },

  /* ---------- bulk contact actions ---------- */
  'bulk-clear'() {
    audienceUI.selected.clear();
    refreshContacts();
  },
  'bulk-tag'() {
    openBulkTagModal();
  },
  'save-bulk-tags'() {
    const form = document.getElementById('bulk-tags-form');
    if (!form) return;
    const ids = new Set(audienceUI.selected);
    if (!ids.size) { toast('No contacts selected', 'error'); return; }
    const fd = new FormData(form);
    const tags = new Set();
    fd.getAll('tag').forEach((t) => { if (String(t).trim()) tags.add(String(t).trim()); });
    String(fd.get('newTags') || '').split(',').forEach((t) => {
      const value = t.trim();
      if (value) tags.add(value);
    });
    if (!tags.size) { toast('Pick an existing tag or type a new one', 'error'); return; }
    let touched = 0;
    State.data.contacts.forEach((c) => {
      if (!ids.has(c.id)) return;
      c.tags = [...new Set([...(c.tags || []), ...tags])];
      touched += 1;
    });
    save();
    audienceUI.selected.clear();
    closeModal();
    rerender();
    toast(`Added ${tags.size} tag${tags.size === 1 ? '' : 's'} to ${touched} contact${touched === 1 ? '' : 's'}`, 'success');
  },
  async 'bulk-delete'() {
    const ids = new Set(audienceUI.selected);
    if (!ids.size) return;
    const ok = await dialog({
      title: `Delete ${ids.size} contact${ids.size === 1 ? '' : 's'}?`,
      message: 'They will be removed from your audience list and from any exports. This cannot be undone.',
      confirmLabel: `Delete ${ids.size}`,
      danger: true,
    });
    if (!ok) return;
    State.data.contacts = State.data.contacts.filter((c) => !ids.has(c.id));
    audienceUI.selected.clear();
    save();
    rerender();
    toast(`${ids.size} contact${ids.size === 1 ? '' : 's'} deleted`, 'success');
  },
  'contacts-page'(el) {
    audienceUI.page = Number(el.dataset.page);
    refreshContacts();
  },
  'clear-contact-filters'() {
    audienceUI.q = '';
    audienceUI.source = 'all';
    audienceUI.page = 1;
    audienceUI.selected.clear();
    rerender();
  },
  'tool-form'() {
    const block = createBlock('form');
    block.title = 'Contact form';
    block.config = { formType: 'contact', buttonLabel: 'Send' };
    save();
    navigate('#/app/editor/content');
    rerender();
    openBlockEditor(block.id);
  },
  'tool-download'() {
    const block = createBlock('download');
    block.title = 'Free download';
    block.config = { formType: 'download', buttonLabel: 'Get the file' };
    save();
    navigate('#/app/editor/content');
    rerender();
    openBlockEditor(block.id);
  },
  'tool-soon': () => toast('Setup for this tool is not wired up in the demo yet.'),
  'integration-request': () => toast('Thanks — integration requests are simulated in this demo.'),
  'clear-msg-filters'() {
    messagingUI.q = '';
    messagingUI.filter = 'all';
    rerender();
  },

  /* ---------- messaging ---------- */
  'open-conversation'(el) {
    messagingUI.activeId = el.dataset.id;
    messagingUI.showConvo = true;
    const convo = State.data.conversations.find((c) => c.id === el.dataset.id);
    if (convo) { convo.unread = 0; save(); }
    rerender();
  },
  'back-to-list'() {
    messagingUI.showConvo = false;
    rerender();
  },
  'msg-tab'(el) {
    messagingUI.tab = el.dataset.tab;
    rerender();
  },
  'msg-filter'(el) {
    messagingUI.filter = el.dataset.filter;
    rerender();
  },
  'msg-details': (el) => threadDetails(el.dataset.id),
  'configure-messaging': () => configureModal(),
  'edit-welcome': () => welcomeModal(),
  'save-messaging'() {
    const form = document.getElementById('msg-config-form');
    if (!form) return;
    const fd = new FormData(form);
    State.data.messaging.configured = fd.get('configured') === 'on';
    State.data.messaging.welcome = String(fd.get('welcome') || '').trim();
    save();
    closeModal();
    rerender();
    toast('Messaging settings saved', 'success');
  },
  'save-welcome'() {
    const form = document.getElementById('welcome-form');
    if (!form) return;
    State.data.messaging.welcome = String(new FormData(form).get('welcome') || '').trim();
    save();
    closeModal();
    rerender();
    toast('Welcome message saved', 'success');
  },
  'delete-conversation': async (el) => {
    const ok = await dialog({ title: 'Delete this thread?', message: 'The conversation will be removed from your inbox.', confirmLabel: 'Delete', danger: true });
    if (!ok) return;
    State.data.conversations = State.data.conversations.filter((c) => c.id !== el.dataset.id);
    messagingUI.activeId = State.data.conversations[0]?.id || null;
    save();
    closeModal();
    rerender();
    toast('Thread deleted');
  },

  /* ---------- public page ---------- */
  'public-block'(el) {
    const block = getPublicBlock(el.dataset.blockId);
    if (!block) return;
    if (block.kind === 'form' || block.kind === 'message') openPublicForm(block);
  },
  async 'share-public'() {
    const handle = currentPublicHandle();
    await copyToClipboard(`${location.origin}${location.pathname}#/p/${handle}`);
    toast('Page link copied', 'success');
  },
  'public-form-submit'() {
    document.getElementById('public-form')?.requestSubmit();
  },
  'public-report': () => toast('Reported. This demo has no moderation queue, but the tap is recorded.'),

  /* ---------- business cards / media kit ---------- */
  'bc-color'(el) {
    State.data.tools.businessCard.background = el.dataset.color;
    save();
    rerender();
  },
  'wallet-apple': () => toast('Apple Wallet passes need a signed pass certificate — simulated here.'),
  'wallet-google': () => toast('Google Wallet passes need an issuer account — simulated here.'),
  'download-card': () => downloadVCard(),
  'download-qr': () => {
    const saved = downloadQr(publicUrl(), `beacon-${State.data.workspace.handle}-qr.png`, { size: 1024 });
    toast(saved ? 'QR code saved as a PNG' : 'This browser cannot save the image', saved ? 'success' : 'error');
  },
  'start-mediakit'() {
    State.data.tools.mediaKit.enabled = true;
    save();
    rerender();
    toast('Media kit created', 'success');
  },
  'disable-mediakit'() {
    State.data.tools.mediaKit.enabled = false;
    save();
    rerender();
    toast('Media kit turned off');
  },
  'mediakit-privacy': () => import('./views/tools.js').then((m) => m.mediakitPrivacyModal()),
  'save-mediakit-privacy'() {
    const form = document.querySelector('form[data-form="mediakit-privacy"]');
    if (!form) return;
    const fd = new FormData(form);
    State.data.tools.mediaKit.shareStats = fd.get('shareStats') === 'on';
    State.data.tools.mediaKit.contactEmail = String(fd.get('contactEmail') || '').trim();
    save();
    closeModal();
    rerender();
    toast('Media kit privacy saved', 'success');
  },
  'download-mediakit': () => downloadMediaKit(),
  async 'copy-mediakit'() {
    await copyToClipboard(`${publicUrl()}?kit=1`);
    toast('Media kit link copied', 'success');
  },

  /* ---------- settings ---------- */
  async 'sign-out'() {
    try { await api.signOut(); } catch { /* session may already be gone */ }
    signOut();
    authView.values = {};
    authView.errors = [];
    toast('Signed out');
    navigate('#/auth/sign-in');
    rerender();
  },
  'reset-demo': async () => {
    const ok = await dialog({
      title: 'Reset workspace content?',
      message: 'Your edits, contacts and analytics will be replaced with the original sample workspace.',
      confirmLabel: 'Reset everything', danger: true,
    });
    if (!ok) return;
    resetDemo();
    toast('Demo data restored', 'success');
    navigate('#/app');
    rerender();
  },
  upgrade: () => toast('Billing is disabled here — every Plus style is already unlocked.'),
  'export-data'() {
    const payload = {
      exportedAt: new Date().toISOString(),
      workspace: State.data.workspace,
      profile: State.data.profile,
      theme: State.data.theme,
      blocks: State.data.blocks,
      contacts: State.data.contacts,
      events: State.data.events,
      conversations: State.data.conversations,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'beacon-workspace.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(a.href);
    toast('Data exported', 'success');
  },
  'delete-account': async () => {
    const ok = await dialog({
      title: 'Delete this account?',
      message: 'This removes your account, page, links, contacts and analytics from the server. There is no undo.',
      confirmLabel: 'Delete account',
      danger: true,
      requireText: 'DELETE',
    });
    if (!ok) return;
    try {
      await api.deleteAccount();
    } catch (err) {
      toast(err.message || 'Could not delete the account', 'error');
      return;
    }
    signOut();
    toast('Account deleted');
    navigate('#/auth/sign-up');
    rerender();
  },

  /* ---------- assistant ---------- */
  'assistant-toggle'() {
    if (!State.data.assistant) {
      State.data.assistant = { open: false, messages: [] };
    }
    State.data.assistant.open = !State.data.assistant.open;
    save();
    rerender();
  },
  'assistant-ask'(el) {
    askAssistant(el.dataset.q || '');
  },
};

function askAssistant(question) {
  const q = question.trim();
  if (!q) return;
  const a = State.data.assistant;
  a.messages.push({ id: uid('a'), from: 'me', text: q });
  const low = q.toLowerCase();
  let reply = 'I can help with links, design, insights and your inbox. Try “how do I publish?” or “where are my contacts?”.';
  if (low.includes('publish')) reply = 'Publishing copies your current draft to the live page. The Publish button sits top-right in the editor — your draft badge turns green when everything is live.';
  else if (low.includes('link')) reply = 'Open Links in the sidebar, then Add. You can drag to reorder or use the arrow buttons. New blocks stay in draft until you publish.';
  else if (low.includes('design') || low.includes('theme') || low.includes('colour') || low.includes('color')) reply = 'Design has themes, wallpaper, button shapes, fonts and colors. Every change updates the phone preview instantly and can be undone from the top bar.';
  else if (low.includes('contact') || low.includes('audience') || low.includes('subscrib')) reply = 'Audience holds everyone who subscribed or messaged you. Activate Subscribe to add a signup form to your page, then export the list any time as CSV.';
  else if (low.includes('message') || low.includes('inbox') || low.includes('reply')) reply = 'Messaging collects everything sent from your Message block. You can set a welcome message under Configure and reply directly from the thread.';
  else if (low.includes('card') || low.includes('qr')) reply = 'Business cards live under Tools. Set a colour and display name, then download the vCard or save your QR code.';
  else if (low.includes('analytic') || low.includes('insight') || low.includes('view') || low.includes('click')) reply = 'Insights shows views, clicks, contacts and traffic sources with a 7, 30 or 90 day range. Toggle sample data off to see the empty states.';
  else if (low.includes('delete')) reply = 'To delete a block use its ⋯ menu. Deleting your whole account lives in Settings → Privacy & data, and requires typing DELETE.';
  a.messages.push({ id: uid('a'), from: 'bot', text: reply });
  save();
  rerender();
  requestAnimationFrame(() => {
    const log = document.querySelector('.assistant-log');
    if (log) log.scrollTop = log.scrollHeight;
  });
}

/* =====================================================================
   Delegated listeners
   ===================================================================== */
export function bindEvents() {
  document.addEventListener('click', (e) => {
    const publicLink = e.target.closest('[data-track-block]');
    if (publicLink) trackPublicClick(publicLink.dataset.trackBlock);
    const el = e.target.closest('[data-action]');
    if (!el) {
      const backdrop = e.target.closest('[data-backdrop]');
      if (backdrop) closeModal();
      return;
    }
    const action = el.dataset.action;
    if (action === 'dialog-confirm' || action === 'dialog-cancel') return;
    const fn = actions[action];
    if (!fn) return;
    e.preventDefault();
    try {
      fn(el, e);
    } catch (err) {
      console.error('Beacon action failed:', action, err);
      toast('Something went wrong. Try again.', 'error');
    }
  });

  document.addEventListener('submit', async (e) => {
    const form = e.target.closest('form[data-form]');
    if (!form) return;
    e.preventDefault();
    const kind = form.dataset.form;

    if (kind === 'sign-in') return doSignIn(form);
    if (kind === 'sign-up') return doSignUp(form);
    if (kind === 'reset') {
      const email = String(new FormData(form).get('email') || '');
      authView.errors = [];
      authView.notice = '';
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        authView.errors = ['Enter the email address on your account.'];
        rerender();
        return;
      }
      authView.values = { email };
      authView.notice = `If ${email} is on file, a reset link is on its way. (Simulated — no email is sent.)`;
      rerender();
      return;
    }
    if (kind === 'header') return saveHeaderForm();
    if (kind === 'block') return saveBlockForm(form.dataset.blockId);
    if (kind === 'compose') {
      const fd = new FormData(form);
      sendReply(form.dataset.convoId, String(fd.get('message') || ''));
      rerender();
      return;
    }
    if (kind === 'bulk-tags') { actions['save-bulk-tags'](); return; }
    if (kind === 'public-message' || kind === 'public-subscribe') {
      const fd = new FormData(form);
      const email = String(fd.get('email') || '').trim();
      const name = String(fd.get('name') || '').trim();
      const message = String(fd.get('message') || '').trim();
      const handle = currentPublicHandle();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { toast('Enter a valid email so the creator can reply', 'error'); return; }
      if (fd.get('consent') === null) { toast('Please tick the consent box', 'error'); return; }
      if (kind === 'public-message' && message.length < 2) { toast('Write a short message first', 'error'); return; }
      if (!handle) { toast('This form is not connected to a page', 'error'); return; }
      const button = document.querySelector('[data-action="public-form-submit"]');
      if (button) { button.disabled = true; button.textContent = 'Sending…'; }
      try {
        await api.publicContact(handle, {
          kind: kind === 'public-message' ? 'message' : 'subscribe',
          name, email, message, consent: true,
        });
      } catch (err) {
        toast(err.message || 'Could not send that — try again.', 'error');
        if (button) { button.disabled = false; button.textContent = 'Try again'; }
        return;
      }
      closeModal();
      toast(kind === 'public-message' ? 'Message sent — the creator has it now' : 'You are on the list. Thank you!', 'success');
      rerender();
      return;
    }
    if (kind === 'business-card') {
      const form2 = document.querySelector('form[data-form="business-card"]');
      const bcfd = new FormData(form2);
      State.data.tools.businessCard = {
        ...State.data.tools.businessCard,
        displayName: String(bcfd.get('displayName') || '').trim(),
        jobTitle: String(bcfd.get('jobTitle') || '').trim(),
        email: String(bcfd.get('email') || '').trim(),
        phone: String(bcfd.get('phone') || '').trim(),
        website: String(bcfd.get('website') || '').trim(),
        showEmail: bcfd.get('showEmail') === 'on',
        showPhone: bcfd.get('showPhone') === 'on',
        showWebsite: bcfd.get('showWebsite') === 'on',
      };
      save();
      rerender();
      toast('Card details saved', 'success');
      return;
    }
    if (kind === 'account') {
      const fd = new FormData(form);
      const name = String(fd.get('name') || '').trim();
      const email = String(fd.get('email') || '').trim();
      const currentPassword = String(fd.get('currentPassword') || '');
      const pw = String(fd.get('password') || '');
      if (!name) { toast('A name is required', 'error'); return; }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { toast('That email does not look valid', 'error'); return; }
      if (pw && pw.length < 8) { toast('Passwords need at least 8 characters', 'error'); return; }
      if (pw && !currentPassword) { toast('Enter your current password to change it', 'error'); return; }
      try {
        const profileResult = await api.updateProfile(name, email);
        if (pw) await api.changePassword(currentPassword, pw);
        State.data.account = { ...State.data.account, ...profileResult.user };
        State.data.session = { ...State.data.session, name, email };
        State.data.workspace = { ...State.data.workspace, name };
        save({ immediate: true });
        rerender();
        toast('Account saved', 'success');
      } catch (err) {
        toast(err.message || 'Could not save your account', 'error');
      }
      return;
    }
    if (kind === 'public-profile') {
      const fd = new FormData(form);
      const handle = String(fd.get('handle') || '').trim().toLowerCase();
      const displayName = String(fd.get('displayName') || '').trim();
      if (!validHandle(handle)) { toast('Handles need 3–30 lowercase letters, numbers, dots or dashes', 'error'); return; }
      if (RESERVED_HANDLES.includes(handle) && handle !== State.data.workspace.handle) { toast('That handle is reserved', 'error'); return; }
      if (!displayName) { toast('A display name is required', 'error'); return; }
      State.data.workspace.handle = handle;
      State.data.profile.displayName = displayName;
      State.data.profile.bio = String(fd.get('bio') || '').trim();
      State.data.settings.publicProfile.showInSearch = fd.get('showInSearch') === 'on';
      State.data.settings.publicProfile.showContactButton = fd.get('showContactButton') === 'on';
      save();
      rerender();
      toast('Public profile saved', 'success');
      return;
    }
    if (kind === 'workspace') {
      State.data.workspace.name = String(new FormData(form).get('name') || '').trim() || State.data.workspace.name;
      save();
      rerender();
      toast('Workspace saved', 'success');
      return;
    }
    if (kind === 'assistant') {
      const value = String(new FormData(form).get('message') || '');
      form.reset();
      askAssistant(value);
      return;
    }
  });

  document.addEventListener('input', (e) => {
    const el = e.target.closest('[data-input]');
    if (el) {
      const kind = el.dataset.input;
      if (kind === 'contact-search') {
        audienceUI.q = el.value;
        audienceUI.page = 1;
        audienceUI.selected.clear();
        refreshContacts();
      } else if (kind === 'add-search') {
        editorUI.search = el.value;
        refreshAddResults();
      } else if (kind === 'msg-search') {
        messagingUI.q = el.value;
        refreshMessageList();
      } else if (kind === 'bc-name' || kind === 'bc-role') {
        const key = kind === 'bc-name' ? 'displayName' : 'jobTitle';
        State.data.tools.businessCard[key] = el.value;
        save();
        const target = document.getElementById(kind === 'bc-name' ? 'bc-preview-name' : 'bc-preview-role');
        if (target) target.textContent = el.value || (kind === 'bc-name' ? 'Your name' : '');
      }
    }

    const handleInput = e.target.closest('[data-handle-input]');
    if (handleInput) {
      const status = document.getElementById('handle-status');
      if (!status) return;
      const value = handleInput.value.trim().toLowerCase();
      clearTimeout(handleCheckTimer);
      if (!value) { status.textContent = ''; status.className = 'handle-status'; return; }
      if (!validHandle(value)) {
        status.textContent = '3–30 lowercase letters, numbers, dots or dashes.';
        status.className = 'handle-status bad';
        return;
      }
      if (RESERVED_HANDLES.includes(value)) {
        status.textContent = 'That handle is taken. Try another.';
        status.className = 'handle-status bad';
        return;
      }
      status.textContent = 'Checking availability…';
      status.className = 'handle-status';
      handleCheckTimer = setTimeout(async () => {
        try {
          const result = await api.checkHandle(value);
          if (handleInput.value.trim().toLowerCase() !== value) return;
          if (result.available) {
            status.textContent = `beacon.page/p/${value} is available`;
            status.className = 'handle-status ok';
          } else {
            status.textContent = 'That handle is taken. Try another.';
            status.className = 'handle-status bad';
          }
        } catch {
          status.textContent = 'Could not check that handle — try again.';
          status.className = 'handle-status bad';
        }
      }, 350);
    }
  });

  document.addEventListener('change', (e) => {
    const pick = e.target.closest('[data-select]');
    if (pick) {
      const mode = pick.dataset.select;
      if (mode === 'all') {
        const ids = filteredContacts().map((c) => c.id);
        if (pick.checked) ids.forEach((id) => audienceUI.selected.add(id));
        else ids.forEach((id) => audienceUI.selected.delete(id));
      } else if (pick.dataset.id) {
        if (pick.checked) audienceUI.selected.add(pick.dataset.id);
        else audienceUI.selected.delete(pick.dataset.id);
      }
      refreshContacts();
      return;
    }
    const upload = e.target.closest('[data-upload]');
    if (upload && upload.files?.[0]) {
      readAvatar(upload.files[0]);
      return;
    }
    const toggle = e.target.closest('[data-toggle]');
    if (toggle) {
      const kind = toggle.dataset.toggle;
      const id = toggle.dataset.id;
      if (kind === 'integration') {
        State.data.settings.integrations[id] = toggle.checked;
        save();
        rerender();
        toast(`${id} ${toggle.checked ? 'connected' : 'disconnected'}`);
      } else if (kind === 'notification') {
        State.data.settings.notifications[id] = toggle.checked;
        save();
        toast('Notification preference saved');
      } else if (kind === 'sample') {
        State.data.demoAnalytics = toggle.checked;
        save();
        rerender();
      } else if (kind === 'bc-show') {
        State.data.tools.businessCard[id] = toggle.checked;
        save();
        rerender();
      }
      return;
    }
    const select = e.target.closest('[data-input]');
    if (select && select.tagName === 'SELECT' && select.dataset.input === 'contact-source') {
      audienceUI.source = select.value;
      audienceUI.page = 1;
      audienceUI.selected.clear();
      refreshContacts();
    }
  });

  document.addEventListener('keydown', (e) => {
    const row = e.target.closest?.('[data-block-row]');
    if (row && e.altKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) {
      e.preventDefault();
      moveBlock(row.dataset.blockRow, e.key === 'ArrowUp' ? -1 : 1);
      requestAnimationFrame(() => {
        document.querySelector(`[data-block-row="${row.dataset.blockRow}"]`)?.focus();
      });
    }
    if (e.key === 'Escape') {
      const proposal = document.querySelector('.assistant-panel');
      if (proposal && State.data.assistant.open && !document.querySelector('.backdrop')) {
        State.data.assistant.open = false;
        save();
        rerender();
      }
    }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z' && document.querySelector('.editor')) {
      e.preventDefault();
      if (e.shiftKey) actions.redo(); else actions.undo();
    }
  });

  /* drag & drop reordering */
  let dragId = null;
  document.addEventListener('dragstart', (e) => {
    const row = e.target.closest?.('[data-block-row]');
    if (!row) return;
    dragId = row.dataset.blockRow;
    row.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
    try { e.dataTransfer.setData('text/plain', dragId); } catch { /* noop */ }
  });
  document.addEventListener('dragend', () => {
    document.querySelectorAll('.block.dragging, .block.drop-target').forEach((el) => el.classList.remove('dragging', 'drop-target'));
    dragId = null;
  });
  document.addEventListener('dragover', (e) => {
    const row = e.target.closest?.('[data-block-row]');
    if (!row || !dragId || row.dataset.blockRow === dragId) return;
    e.preventDefault();
    document.querySelectorAll('.block.drop-target').forEach((el) => el.classList.remove('drop-target'));
    row.classList.add('drop-target');
  });
  document.addEventListener('drop', (e) => {
    const row = e.target.closest?.('[data-block-row]');
    if (!row || !dragId) return;
    e.preventDefault();
    const list = byPosition();
    const from = list.findIndex((b) => b.id === dragId);
    const to = list.findIndex((b) => b.id === row.dataset.blockRow);
    if (from < 0 || to < 0 || from === to) return;
    snapshot();
    const [moved] = list.splice(from, 1);
    list.splice(to, 0, moved);
    reindex(list);
    save();
    dragId = null;
    rerender();
  });
}
