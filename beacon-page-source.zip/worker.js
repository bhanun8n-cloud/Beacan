/**
 * Beacon Page — server API on Cloudflare Workers + D1.
 *
 * Accounts are app-owned: email + password (PBKDF2-SHA256), HttpOnly session
 * cookies stored as hashes. Workspaces (profile, design, links, contacts,
 * messaging, settings) persist in D1 so they follow a user between browsers.
 * Static files are served from the ASSETS binding.
 */

const SESSION_COOKIE = 'beacon_session';
const SESSION_DAYS = 30;
// Cloudflare's WebCrypto rejects PBKDF2 above 100,000 iterations.
const PBKDF2_ITERATIONS = 100000;
const MAX_DOC_BYTES = 900000;
const RESERVED_HANDLES = new Set(['admin', 'beacon', 'support', 'help', 'linktree', 'login', 'signup', 'maya.studio']);
const SOURCE_LABEL = 'Beacon Page';

const THEME = {
  preset: 'Aurora',
  background: 'linear-gradient(165deg, #ece5ff 0%, #f8f4ff 48%, #eaf9d5 100%)',
  wallpaper: 'blob',
  buttonStyle: 'rounded',
  buttonColor: '#ffffff',
  fontFamily: 'Inter',
  textColor: '#1f1f1f',
  accentColor: '#6b28d9',
  decorations: ['sparkle'],
};

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */
const enc = new TextEncoder();

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff',
      ...extraHeaders,
    },
  });
}

const fail = (status, error, message) => json({ error, message }, status);

function b64url(bytes) {
  let binary = '';
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '');
}

function b64ToBytes(value) {
  const binary = atob(value);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) out[i] = binary.charCodeAt(i);
  return out;
}

const bytesToB64 = (bytes) => btoa(String.fromCharCode(...bytes));

async function sha256Hex(text) {
  const digest = await crypto.subtle.digest('SHA-256', enc.encode(text));
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function derivePassword(password, saltB64) {
  const salt = saltB64 ? b64ToBytes(saltB64) : crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
    key,
    256,
  );
  return { salt: bytesToB64(salt), hash: bytesToB64(new Uint8Array(bits)) };
}

function safeEqual(a, b) {
  const length = Math.max(a.length, b.length);
  let diff = a.length ^ b.length;
  for (let i = 0; i < length; i += 1) {
    diff |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
  }
  return diff === 0;
}

const isEmail = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
const isHandle = (value) => /^[a-z0-9._-]{3,30}$/.test(value);

function sessionCookie(token, secure) {
  const parts = [
    `${SESSION_COOKIE}=${token}`,
    'Path=/',
    'HttpOnly',
    'SameSite=Lax',
    `Max-Age=${SESSION_DAYS * 86400}`,
  ];
  if (secure) parts.push('Secure');
  return parts.join('; ');
}
const clearCookie = (secure) => `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure ? '; Secure' : ''}`;

function readCookie(request, name) {
  const header = request.headers.get('cookie') || '';
  for (const part of header.split(';')) {
    const [key, ...rest] = part.trim().split('=');
    if (key === name) return rest.join('=');
  }
  return null;
}

async function readJson(request) {
  const type = request.headers.get('content-type') || '';
  if (!type.includes('application/json')) return null;
  const text = await request.text();
  if (text.length > MAX_DOC_BYTES + 50000) return null;
  try { return JSON.parse(text); } catch { return null; }
}

function sameOrigin(request, url) {
  const origin = request.headers.get('origin');
  if (!origin) return true; // non-browser clients (curl, health checks)
  try { return new URL(origin).host === url.host; } catch { return false; }
}

/* ------------------------------------------------------------------ */
/* rate limiting (per isolate, best effort)                            */
/* ------------------------------------------------------------------ */
const buckets = new Map();
function rateLimit(key, limit, windowMs) {
  const now = Date.now();
  const bucket = buckets.get(key) || { count: 0, reset: now + windowMs };
  if (now > bucket.reset) { bucket.count = 0; bucket.reset = now + windowMs; }
  bucket.count += 1;
  buckets.set(key, bucket);
  if (buckets.size > 5000) buckets.clear();
  return bucket.count <= limit;
}
const clientKey = (request, scope) =>
  `${scope}:${request.headers.get('cf-connecting-ip') || 'local'}`;

/* ------------------------------------------------------------------ */
/* schema + data access                                                */
/* ------------------------------------------------------------------ */
let schemaReady = null;
function ensureSchema(env) {
  if (!schemaReady) {
    schemaReady = (async () => {
      const statements = [
        'CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, name TEXT NOT NULL, handle TEXT NOT NULL, password_hash TEXT NOT NULL, salt TEXT NOT NULL, created_at TEXT NOT NULL)',
        'CREATE UNIQUE INDEX IF NOT EXISTS users_handle ON users(handle)',
        'CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, created_at TEXT NOT NULL, expires_at TEXT NOT NULL)',
        'CREATE INDEX IF NOT EXISTS sessions_user ON sessions(user_id)',
        'CREATE TABLE IF NOT EXISTS workspaces (user_id TEXT PRIMARY KEY, handle TEXT NOT NULL UNIQUE, name TEXT NOT NULL, status TEXT NOT NULL, doc TEXT NOT NULL, updated_at TEXT NOT NULL)',
        'CREATE TABLE IF NOT EXISTS events (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, type TEXT NOT NULL, block_id TEXT, occurred_at TEXT NOT NULL, country TEXT, device TEXT, referrer TEXT)',
        'CREATE INDEX IF NOT EXISTS events_user_time ON events(user_id, occurred_at)',
      ];
      for (const statement of statements) {
        await env.DB.prepare(statement).run();
      }
    })().catch((err) => { schemaReady = null; throw err; });
  }
  return schemaReady;
}

function starterDoc(user) {
  const firstName = user.name.split(/\s+/)[0] || user.name;
  return {
    profile: {
      displayName: user.name,
      bio: '',
      avatarUrl: '',
      socials: [],
      headerAlign: 'center',
      headerSpacing: 'cozy',
      showSocials: true,
      email: user.email,
    },
    theme: { ...THEME },
    blocks: [],
    archived: [],
    published: null,
    contacts: [],
    conversations: [],
    events: [],
    messaging: {
      configured: true,
      welcome: `Thanks for reaching out! ${firstName} reads every message and usually replies within a couple of days.`,
      tab: 'all',
      spotlight: null,
    },
    subscribe: {
      enabled: false,
      fields: ['email'],
      consentText: `I agree to receive occasional emails from ${user.name}.`,
    },
    tools: {
      businessCard: {
        displayName: user.name,
        jobTitle: '',
        background: '#c7ff3f',
        showEmail: true,
        showPhone: false,
        showWebsite: true,
        email: user.email,
        phone: '',
        website: '',
      },
      mediaKit: { enabled: false, shareStats: true, contactEmail: user.email },
    },
    settings: {
      notifications: { weeklyDigest: true, newContact: true, newMessage: true, productUpdates: false },
      integrations: { instagram: false, tiktok: false, youtube: false, spotify: false, mailchimp: false },
      plan: 'Starter',
      publicProfile: { showInSearch: true, showContactButton: true },
    },
    onboarding: { completed: ['handle'] },
    demoAnalytics: false,
  };
}

async function findUserByEmail(env, email) {
  return env.DB.prepare('SELECT * FROM users WHERE email = ?').bind(email).first();
}

async function sessionUser(request, env) {
  const token = readCookie(request, SESSION_COOKIE);
  if (!token) return null;
  const tokenHash = await sha256Hex(token);
  const row = await env.DB.prepare(
    `SELECT u.id, u.email, u.name, u.handle, u.created_at, s.expires_at
     FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.token_hash = ? AND s.expires_at > ?`,
  ).bind(tokenHash, new Date().toISOString()).first();
  return row || null;
}

async function loadWorkspace(env, userId) {
  const row = await env.DB.prepare('SELECT handle, name, status, doc, updated_at FROM workspaces WHERE user_id = ?')
    .bind(userId).first();
  if (!row) return null;
  let doc = {};
  try { doc = JSON.parse(row.doc); } catch { doc = {}; }
  return { handle: row.handle, name: row.name, status: row.status, doc, updatedAt: row.updated_at };
}

async function loadEvents(env, userId) {
  const since = new Date(Date.now() - 90 * 86400000).toISOString();
  const { results } = await env.DB.prepare(
    `SELECT id, type, block_id, occurred_at, country, device, referrer
     FROM events WHERE user_id = ? AND occurred_at >= ?
     ORDER BY occurred_at ASC LIMIT 5000`,
  ).bind(userId, since).all();
  return (results || []).map((row) => ({
    id: row.id,
    type: row.type,
    blockId: row.block_id || null,
    occurredAt: row.occurred_at,
    country: row.country || 'Unknown',
    device: row.device || 'desktop',
    referrer: row.referrer || 'direct',
  }));
}

async function createSession(env, userId) {
  const token = b64url(crypto.getRandomValues(new Uint8Array(32)));
  const tokenHash = await sha256Hex(token);
  const now = new Date();
  const expires = new Date(now.getTime() + SESSION_DAYS * 86400000);
  await env.DB.prepare('INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)')
    .bind(tokenHash, userId, now.toISOString(), expires.toISOString()).run();
  return token;
}

/* ------------------------------------------------------------------ */
/* routes                                                              */
/* ------------------------------------------------------------------ */
async function handleApi(request, env, url) {
  await ensureSchema(env);
  const secure = url.protocol === 'https:';
  const path = url.pathname;
  const method = request.method;
  const mutation = method !== 'GET' && method !== 'HEAD';
  if (mutation && !sameOrigin(request, url)) return fail(403, 'forbidden_origin', 'Cross-origin request rejected.');

  /* ---------------- auth ---------------- */
  if (path === '/api/auth/sign-up' && method === 'POST') {
    if (!rateLimit(clientKey(request, 'signup'), 20, 60 * 60 * 1000)) {
      return fail(429, 'rate_limited', 'Too many sign-up attempts. Try again later.');
    }
    const body = await readJson(request);
    if (!body) return fail(400, 'bad_request', 'Send a JSON body.');
    const name = String(body.name || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    const handle = String(body.handle || '').trim().toLowerCase();
    const password = String(body.password || '');

    if (name.length < 2 || name.length > 60) return fail(422, 'invalid_name', 'Add a display name (2–60 characters).');
    if (!isEmail(email)) return fail(422, 'invalid_email', 'Enter a valid email address.');
    if (!isHandle(handle)) return fail(422, 'invalid_handle', 'Handles need 3–30 lowercase letters, numbers, dots or dashes.');
    if (RESERVED_HANDLES.has(handle)) return fail(409, 'handle_taken', 'That handle is not available.');
    if (password.length < 8) return fail(422, 'weak_password', 'Passwords need at least 8 characters.');

    const existing = await findUserByEmail(env, email);
    if (existing) return fail(409, 'email_taken', 'An account with that email already exists. Sign in instead.');
    const handleRow = await env.DB.prepare('SELECT user_id FROM workspaces WHERE handle = ?').bind(handle).first();
    if (handleRow) return fail(409, 'handle_taken', 'That handle is already taken.');

    const { salt, hash } = await derivePassword(password);
    const user = {
      id: crypto.randomUUID(), email, name, handle,
      password_hash: hash, salt, created_at: new Date().toISOString(),
    };
    try {
      await env.DB.batch([
        env.DB.prepare('INSERT INTO users (id, email, name, handle, password_hash, salt, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
          .bind(user.id, user.email, user.name, user.handle, user.password_hash, user.salt, user.created_at),
        env.DB.prepare('INSERT INTO workspaces (user_id, handle, name, status, doc, updated_at) VALUES (?, ?, ?, ?, ?, ?)')
          .bind(user.id, handle, name, 'draft', JSON.stringify(starterDoc(user)), user.created_at),
      ]);
    } catch (err) {
      const message = String(err?.message || '');
      if (message.includes('UNIQUE')) return fail(409, 'taken', 'That email or handle is already in use.');
      throw err;
    }

    const token = await createSession(env, user.id);
    return json(
      { user: { id: user.id, email, name, handle }, workspace: await loadWorkspace(env, user.id), events: [] },
      201,
      { 'set-cookie': sessionCookie(token, secure) },
    );
  }

  if (path === '/api/auth/sign-in' && method === 'POST') {
    if (!rateLimit(clientKey(request, 'signin'), 12, 15 * 60 * 1000)) {
      return fail(429, 'rate_limited', 'Too many sign-in attempts. Wait a few minutes and try again.');
    }
    const body = await readJson(request);
    if (!body) return fail(400, 'bad_request', 'Send a JSON body.');
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    if (!email || !password) return fail(422, 'missing_fields', 'Enter your email and password.');

    const user = await findUserByEmail(env, email);
    const derived = user ? await derivePassword(password, user.salt) : null;
    if (!user || !safeEqual(derived.hash, user.password_hash)) {
      return fail(401, 'invalid_credentials', 'That email and password do not match an account.');
    }

    await env.DB.prepare('DELETE FROM sessions WHERE expires_at < ?').bind(new Date().toISOString()).run();
    const token = await createSession(env, user.id);
    return json(
      {
        user: { id: user.id, email: user.email, name: user.name, handle: user.handle },
        workspace: await loadWorkspace(env, user.id),
        events: await loadEvents(env, user.id),
      },
      200,
      { 'set-cookie': sessionCookie(token, secure) },
    );
  }

  if (path === '/api/auth/sign-out' && method === 'POST') {
    const token = readCookie(request, SESSION_COOKIE);
    if (token) {
      await env.DB.prepare('DELETE FROM sessions WHERE token_hash = ?').bind(await sha256Hex(token)).run();
    }
    return json({ ok: true }, 200, { 'set-cookie': clearCookie(secure) });
  }

  if (path === '/api/auth/reset' && method === 'POST') {
    if (!rateLimit(clientKey(request, 'reset'), 8, 15 * 60 * 1000)) {
      return fail(429, 'rate_limited', 'Too many reset requests. Try again later.');
    }
    // Deliberately identical response whether or not the address exists.
    return json({ ok: true, message: 'If that address has an account, a reset link would be sent. This demo has no email service — sign in and change your password in Settings instead.' });
  }

  if (path === '/api/auth/password' && method === 'POST') {
    const user = await sessionUser(request, env);
    if (!user) return fail(401, 'unauthorized', 'Sign in first.');
    const body = await readJson(request);
    const current = String(body?.current || '');
    const next = String(body?.next || '');
    if (next.length < 8) return fail(422, 'weak_password', 'New passwords need at least 8 characters.');
    const full = await env.DB.prepare('SELECT password_hash, salt FROM users WHERE id = ?').bind(user.id).first();
    const derived = await derivePassword(current, full.salt);
    if (!safeEqual(derived.hash, full.password_hash)) return fail(403, 'wrong_password', 'Your current password is not correct.');
    const { salt, hash } = await derivePassword(next);
    await env.DB.prepare('UPDATE users SET password_hash = ?, salt = ? WHERE id = ?').bind(hash, salt, user.id).run();
    await env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(user.id).run();
    const token = await createSession(env, user.id);
    return json({ ok: true }, 200, { 'set-cookie': sessionCookie(token, secure) });
  }

  if (path === '/api/auth/profile' && method === 'PATCH') {
    const user = await sessionUser(request, env);
    if (!user) return fail(401, 'unauthorized', 'Sign in first.');
    const body = await readJson(request);
    const name = String(body?.name || '').trim();
    const email = String(body?.email || '').trim().toLowerCase();
    if (name.length < 2) return fail(422, 'invalid_name', 'Add a display name.');
    if (!isEmail(email)) return fail(422, 'invalid_email', 'Enter a valid email address.');
    const clash = await env.DB.prepare('SELECT id FROM users WHERE email = ? AND id != ?').bind(email, user.id).first();
    if (clash) return fail(409, 'email_taken', 'Another account already uses that email.');
    await env.DB.prepare('UPDATE users SET name = ?, email = ? WHERE id = ?').bind(name, email, user.id).run();
    return json({ ok: true, user: { id: user.id, email, name, handle: user.handle } });
  }

  if (path === '/api/auth/session' && method === 'GET') {
    const user = await sessionUser(request, env);
    if (!user) return fail(401, 'unauthorized', 'Not signed in.');
    return json({
      user: { id: user.id, email: user.email, name: user.name, handle: user.handle },
      workspace: await loadWorkspace(env, user.id),
      events: await loadEvents(env, user.id),
    });
  }

  /* ---------------- handle availability ---------------- */
  if (path.startsWith('/api/handles/') && method === 'GET') {
    const handle = decodeURIComponent(path.slice('/api/handles/'.length)).trim().toLowerCase();
    if (!isHandle(handle)) return json({ handle, available: false, reason: 'invalid' });
    if (RESERVED_HANDLES.has(handle)) return json({ handle, available: false, reason: 'reserved' });
    const row = await env.DB.prepare('SELECT user_id FROM workspaces WHERE handle = ?').bind(handle).first();
    return json({ handle, available: !row });
  }

  /* ---------------- workspace ---------------- */
  if (path === '/api/workspace' && method === 'PUT') {
    const user = await sessionUser(request, env);
    if (!user) return fail(401, 'unauthorized', 'Sign in to save your page.');
    const body = await readJson(request);
    if (!body) return fail(400, 'bad_request', 'Send a JSON body.');
    const handle = String(body.handle || user.handle).trim().toLowerCase();
    const name = String(body.name || user.name).trim();
    const status = body.status === 'published' ? 'published' : 'draft';
    if (!isHandle(handle)) return fail(422, 'invalid_handle', 'That handle is not valid.');
    if (RESERVED_HANDLES.has(handle) && handle !== user.handle) return fail(409, 'handle_taken', 'That handle is reserved.');
    const doc = JSON.stringify(body.doc ?? {});
    if (doc.length > MAX_DOC_BYTES) return fail(413, 'doc_too_large', 'This workspace is too large to save.');

    const clash = await env.DB.prepare('SELECT user_id FROM workspaces WHERE handle = ? AND user_id != ?')
      .bind(handle, user.id).first();
    if (clash) return fail(409, 'handle_taken', 'That handle is already taken.');

    const now = new Date().toISOString();
    await env.DB.batch([
      env.DB.prepare('UPDATE workspaces SET handle = ?, name = ?, status = ?, doc = ?, updated_at = ? WHERE user_id = ?')
        .bind(handle, name, status, doc, now, user.id),
      env.DB.prepare('UPDATE users SET handle = ?, name = ? WHERE id = ?').bind(handle, name, user.id),
    ]);
    return json({ ok: true, savedAt: now, handle, status });
  }

  /* ---------------- public profile ---------------- */
  if (path.startsWith('/api/public/') && method === 'GET' && !path.endsWith('/event') && !path.endsWith('/contact')) {
    const handle = decodeURIComponent(path.slice('/api/public/'.length)).trim().toLowerCase();
    if (!isHandle(handle)) return fail(404, 'not_found', 'Page not found.');
    const row = await env.DB.prepare('SELECT doc, updated_at FROM workspaces WHERE handle = ?').bind(handle).first();
    if (!row) return fail(404, 'not_found', 'Page not found.');
    let doc = {};
    try { doc = JSON.parse(row.doc); } catch { doc = {}; }
    if (!doc.published || !Array.isArray(doc.published.blocks)) {
      return fail(404, 'unpublished', 'This page has not been published yet.');
    }
    return json(
      { handle, published: doc.published, updatedAt: row.updated_at },
      200,
      { 'cache-control': 'public, max-age=30' },
    );
  }

  if (path.startsWith('/api/public/') && path.endsWith('/event') && method === 'POST') {
    const handle = decodeURIComponent(path.slice('/api/public/'.length, -'/event'.length)).trim().toLowerCase();
    if (!rateLimit(`event:${handle}:${clientKey(request, 'e')}`, 240, 60 * 1000)) {
      return json({ ok: true }); // silently drop floods
    }
    const body = await readJson(request);
    const type = String(body?.type || '');
    if (!['view', 'click', 'share', 'contact'].includes(type)) return fail(422, 'invalid_type', 'Unknown event type.');
    const owner = await env.DB.prepare('SELECT user_id FROM workspaces WHERE handle = ?').bind(handle).first();
    if (!owner) return fail(404, 'not_found', 'Page not found.');
    const blockId = body?.blockId ? String(body.blockId).slice(0, 64) : null;
    await env.DB.prepare(
      'INSERT INTO events (id, user_id, type, block_id, occurred_at, country, device, referrer) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    ).bind(
      crypto.randomUUID(), owner.user_id, type, blockId, new Date().toISOString(),
      String(request.headers.get('cf-ipcountry') || 'Unknown'),
      String(body?.device || 'desktop').slice(0, 16),
      String(body?.referrer || 'direct').slice(0, 60),
    ).run();
    return json({ ok: true });
  }

  if (path.startsWith('/api/public/') && path.endsWith('/contact') && method === 'POST') {
    if (!rateLimit(clientKey(request, 'contact'), 20, 10 * 60 * 1000)) {
      return fail(429, 'rate_limited', 'Too many messages from this connection. Try again shortly.');
    }
    const handle = decodeURIComponent(path.slice('/api/public/'.length, -'/contact'.length)).trim().toLowerCase();
    const body = await readJson(request);
    const email = String(body?.email || '').trim();
    const name = String(body?.name || '').trim().slice(0, 80);
    const message = String(body?.message || '').trim().slice(0, 1200);
    const kind = body?.kind === 'message' ? 'message' : 'subscribe';
    if (!isEmail(email)) return fail(422, 'invalid_email', 'Enter a valid email address.');
    if (body?.consent !== true) return fail(422, 'consent_required', 'Consent is required.');
    if (kind === 'message' && message.length < 2) return fail(422, 'message_required', 'Write a short message.');

    const row = await env.DB.prepare('SELECT user_id, doc FROM workspaces WHERE handle = ?').bind(handle).first();
    if (!row) return fail(404, 'not_found', 'Page not found.');
    let doc = {};
    try { doc = JSON.parse(row.doc); } catch { doc = {}; }
    doc.contacts = Array.isArray(doc.contacts) ? doc.contacts : [];
    doc.conversations = Array.isArray(doc.conversations) ? doc.conversations : [];

    const now = new Date().toISOString();
    if (!doc.contacts.some((c) => String(c.email || '').toLowerCase() === email.toLowerCase())) {
      doc.contacts.unshift({
        id: crypto.randomUUID(), name: name || email, email, phone: '', tags: [],
        source: kind === 'message' ? 'Message CTA' : 'Subscribe form',
        consentAt: now, createdAt: now,
      });
    }
    if (kind === 'message') {
      doc.conversations.unshift({
        id: crypto.randomUUID(), name: name || email, email, unread: 1, lastAt: now,
        messages: [{ id: crypto.randomUUID(), from: 'them', text: message, at: now }],
      });
    }
    await env.DB.batch([
      env.DB.prepare('UPDATE workspaces SET doc = ?, updated_at = ? WHERE user_id = ?')
        .bind(JSON.stringify(doc), now, row.user_id),
      env.DB.prepare('INSERT INTO events (id, user_id, type, block_id, occurred_at, country, device, referrer) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
        .bind(crypto.randomUUID(), row.user_id, 'contact', null, now, String(request.headers.get('cf-ipcountry') || 'Unknown'), 'desktop', 'direct'),
    ]);
    return json({ ok: true });
  }

  /* ---------------- account deletion ---------------- */
  if (path === '/api/account' && method === 'DELETE') {
    const user = await sessionUser(request, env);
    if (!user) return fail(401, 'unauthorized', 'Sign in first.');
    await env.DB.batch([
      env.DB.prepare('DELETE FROM events WHERE user_id = ?').bind(user.id),
      env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(user.id),
      env.DB.prepare('DELETE FROM workspaces WHERE user_id = ?').bind(user.id),
      env.DB.prepare('DELETE FROM users WHERE id = ?').bind(user.id),
    ]);
    return json({ ok: true }, 200, { 'set-cookie': clearCookie(secure) });
  }

  if (path === '/api/health') return json({ ok: true, service: SOURCE_LABEL });

  return fail(404, 'not_found', 'Unknown API route.');
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/')) {
      try {
        return await handleApi(request, env, url);
      } catch (err) {
        console.error('beacon_api_error', err && err.stack ? err.stack : String(err));
        return fail(500, 'server_error', 'Something went wrong on our side. Try again.');
      }
    }
    return env.ASSETS.fetch(request);
  },
};
