/* Build the deployable bundle: static assets in dist/public, Worker + manifest at dist/. */
import { rm, mkdir, cp, writeFile, readdir, readFile } from 'node:fs/promises';

const root = process.cwd();
const buildId = Date.now().toString(36);

await rm(`${root}/dist`, { recursive: true, force: true });
await mkdir(`${root}/dist/public`, { recursive: true });

await cp(`${root}/assets`, `${root}/dist/public/assets`, { recursive: true });
await cp(`${root}/js`, `${root}/dist/public/js`, { recursive: true });
await cp(`${root}/worker.js`, `${root}/dist/worker.js`);

// Version every module import so a new deploy never mixes with cached files.
async function versionModules(dir) {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const path = `${dir}/${entry.name}`;
    if (entry.isDirectory()) { await versionModules(path); continue; }
    if (!entry.name.endsWith('.js')) continue;
    const source = await readFile(path, 'utf8');
    const versioned = source
      .replace(/(\bfrom\s*['"])(\.{1,2}\/[^'"?]+\.js)(['"])/g, `$1$2?v=${buildId}$3`)
      .replace(/(\bimport\(\s*['"])(\.{1,2}\/[^'"?]+\.js)(['"])/g, `$1$2?v=${buildId}$3`);
    if (versioned !== source) await writeFile(path, versioned, 'utf8');
  }
}
await versionModules(`${root}/dist/public/js`);

const html = (await readFile(`${root}/index.html`, 'utf8'))
  .replace(/(src=")(\.?\/js\/app\.js)(")/g, `$1$2?v=${buildId}$3`);
await writeFile(`${root}/dist/public/index.html`, html, 'utf8');

// Never serve a stale app shell: module URLs inside it are versioned per build.
await writeFile(
  `${root}/dist/public/_headers`,
  ['/', '  Cache-Control: no-store', '', '/index.html', '  Cache-Control: no-store', ''].join('\n'),
  'utf8',
);

const manifest = {
  entrypoint: 'worker.js',
  compatibilityDate: '2026-11-01',
  modules: [{ name: 'worker.js', type: 'esm', path: './worker.js' }],
  assetsDirectory: './public',
};
await writeFile(`${root}/dist/manifest.json`, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');

let files = 0;
async function count(dir) {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    if (entry.isDirectory()) await count(`${dir}/${entry.name}`);
    else files += 1;
  }
}
await count(`${root}/dist/public`);
console.log(`Built dist/ with ${files} static assets + worker.js (build ${buildId})`);
